"""Приватный Telegram-бот для чтения локального архива переписки."""

from __future__ import annotations

import asyncio
import calendar
import logging
import os
import random
import re
import secrets
import shutil
import sqlite3
import sys
import tempfile
from collections import Counter
from contextlib import asynccontextmanager
from datetime import date, datetime
from pathlib import Path
from urllib.parse import unquote

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.middlewares.base import BaseRequestMiddleware
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest, TelegramRetryAfter
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    BotCommand,
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputMediaPhoto,
    KeyboardButton,
    MenuButtonWebApp,
    Message,
    ReplyKeyboardMarkup,
    WebAppInfo,
)

import config
import export_paths
import local_settings
import updater
import webapp_server
from screenshots import render_day_screenshots

log = logging.getLogger("archive-bot")

SEARCH_PAGE_SIZE = 8
MIN_SEARCH_LENGTH = 2
UPLOAD_LIMIT = 50 * 1024 * 1024        # лимит Telegram на файлы от ботов
PHOTO_LIMIT = 10 * 1024 * 1024         # крупнее — отправляем как файл
MAX_SEARCH_SESSIONS = 200

MONTH_NAMES_RU = ("", "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь")
MONTH_SHORT_RU = ("", "Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек")
WEEKDAYS_SHORT_RU = ("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
KIND_NAMES_RU = {
    "photo": "фото", "video": "видео", "video_note": "кружки", "voice": "голосовые",
    "animation": "GIF", "sticker": "стикеры",
}

BTN_CALENDAR = "📅 Календарь"
BTN_SEARCH = "🔎 Поиск"
BTN_RANDOM = "🎲 Случайный день"
BTN_TODAY = "📆 В этот день"
BTN_STATS = "📊 Статистика"
BTN_SETTINGS = "⚙️ Настройки"
def build_main_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BTN_CALENDAR), KeyboardButton(text=BTN_SEARCH)],
            [KeyboardButton(text=BTN_RANDOM), KeyboardButton(text=BTN_TODAY), KeyboardButton(text=BTN_STATS)],
            [KeyboardButton(text=BTN_SETTINGS)],
        ],
        resize_keyboard=True,
        is_persistent=True,
    )


MAIN_MENU = build_main_menu()

public_router = Router()      # /id — доступен всем, чтобы человек мог узнать свой ID
private_router = Router()     # всё остальное — только для разрешённых ID
fallback_router = Router()    # чужим — вежливый отказ
private_router.message.filter(F.from_user.id.in_(config.ALLOWED_USER_IDS))
private_router.callback_query.filter(F.from_user.id.in_(config.ALLOWED_USER_IDS))

search_waiting_for_input: set[int] = set()
search_sessions: dict[str, tuple[int, str, bool]] = {}     # token -> (user, term, newest_first)
busy_users: set[int] = set()


class ProtectContentMiddleware(BaseRequestMiddleware):
    """Запрет пересылки и сохранения — личная настройка получателя (в личном чате chat_id = ID человека)."""

    async def __call__(self, make_request, bot, method):
        chat_id = getattr(method, "chat_id", None)
        if isinstance(chat_id, int) and "protect_content" in getattr(type(method), "model_fields", {}):
            value = local_settings.effective(chat_id).protect
            try:
                method.protect_content = value
            except (TypeError, ValueError):
                method.__dict__["protect_content"] = value
        return await make_request(bot, method)


class BotAlreadyRunning(RuntimeError):
    """Другой экземпляр бота уже опрашивает Telegram."""


# ----------------------------------------------------------------------------
# Служебное
# ----------------------------------------------------------------------------

def acquire_instance_mutex() -> int | None:
    """Именованный мьютекс Windows: второй экземпляр бота не запустится."""
    if os.name != "nt":
        return None
    import ctypes

    kernel32 = ctypes.windll.kernel32
    handle = kernel32.CreateMutexW(None, False, "Local\\PrivateArchiveBotPolling")
    if not handle:
        raise RuntimeError("Не удалось создать блокировку экземпляра бота.")
    if kernel32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
        kernel32.CloseHandle(handle)
        raise BotAlreadyRunning
    return handle


async def retry_telegram(operation):
    """Повторяет запрос при лимите Telegram, чтобы страница не обрывалась на середине."""
    for attempt in range(3):
        try:
            result = await operation()
            await asyncio.sleep(0.08)
            return result
        except TelegramRetryAfter as error:
            if attempt == 2:
                raise
            await asyncio.sleep(float(error.retry_after) + 0.5)


@asynccontextmanager
async def exclusive(user_id: int):
    """Один тяжёлый запрос (чтение/скриншоты) на человека — без дублей от двойных нажатий."""
    if user_id in busy_users:
        yield False
        return
    busy_users.add(user_id)
    try:
        yield True
    finally:
        busy_users.discard(user_id)


def split_for_telegram(text: str, limit: int = 4096) -> list[str]:
    """Режет длинный текст по лимиту Telegram, ничего не теряя."""
    parts: list[str] = []
    remaining = text
    while len(remaining) > limit:
        cut = max(remaining.rfind("\n", 0, limit), remaining.rfind(" ", 0, limit))
        if cut < 1:
            cut = limit
        parts.append(remaining[:cut].rstrip())
        remaining = remaining[cut:].lstrip()
    if remaining or not parts:
        parts.append(remaining)
    return parts


def plural(number: int, forms: tuple[str, str, str]) -> str:
    n = abs(number) % 100
    if 11 <= n <= 19:
        return forms[2]
    return forms[{1: 0, 2: 1, 3: 1, 4: 1}.get(n % 10, 2)]


def human_day(day: str, weekday: bool = False) -> str:
    value = datetime.strptime(day, "%Y-%m-%d")
    text = value.strftime("%d.%m.%Y")
    return f"{text}, {WEEKDAYS_SHORT_RU[value.weekday()]}" if weekday else text


def compact(number: int) -> str:
    return f"{number / 1000:.1f}k".replace(".0k", "k") if number >= 1000 else str(number)


# ----------------------------------------------------------------------------
# База данных
# ----------------------------------------------------------------------------

def db_rows(query: str, params: tuple = ()) -> list[sqlite3.Row]:
    connection = sqlite3.connect(f"{config.DATABASE_PATH.as_uri()}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    try:
        return connection.execute(query, params).fetchall()
    finally:
        connection.close()


def db_value(query: str, params: tuple = (), default=None):
    rows = db_rows(query, params)
    return rows[0][0] if rows and rows[0][0] is not None else default


def meta(key: str, default: str = "") -> str:
    try:
        return db_value("SELECT value FROM meta WHERE key = ?", (key,), default)
    except sqlite3.Error:
        return default


def export_dir() -> Path | None:
    value = config.EXPORT_DIR_OVERRIDE or meta("export_dir")
    return Path(value).resolve() if value else None


def available_months() -> list[str]:
    return [row["month"] for row in db_rows("SELECT DISTINCT substr(day, 1, 7) AS month FROM messages ORDER BY month")]


def day_exists(day: str) -> bool:
    return bool(re.fullmatch(r"\d{4}-\d{2}-\d{2}", day)) and bool(db_rows("SELECT 1 FROM messages WHERE day = ? LIMIT 1", (day,)))


def day_count(day: str) -> int:
    return db_value("SELECT COUNT(*) FROM messages WHERE day = ?", (day,), 0)


def neighbour_day(day: str, forward: bool) -> str | None:
    if forward:
        return db_value("SELECT MIN(day) FROM messages WHERE day > ?", (day,))
    return db_value("SELECT MAX(day) FROM messages WHERE day < ?", (day,))


def search_term_pattern(term: str) -> str:
    escaped = term.casefold().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


def search_count(term: str) -> int:
    return db_value("SELECT COUNT(*) FROM messages WHERE search_text LIKE ? ESCAPE '\\'", (search_term_pattern(term),), 0)


def search_rows(term: str, offset: int, newest_first: bool) -> list[sqlite3.Row]:
    order = "DESC" if newest_first else "ASC"
    return db_rows(
        f"""SELECT m.sent_at, m.day, m.author, m.text,
                   (SELECT COUNT(*) FROM messages x WHERE x.day = m.day AND x.sort_key < m.sort_key) AS position
            FROM messages m
            WHERE m.search_text LIKE ? ESCAPE '\\'
            ORDER BY m.sort_key {order} LIMIT ? OFFSET ?""",
        (search_term_pattern(term), SEARCH_PAGE_SIZE, offset),
    )


def attachment_rows(message_id: str) -> list[tuple[str, str]]:
    """(путь, тип). Анимированные стикеры .tgs старые индексы считали файлами — исправляем на лету."""
    return [
        (row["relative_path"], "sticker" if row["relative_path"].lower().endswith(".tgs") else row["kind"])
        for row in db_rows("SELECT relative_path, kind FROM attachments WHERE message_id = ? ORDER BY id", (message_id,))
    ]


def export_roots() -> export_paths.ExportRoots | None:
    return export_paths.cached_roots(config.DATABASE_PATH, config.EXPORT_DIR_OVERRIDE)


def safe_media_path(relative_path: str) -> Path | None:
    roots = export_roots()
    return roots.resolve(relative_path) if roots is not None else None


def parse_user_date(text: str) -> str | None:
    """15.03.2024, 15/3/24, 2024-03-15 → '2024-03-15' (или None, если это не дата)."""
    text = text.strip()
    match = re.fullmatch(r"(\d{1,2})[./\-](\d{1,2})[./\-](\d{2}|\d{4})", text)
    if match:
        d, m, y = (int(g) for g in match.groups())
        y += 2000 if y < 100 else 0
    else:
        match = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", text)
        if not match:
            return None
        y, m, d = (int(g) for g in match.groups())
    try:
        return date(y, m, d).isoformat()
    except ValueError:
        return None


# ----------------------------------------------------------------------------
# Клавиатуры и тексты
# ----------------------------------------------------------------------------

def calendar_keyboard(month: str) -> InlineKeyboardMarkup:
    year, month_number = (int(value) for value in month.split("-"))
    active_days = {int(row["day"][-2:]) for row in db_rows("SELECT DISTINCT day FROM messages WHERE substr(day, 1, 7) = ?", (month,))}
    months = available_months()
    month_index = months.index(month) if month in months else 0
    navigation: list[InlineKeyboardButton] = []
    if month_index:
        navigation.append(InlineKeyboardButton(text="‹", callback_data=f"month:{months[month_index - 1]}"))
    # Нажатие на название месяца открывает выбор года.
    navigation.append(InlineKeyboardButton(text=f"{MONTH_NAMES_RU[month_number]} {year} ▾", callback_data=f"year:{year}"))
    if month_index + 1 < len(months):
        navigation.append(InlineKeyboardButton(text="›", callback_data=f"month:{months[month_index + 1]}"))
    buttons: list[list[InlineKeyboardButton]] = [navigation]
    buttons.append([InlineKeyboardButton(text=name, callback_data="ignore") for name in WEEKDAYS_SHORT_RU])
    for week in calendar.monthcalendar(year, month_number):
        row: list[InlineKeyboardButton] = []
        for value in week:
            if not value:
                row.append(InlineKeyboardButton(text="·", callback_data="ignore"))
            elif value in active_days:
                row.append(InlineKeyboardButton(text=str(value), callback_data=f"day:{month}-{value:02d}"))
            else:
                row.append(InlineKeyboardButton(text="—", callback_data="ignore"))
        buttons.append(row)
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def years_keyboard() -> InlineKeyboardMarkup:
    rows = db_rows("SELECT substr(day, 1, 4) AS year, COUNT(*) AS count FROM messages GROUP BY year ORDER BY year")
    buttons = [InlineKeyboardButton(text=f"{row['year']} · {compact(row['count'])}", callback_data=f"year:{row['year']}") for row in rows]
    return InlineKeyboardMarkup(inline_keyboard=[buttons[i:i + 3] for i in range(0, len(buttons), 3)])


def year_keyboard(year: str) -> InlineKeyboardMarkup:
    counts = {
        row["month"]: row["count"]
        for row in db_rows("SELECT substr(day, 1, 7) AS month, COUNT(*) AS count FROM messages WHERE substr(day, 1, 4) = ? GROUP BY month", (year,))
    }
    buttons: list[InlineKeyboardButton] = []
    for number in range(1, 13):
        month = f"{year}-{number:02d}"
        if month in counts:
            buttons.append(InlineKeyboardButton(text=f"{MONTH_SHORT_RU[number]} · {compact(counts[month])}", callback_data=f"month:{month}"))
        else:
            buttons.append(InlineKeyboardButton(text="—", callback_data="ignore"))
    rows = [buttons[i:i + 3] for i in range(0, 12, 3)]
    rows.append([InlineKeyboardButton(text="‹ Все годы", callback_data="years")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def day_keyboard(day: str) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text="📖 Читать сообщения", callback_data=f"read:{day}:0")],
        [InlineKeyboardButton(text="🖼 Скриншоты дня", callback_data=f"shots:{day}")],
    ]
    neighbours: list[InlineKeyboardButton] = []
    previous_day, next_day = neighbour_day(day, False), neighbour_day(day, True)
    if previous_day:
        neighbours.append(InlineKeyboardButton(text=f"‹ {previous_day[8:10]}.{previous_day[5:7]}", callback_data=f"day:{previous_day}"))
    if next_day:
        neighbours.append(InlineKeyboardButton(text=f"{next_day[8:10]}.{next_day[5:7]} ›", callback_data=f"day:{next_day}"))
    if neighbours:
        rows.append(neighbours)
    rows.append([InlineKeyboardButton(text="📅 К календарю", callback_data=f"month:{day[:7]}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def day_summary(day: str) -> str:
    count = day_count(day)
    media = db_value("SELECT COUNT(*) FROM attachments a JOIN messages m ON m.id = a.message_id WHERE m.day = ?", (day,), 0)
    first, last = db_rows("SELECT MIN(sent_at) AS a, MAX(sent_at) AS b FROM messages WHERE day = ?", (day,))[0]
    span = f"{datetime.fromisoformat(first):%H:%M}–{datetime.fromisoformat(last):%H:%M}"
    text = f"📅 {human_day(day, weekday=True)}\n{count} {plural(count, ('сообщение', 'сообщения', 'сообщений'))}, {span}"
    if media:
        text += f"\nВложений: {media}"
    return text


def search_snippet(text: str, term: str, limit: int = 230) -> str:
    flat = " ".join(text.split())
    position = flat.casefold().find(term.casefold())
    if position < 0:
        return flat[:limit] + ("…" if len(flat) > limit else "")
    start = max(0, position - 80)
    end = min(len(flat), position + len(term) + 140)
    return ("…" if start else "") + flat[start:end] + ("…" if end < len(flat) else "")


def search_text(term: str, rows: list[sqlite3.Row], total: int, offset: int, newest_first: bool) -> str:
    order = "сначала новые" if newest_first else "сначала старые"
    lines = [f"🔎 «{term}» — найдено: {total} ({order})", f"Результаты {offset + 1}–{offset + len(rows)}. Номер под текстом откроет это место в переписке."]
    for number, row in enumerate(rows, start=offset + 1):
        sent_at = datetime.fromisoformat(row["sent_at"])
        lines.extend((f"\n{number}. {sent_at:%d.%m.%Y %H:%M} · {row['author']}", search_snippet(row["text"], term)))
    return "\n".join(lines)


def search_keyboard(token: str, rows: list[sqlite3.Row], offset: int, total: int, newest_first: bool) -> InlineKeyboardMarkup:
    keyboard: list[list[InlineKeyboardButton]] = []
    keyboard.append([
        InlineKeyboardButton(text=str(number), callback_data=f"read:{row['day']}:{max(0, row['position'] - 2)}")
        for number, row in enumerate(rows, start=offset + 1)
    ])
    paging: list[InlineKeyboardButton] = []
    if offset:
        paging.append(InlineKeyboardButton(text="‹ Назад", callback_data=f"find:{token}:{max(0, offset - SEARCH_PAGE_SIZE)}"))
    if offset + SEARCH_PAGE_SIZE < total:
        paging.append(InlineKeyboardButton(text="Дальше ›", callback_data=f"find:{token}:{offset + SEARCH_PAGE_SIZE}"))
    if paging:
        keyboard.append(paging)
    keyboard.append([InlineKeyboardButton(text="↕ Сначала старые" if newest_first else "↕ Сначала новые", callback_data=f"findo:{token}")])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)


# ----------------------------------------------------------------------------
# Отправка
# ----------------------------------------------------------------------------

async def deliver_attachment(bot: Bot, chat_id: int, relative_path: str, kind: str) -> str | None:
    """Отправляет вложение. Возвращает текст проблемы, если не получилось, — чтение не прерывается."""
    path = safe_media_path(relative_path)
    if path is None:
        return f"⚠️ Файл не найден (его нет в экспорте или папка перенесена): {relative_path}"
    size = path.stat().st_size
    if size > UPLOAD_LIMIT:
        return f"⚠️ Файл слишком большой для бота ({size / 1048576:.0f} МБ): {relative_path}"

    async def send(as_kind: str) -> None:
        file = FSInputFile(path)
        if as_kind == "photo":
            await bot.send_photo(chat_id, file)
        elif as_kind == "voice":
            await bot.send_voice(chat_id, file)
        elif as_kind == "video_note":
            await bot.send_video_note(chat_id, file)
        elif as_kind == "video":
            await bot.send_video(chat_id, file, supports_streaming=True)
        elif as_kind == "animation":
            await bot.send_animation(chat_id, file)
        elif as_kind == "sticker" and path.suffix.lower() in {".webp", ".tgs", ".webm"}:
            await bot.send_sticker(chat_id, file)
        else:
            await bot.send_document(chat_id, file)

    send_as = "document" if kind == "photo" and size > PHOTO_LIMIT else kind
    try:
        await retry_telegram(lambda: send(send_as))
        return None
    except TelegramBadRequest as error:
        if send_as != "document":  # Telegram не принял как фото/видео/голосовое — отправим файлом
            try:
                await retry_telegram(lambda: send("document"))
                return None
            except TelegramAPIError as second:
                error = second
        log.warning("attachment %s failed: %s", relative_path, error)
        return f"⚠️ Telegram не принял файл: {relative_path}"
    except TelegramAPIError as error:
        log.warning("attachment %s failed: %s", relative_path, error)
        return f"⚠️ Не удалось отправить файл: {relative_path}"


async def edit_or_answer(source: Message | CallbackQuery, text: str, markup: InlineKeyboardMarkup | None = None) -> None:
    if isinstance(source, CallbackQuery):
        try:
            await source.message.edit_text(text, reply_markup=markup)
        except TelegramBadRequest as error:
            if "not modified" not in str(error):
                raise
    else:
        await source.answer(text, reply_markup=markup)


async def show_calendar(source: Message | CallbackQuery, month: str | None = None) -> None:
    months = available_months()
    if not months:
        await edit_or_answer(source, "Архив ещё не проиндексирован.")
        return
    month = month if month in months else months[-1]
    await edit_or_answer(source, "Выбери день:", calendar_keyboard(month))


async def show_day(source: Message | CallbackQuery, day: str) -> None:
    if not day_exists(day):
        await edit_or_answer(source, f"За {human_day(day)} сообщений нет. Открой календарь — там отмечены дни с перепиской.")
        return
    await edit_or_answer(source, day_summary(day), day_keyboard(day))


async def present_search(message: Message, term: str) -> None:
    term = " ".join(term.split())
    if len(term) < MIN_SEARCH_LENGTH:
        await message.answer(f"Введи хотя бы {MIN_SEARCH_LENGTH} символа.")
        return
    total = search_count(term)
    if not total:
        await message.answer(f"По запросу «{term}» ничего не найдено.")
        return
    if len(search_sessions) >= MAX_SEARCH_SESSIONS:
        search_sessions.pop(next(iter(search_sessions)))
    token = secrets.token_urlsafe(6)
    search_sessions[token] = (message.from_user.id, term, True)
    rows = search_rows(term, 0, True)
    await message.answer(search_text(term, rows, total, 0, True), reply_markup=search_keyboard(token, rows, 0, total, True))


async def show_random_day(source: Message | CallbackQuery) -> None:
    days = [row["day"] for row in db_rows("SELECT DISTINCT day FROM messages")]
    if not days:
        await edit_or_answer(source, "Архив ещё не проиндексирован.")
        return
    await show_day(source, random.choice(days))


async def show_on_this_day(source: Message | CallbackQuery) -> None:
    today = date.today()
    rows = db_rows(
        "SELECT day, COUNT(*) AS count FROM messages WHERE substr(day, 6, 5) = ? GROUP BY day ORDER BY day",
        (f"{today.month:02d}-{today.day:02d}",),
    )
    if not rows:
        await edit_or_answer(source, f"В этот день ({today:%d.%m}) в архиве ничего нет.")
        return
    buttons = [[InlineKeyboardButton(text=f"{row['day'][:4]} — {row['count']} {plural(row['count'], ('сообщение', 'сообщения', 'сообщений'))}", callback_data=f"day:{row['day']}")] for row in rows]
    await edit_or_answer(source, f"📆 {today:%d.%m} в разные годы:", InlineKeyboardMarkup(inline_keyboard=buttons))


def media_health() -> tuple[int, int]:
    """(всего вложений, не найдено на диске) — запускается в потоке."""
    missing = total = 0
    for row in db_rows("SELECT relative_path FROM attachments"):
        total += 1
        if safe_media_path(row["relative_path"]) is None:
            missing += 1
    return total, missing


def build_stats() -> str:
    total = db_value("SELECT COUNT(*) FROM messages", (), 0)
    days = db_value("SELECT COUNT(DISTINCT day) FROM messages", (), 0)
    first, last = db_rows("SELECT MIN(day) AS a, MAX(day) AS b FROM messages")[0]
    lines = [
        "📊 Статистика переписки",
        f"Сообщений: {total} · дней с перепиской: {days}",
        f"Период: {human_day(first)} — {human_day(last)}",
    ]
    authors = db_rows("SELECT author, COUNT(*) AS count FROM messages GROUP BY author ORDER BY count DESC LIMIT 5")
    if authors:
        lines.append("Писали: " + ", ".join(f"{row['author']} — {row['count']} ({row['count'] * 100 // total}%)" for row in authors))
    busiest = db_rows("SELECT day, COUNT(*) AS count FROM messages GROUP BY day ORDER BY count DESC LIMIT 1")[0]
    lines.append(f"Самый длинный день: {human_day(busiest['day'])} — {busiest['count']} сообщ.")
    kinds = Counter({
        row["kind"]: row["count"]
        for row in db_rows("SELECT CASE WHEN lower(relative_path) LIKE '%.tgs' THEN 'sticker' ELSE kind END AS kind, COUNT(*) AS count FROM attachments GROUP BY 1")
        if row["kind"] != "document"   # «файлы» в статистике не показываем
    })
    if kinds:
        lines.append("Вложения: " + ", ".join(f"{KIND_NAMES_RU.get(kind, kind)} — {count}" for kind, count in kinds.most_common()))
    indexed = meta("indexed_at")
    if indexed:
        lines.append(f"Индекс обновлён: {datetime.fromisoformat(indexed):%d.%m.%Y %H:%M}")
    lines.append(f"База: {config.DATABASE_PATH}")   # видно, с какой папкой данных работает этот бот
    return "\n".join(lines)


# ----------------------------------------------------------------------------
# Обработчики для всех
# ----------------------------------------------------------------------------

@public_router.message(Command("id"))
async def show_id(message: Message) -> None:
    await message.answer(f"Ваш Telegram ID: {message.from_user.id}")


# ----------------------------------------------------------------------------
# Обработчики для разрешённых
# ----------------------------------------------------------------------------

@private_router.message(CommandStart())
async def start(message: Message) -> None:
    if not available_months():
        await message.answer("Архив ещё не проиндексирован. Запустите «2_Обновить_переписку.bat».")
        return
    # Клавиатуру нельзя повесить без сообщения: отправляем точку и сразу её удаляем — кнопки остаются, приветствия нет.
    carrier = await message.answer("·", reply_markup=MAIN_MENU)
    try:
        await carrier.delete()
    except (TelegramAPIError, AttributeError):
        pass
    await show_calendar(message)


@private_router.message(Command("dates"))
@private_router.message(F.text == BTN_CALENDAR)
async def open_calendar(message: Message) -> None:
    await show_calendar(message)


@private_router.message(Command("random"))
@private_router.message(F.text == BTN_RANDOM)
async def random_day(message: Message) -> None:
    await show_random_day(message)


@private_router.message(Command("today"))
@private_router.message(F.text == BTN_TODAY)
async def on_this_day(message: Message) -> None:
    await show_on_this_day(message)


@private_router.message(Command("stats"))
@private_router.message(F.text == BTN_STATS)
async def stats(message: Message) -> None:
    text = build_stats()
    root = export_dir()
    if root is None or not root.is_dir():
        text += "\n\n⚠️ Папка экспорта не найдена — фото, видео и файлы отправляться не будут. Верни папку на место или запусти «2_Обновить_переписку.bat» с новым путём."
    else:
        total, missing = await asyncio.to_thread(media_health)
        if missing:
            text += f"\n\n⚠️ Файлов вложений нет на диске: {missing} из {total} (не были скачаны при экспорте или удалены)."
        elif total:
            text += "\n\n✅ Все вложения на месте."
    await message.answer(text)


# ----------------------------------------------------------------------------
# Личные настройки (/settings)
# ----------------------------------------------------------------------------

def target_token(target: int | None) -> str:
    return "a" if target is None else str(target)


def parse_target(token: str) -> tuple[bool, int | None]:
    """(верно ли, ID). «a» — настройки «для всех по умолчанию»."""
    if token == "a":
        return True, None
    if token.isdigit() and int(token) in config.ALLOWED_USER_IDS:
        return True, int(token)
    return False, None


def settings_text(actor: int, target: int | None) -> str:
    here = local_settings.effective(target)
    default_author = local_settings.first_author()
    if target is None:
        title = "Настройки для всех по умолчанию"
    elif target == actor:
        title = "Мои настройки"
    else:
        title = f"Настройки пользователя {target}"
    lines = [f"⚙️ {title}", ""]
    for key in local_settings.PARAMS:
        lines.append(f"• {local_settings.TITLES[key]}: {local_settings.describe(key, getattr(here, key), default_author)}")
    if actor != local_settings.admin_id():
        lines += ["", f"Приватность и «чьим лицом» показывается переписка меняет главный пользователь (ID {local_settings.admin_id()}).",
                  f"Ваш ID: {actor}. Главного можно сменить на компьютере: Управление.bat → Локальные настройки → g."]
    return "\n".join(lines)


def settings_keyboard(actor: int, target: int | None) -> InlineKeyboardMarkup:
    here = local_settings.effective(target)
    token = target_token(target)
    labels = {
        "perspective": f"👤 Чьим лицом: {here.perspective or 'как в архиве'}",
        "protect": "🔒 Пересылка: " + ("запрещена" if here.protect else "разрешена"),
        "page_size": f"📄 Сообщений за раз: {here.page_size}",
        "names": "🏷 Имена в приложении: " + {"auto": "авто", "show": "да", "hide": "нет"}[here.names],
    }
    rows = []
    for index, key in enumerate(local_settings.PARAMS):
        if local_settings.can_edit(actor, target, key):
            data = f"set:p:{token}" if key == "perspective" else f"set:v:{token}:{index}"
            rows.append([InlineKeyboardButton(text=labels[key], callback_data=data)])
    if actor == local_settings.admin_id():
        if target is not None and local_settings.load()["users"].get(str(target)):
            rows.append([InlineKeyboardButton(text="↩️ Сбросить личные на общие", callback_data=f"set:r:{token}")])
        rows.append([InlineKeyboardButton(text="👥 Все пользователи", callback_data="set:u")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@private_router.message(Command("settings"))
@private_router.message(F.text == BTN_SETTINGS)
async def open_settings(message: Message) -> None:
    user_id = message.from_user.id
    await message.answer(settings_text(user_id, user_id), reply_markup=settings_keyboard(user_id, user_id))


@private_router.callback_query(F.data.startswith("set:"))
async def settings_callback(callback: CallbackQuery) -> None:
    actor = callback.from_user.id
    admin = local_settings.admin_id()
    parts = callback.data.split(":")
    action = parts[1] if len(parts) > 1 else ""

    if action == "u":   # список людей — только главному
        if actor != admin:
            await callback.answer("Это доступно только главному пользователю.", show_alert=True)
            return
        rows = [[InlineKeyboardButton(text="Для всех по умолчанию", callback_data="set:o:a")]]
        for uid in local_settings.users():
            here = local_settings.effective(uid)
            label = f"ID {uid}" + (" (вы)" if uid == actor else "") + f" · {here.perspective or 'как в архиве'}"
            rows.append([InlineKeyboardButton(text=label, callback_data=f"set:o:{uid}")])
        await edit_or_answer(callback, "👥 Чьи настройки открыть?", InlineKeyboardMarkup(inline_keyboard=rows))
        await callback.answer()
        return

    valid, target = parse_target(parts[2] if len(parts) > 2 else "")
    if not valid:
        await callback.answer("Эти настройки недоступны.", show_alert=True)
        return
    if target != actor and actor != admin:
        await callback.answer("Чужие настройки может менять только главный пользователь.", show_alert=True)
        return

    async def show_panel() -> None:
        await edit_or_answer(callback, settings_text(actor, target), settings_keyboard(actor, target))

    if action == "o":
        await show_panel()
    elif action == "v":   # быстрые переключатели: пересылка, число сообщений, имена
        try:
            key = local_settings.PARAMS[int(parts[3])]
        except (IndexError, ValueError):
            await callback.answer("Эта кнопка устарела.", show_alert=True)
            return
        if key == "perspective" or not local_settings.can_edit(actor, target, key):
            await callback.answer("Этот пункт вам менять нельзя.", show_alert=True)
            return
        here = getattr(local_settings.effective(target), key)
        if key == "protect":
            new = not here
        elif key == "page_size":
            bigger = [size for size in local_settings.PAGE_SIZES if size > here]
            new = bigger[0] if bigger else local_settings.PAGE_SIZES[0]
        else:
            modes = local_settings.NAMES_MODES
            new = modes[(modes.index(here) + 1) % len(modes)]
        local_settings.update(target, key, new)
        await show_panel()
    elif action == "p":   # выбор «чьим лицом»
        if not local_settings.can_edit(actor, target, "perspective"):
            await callback.answer("Это может менять только главный пользователь.", show_alert=True)
            return
        token = target_token(target)
        rows = [[InlineKeyboardButton(text="Как в архиве (автор первого сообщения)", callback_data=f"set:a:{token}:0")]]
        for number, name in enumerate(local_settings.list_authors(), 1):
            rows.append([InlineKeyboardButton(text=name, callback_data=f"set:a:{token}:{number}")])
        if target is not None:
            rows.append([InlineKeyboardButton(text="Брать общее значение", callback_data=f"set:a:{token}:r")])
        rows.append([InlineKeyboardButton(text="‹ Назад", callback_data=f"set:o:{token}")])
        await edit_or_answer(callback, "👤 От чьего лица показывать переписку?\nЭтого автора пузыри будут справа, как «мои».", InlineKeyboardMarkup(inline_keyboard=rows))
    elif action == "a":
        if not local_settings.can_edit(actor, target, "perspective"):
            await callback.answer("Это может менять только главный пользователь.", show_alert=True)
            return
        choice = parts[3] if len(parts) > 3 else ""
        authors = local_settings.list_authors()
        if choice == "r" and target is not None:
            local_settings.update(target, "perspective", None)
        elif choice == "0":
            local_settings.update(target, "perspective", "")
        elif choice.isdigit() and 1 <= int(choice) <= len(authors):
            local_settings.update(target, "perspective", authors[int(choice) - 1])
        else:
            await callback.answer("Список изменился, откройте выбор заново.", show_alert=True)
            return
        await show_panel()
    elif action == "r":
        if actor != admin or target is None:
            await callback.answer("Это доступно только главному пользователю.", show_alert=True)
            return
        for key in local_settings.PARAMS:
            local_settings.update(target, key, None)
        await show_panel()
    else:
        await callback.answer()
        return
    await callback.answer()


async def begin_search(message: Message) -> None:
    search_waiting_for_input.add(message.from_user.id)
    await message.answer("Введи слово или фразу для поиска.")


@private_router.message(F.text == BTN_SEARCH)
async def choose_search(message: Message) -> None:
    await begin_search(message)


@private_router.message(Command("find"))
async def command_search(message: Message) -> None:
    _, _, term = (message.text or "").partition(" ")
    if not term.strip():
        await begin_search(message)
        return
    await present_search(message, term)


@private_router.message(F.text & ~F.text.startswith("/"))
async def receive_text(message: Message) -> None:
    """Любой другой текст: дата открывает день, всё остальное — поиск."""
    text = message.text or ""
    user_id = message.from_user.id
    if user_id in search_waiting_for_input:
        search_waiting_for_input.discard(user_id)
        await present_search(message, text)
        return
    day = parse_user_date(text)
    if day:
        await show_day(message, day)
        return
    await present_search(message, text)


@private_router.callback_query(F.data == "ignore")
async def ignore(callback: CallbackQuery) -> None:
    await callback.answer()


@private_router.callback_query(F.data == "years")
async def choose_year_list(callback: CallbackQuery) -> None:
    await edit_or_answer(callback, "Выбери год:", years_keyboard())
    await callback.answer()


@private_router.callback_query(F.data.startswith("year:"))
async def choose_year(callback: CallbackQuery) -> None:
    year = callback.data.split(":", 1)[1]
    if not any(month.startswith(year) for month in available_months()):
        await callback.answer("За этот год ничего нет.", show_alert=True)
        return
    await edit_or_answer(callback, f"{year} — выбери месяц:", year_keyboard(year))
    await callback.answer()


@private_router.callback_query(F.data.startswith("month:"))
async def choose_month(callback: CallbackQuery) -> None:
    month = callback.data.split(":", 1)[1]
    if month not in available_months():
        await callback.answer("Эта дата недоступна.", show_alert=True)
        return
    await show_calendar(callback, month)
    await callback.answer()


@private_router.callback_query(F.data.startswith("day:"))
async def choose_day(callback: CallbackQuery) -> None:
    day = callback.data.split(":", 1)[1]
    if not day_exists(day):
        await callback.answer("За эту дату сообщений нет.", show_alert=True)
        return
    await show_day(callback, day)
    await callback.answer()


@private_router.callback_query(F.data.startswith("find:"))
async def browse_search(callback: CallbackQuery) -> None:
    try:
        _, token, offset_text = callback.data.split(":")
        offset = int(offset_text)
        owner_id, term, newest_first = search_sessions[token]
    except (KeyError, ValueError):
        await callback.answer("Поиск устарел. Запусти его ещё раз.", show_alert=True)
        return
    if owner_id != callback.from_user.id or offset < 0:
        await callback.answer("Нет доступа к этому поиску.", show_alert=True)
        return
    await render_search_page(callback, token, term, offset, newest_first)


@private_router.callback_query(F.data.startswith("findo:"))
async def toggle_search_order(callback: CallbackQuery) -> None:
    token = callback.data.split(":", 1)[1]
    session = search_sessions.get(token)
    if session is None:
        await callback.answer("Поиск устарел. Запусти его ещё раз.", show_alert=True)
        return
    owner_id, term, newest_first = session
    if owner_id != callback.from_user.id:
        await callback.answer("Нет доступа к этому поиску.", show_alert=True)
        return
    search_sessions[token] = (owner_id, term, not newest_first)
    await render_search_page(callback, token, term, 0, not newest_first)


async def render_search_page(callback: CallbackQuery, token: str, term: str, offset: int, newest_first: bool) -> None:
    total = search_count(term)
    rows = search_rows(term, offset, newest_first)
    if not rows:
        await callback.answer("Результатов больше нет.", show_alert=True)
        return
    await edit_or_answer(callback, search_text(term, rows, total, offset, newest_first), search_keyboard(token, rows, offset, total, newest_first))
    await callback.answer()


@private_router.callback_query(F.data.startswith("read:"))
async def read_page(callback: CallbackQuery, bot: Bot) -> None:
    try:
        _, day, offset_text = callback.data.split(":")
        offset = int(offset_text)
    except ValueError:
        await callback.answer("Эта страница недоступна.", show_alert=True)
        return
    if not day_exists(day) or offset < 0:
        await callback.answer("Эта страница недоступна.", show_alert=True)
        return
    page_size = local_settings.effective(callback.from_user.id).page_size   # у каждого своё
    rows = db_rows(
        "SELECT id, sent_at, author, text FROM messages WHERE day = ? ORDER BY sort_key LIMIT ? OFFSET ?",
        (day, page_size, offset),
    )
    if not rows:
        await callback.answer("Сообщений больше нет.", show_alert=True)
        return
    chat_id = callback.message.chat.id
    async with exclusive(callback.from_user.id) as free:
        if not free:
            await callback.answer("Подожди, предыдущий запрос ещё выполняется.", show_alert=True)
            return
        await callback.answer("Отправляю…")
        for row in rows:
            time = datetime.fromisoformat(row["sent_at"]).strftime("%H:%M")
            body = f"{row['author']} · {time}\n{row['text'] or ''}"
            for content in split_for_telegram(body):
                if content:
                    await retry_telegram(lambda content=content: bot.send_message(chat_id, content))
            problems = []
            for relative_path, kind in attachment_rows(row["id"]):
                problem = await deliver_attachment(bot, chat_id, relative_path, kind)
                if problem:
                    problems.append(problem)
            if problems:
                await retry_telegram(lambda text="\n".join(problems): bot.send_message(chat_id, text))
        next_offset = offset + len(rows)
        total = day_count(day)
        controls: list[InlineKeyboardButton] = []
        if offset:
            controls.append(InlineKeyboardButton(text="‹ Предыдущие", callback_data=f"read:{day}:{max(0, offset - page_size)}"))
        if next_offset < total:
            controls.append(InlineKeyboardButton(text="Следующие ›", callback_data=f"read:{day}:{next_offset}"))
            footer = f"Показано {next_offset} из {total}."
        else:
            footer = f"Это всё за {human_day(day)}."
        keyboard = [controls] if controls else []
        if next_offset >= total:
            next_day = neighbour_day(day, True)
            if next_day:
                keyboard.append([InlineKeyboardButton(text=f"Читать следующий день ({human_day(next_day)}) ›", callback_data=f"read:{next_day}:0")])
        keyboard.append([InlineKeyboardButton(text="📅 К дню", callback_data=f"day:{day}")])
        await retry_telegram(lambda: bot.send_message(chat_id, footer, reply_markup=InlineKeyboardMarkup(inline_keyboard=keyboard)))


@private_router.callback_query(F.data.startswith("shots:"))
async def send_screenshots(callback: CallbackQuery, bot: Bot) -> None:
    day = callback.data.split(":", 1)[1]
    if not day_exists(day):
        await callback.answer("Эта дата недоступна.", show_alert=True)
        return
    chat_id = callback.message.chat.id
    async with exclusive(callback.from_user.id) as free:
        if not free:
            await callback.answer("Подожди, предыдущий запрос ещё выполняется.", show_alert=True)
            return
        await callback.answer("Готовлю скриншоты…")
        temporary_dir = Path(tempfile.mkdtemp(prefix="archive-shots-"))
        try:
            root = export_roots() or export_paths.ExportRoots(Path("."))
            owner = local_settings.resolve_perspective(callback.from_user.id, meta("first_author")) or None   # справа — те, от чьего лица смотрит этот человек
            paths = await asyncio.to_thread(render_day_screenshots, config.DATABASE_PATH, root, day, temporary_dir, owner)
            if not paths:
                await retry_telegram(lambda: bot.send_message(chat_id, "За эту дату нет сообщений для снимка."))
                return
            await retry_telegram(lambda: bot.send_message(chat_id, f"Скриншоты за {human_day(day)}: {len(paths)} {plural(len(paths), ('страница', 'страницы', 'страниц'))}"))
            for start_index in range(0, len(paths), 10):   # альбомами по 10 — быстрее и аккуратнее
                chunk = paths[start_index:start_index + 10]
                if len(chunk) == 1:
                    await retry_telegram(lambda: bot.send_photo(chat_id, FSInputFile(chunk[0])))
                else:
                    media = [InputMediaPhoto(media=FSInputFile(path)) for path in chunk]
                    await retry_telegram(lambda media=media: bot.send_media_group(chat_id, media))
        finally:
            shutil.rmtree(temporary_dir, ignore_errors=True)


# ----------------------------------------------------------------------------
# Чужие
# ----------------------------------------------------------------------------

@fallback_router.message()
async def deny_message(message: Message) -> None:
    user_id = message.from_user.id if message.from_user else "?"
    await message.answer(f"Нет доступа к этому архиву. Ваш ID: {user_id} — его можно передать владельцу бота.")


@fallback_router.callback_query()
async def deny_callback(callback: CallbackQuery) -> None:
    await callback.answer("Нет доступа.", show_alert=True)


# ----------------------------------------------------------------------------
# Запуск
# ----------------------------------------------------------------------------

BOT_COMMANDS = [
    BotCommand(command="start", description="Открыть архив"),
    BotCommand(command="dates", description="Календарь"),
    BotCommand(command="find", description="Поиск: /find слово"),
    BotCommand(command="random", description="Случайный день"),
    BotCommand(command="today", description="В этот день в прошлом"),
    BotCommand(command="stats", description="Статистика архива"),
    BotCommand(command="settings", description="Мои настройки"),
    BotCommand(command="id", description="Узнать свой Telegram ID"),
]


def check_configuration() -> list[str]:
    problems = list(config.CONFIG_ERRORS)
    if not config.TOKEN:
        problems.append(f"Не задан BOT_TOKEN. Откройте {config.CONFIG_PATH} или запустите «1_Установить.bat».")
    if not config.ALLOWED_USER_IDS and not config.CONFIG_ERRORS:
        problems.append("Не задан ALLOWED_USER_IDS — впишите свой числовой Telegram ID в настройки.")
    if not config.DATABASE_PATH.is_file():
        problems.append("Нет индекса переписки. Запустите «2_Обновить_переписку.bat».")
    elif not meta("schema_version").isdigit() or int(meta("schema_version")) < 3:
        problems.append("Индекс создан старой версией бота. Запустите «2_Обновить_переписку.bat».")
    return problems


async def main() -> None:
    problems = check_configuration()
    if problems:
        for problem in problems:
            log.error(problem)
        sys.exit(2)   # 2 = ошибка настроек: трей не будет перезапускать бота по кругу
    mutex = acquire_instance_mutex()
    web_server = None
    update_task = None
    bot = Bot(config.TOKEN, default=DefaultBotProperties(protect_content=config.PROTECT_CONTENT))
    bot.session.middleware(ProtectContentMiddleware())
    dispatcher = Dispatcher()
    dispatcher.include_router(public_router)
    dispatcher.include_router(private_router)
    dispatcher.include_router(fallback_router)
    try:
        try:
            await bot.set_my_commands(BOT_COMMANDS)
        except TelegramAPIError as error:
            log.warning("Не удалось обновить меню команд: %s", error)
        if config.WEBAPP_URL:
            try:
                web_server = webapp_server.start_server(config.WEBAPP_PORT)
            except OSError as error:
                log.error("Приложение не запущено: порт %d занят или недоступен (%s). Бот продолжит работать кнопками.", config.WEBAPP_PORT, error)
        if web_server is not None:
            for user_id in config.ALLOWED_USER_IDS:   # кнопка «Архив» рядом с полем ввода
                try:
                    await bot.set_chat_menu_button(chat_id=user_id, menu_button=MenuButtonWebApp(text=config.WEBAPP_BUTTON_TEXT, web_app=WebAppInfo(url=config.WEBAPP_URL)))
                except TelegramAPIError as error:
                    log.warning("Не удалось поставить кнопку приложения для %s: %s", user_id, error)
        log.info("Бот запущен. Разрешённых пользователей: %d", len(config.ALLOWED_USER_IDS))
        update_task = asyncio.create_task(updater.monitor(bot), name="update-monitor")
        await dispatcher.start_polling(bot, allowed_updates=dispatcher.resolve_used_update_types())
    finally:
        if update_task is not None:
            update_task.cancel()
        if web_server is not None:
            web_server.shutdown()
        await bot.session.close()
        if mutex is not None:
            import ctypes
            ctypes.windll.kernel32.CloseHandle(mutex)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", stream=sys.stderr)
    try:
        asyncio.run(main())
    except BotAlreadyRunning:
        pass
