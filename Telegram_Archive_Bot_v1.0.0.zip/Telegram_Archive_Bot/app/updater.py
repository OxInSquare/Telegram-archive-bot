"""Проверка обновлений на GitHub: когда в репозитории выходит новый релиз, главный пользователь получает сообщение.

Репозиторий и период проверки зашиты в код (REPO, CHECK_HOURS) и одинаковы у всех: пользователь их не меняет.
Берётся последний релиз (Releases), а если релизов нет — последний тег.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import sys
import urllib.error
import urllib.request

import config

log = logging.getLogger("updater")
STATE_PATH = config.DATA_DIR / "update_state.json"
REPO = "OxInSquare/Telegram-archive-bot"
CHECK_HOURS = 24
FIRST_CHECK_DELAY = 60   # секунд после запуска бота


def version_tuple(value: str) -> tuple[int, ...] | None:
    match = re.search(r"\d+(?:\.\d+)*", value or "")
    return tuple(int(part) for part in match.group(0).split(".")) if match else None


def is_newer(latest: tuple[int, ...], current: tuple[int, ...]) -> bool:
    size = max(len(latest), len(current))
    return latest + (0,) * (size - len(latest)) > current + (0,) * (size - len(current))


def _get(url: str) -> object:
    request = urllib.request.Request(url, headers={
        "Accept": "application/vnd.github+json",
        "User-Agent": f"TelegramArchiveBot/{config.APP_VERSION}",
        "X-GitHub-Api-Version": "2022-11-28",
    })
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.loads(response.read().decode("utf-8"))


def fetch_latest(repo: str) -> dict | None:
    """{'tag', 'title', 'url', 'notes'} последнего релиза/тега или None, если в репозитории их нет.
    Исключения сети и HTTP (в т.ч. 404 «нет такого репозитория») пробрасываются."""
    try:
        release = _get(f"https://api.github.com/repos/{repo}/releases/latest")
        if isinstance(release, dict) and release.get("tag_name"):
            tag = str(release["tag_name"]).strip()
            return {"tag": tag, "title": str(release.get("name") or tag).strip(),
                    "url": str(release.get("html_url") or f"https://github.com/{repo}/releases").strip(),
                    "notes": str(release.get("body") or "").strip()}
    except urllib.error.HTTPError as error:
        if error.code != 404:
            raise
    tags = _get(f"https://api.github.com/repos/{repo}/tags?per_page=30")
    best = None
    for item in tags if isinstance(tags, list) else []:
        number = version_tuple(str(item.get("name", "")))
        if number and (best is None or is_newer(number, best[0])):
            best = (number, str(item["name"]))
    if best is None:
        return None
    return {"tag": best[1], "title": best[1], "url": f"https://github.com/{repo}/releases/tag/{best[1]}", "notes": ""}


def newer_release(repo: str) -> tuple[dict | None, bool]:
    """(последний релиз, он новее текущей версии?)"""
    latest = fetch_latest(repo)
    if latest is None:
        return None, False
    number, current = version_tuple(latest["tag"]), version_tuple(config.APP_VERSION)
    return latest, bool(number and current and is_newer(number, current))


def load_state() -> dict:
    try:
        data = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_state(state: dict) -> None:
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    temporary = STATE_PATH.with_suffix(".tmp")
    temporary.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
    temporary.replace(STATE_PATH)


def message_text(release: dict) -> str:
    lines = [f"🆕 Вышла новая версия архив-бота: {release['title']}", f"Сейчас у вас: {config.APP_VERSION}"]
    notes = release["notes"]
    if notes:
        lines += ["", notes[:700] + ("…" if len(notes) > 700 else "")]
    lines += ["", f"Скачать: {release['url']}"]
    return "\n".join(lines)


async def monitor(bot) -> None:
    """Фоновая задача бота: раз в CHECK_HOURS часов смотрит GitHub и пишет главному пользователю."""
    from aiogram.exceptions import TelegramAPIError
    import local_settings

    repo = REPO
    await asyncio.sleep(FIRST_CHECK_DELAY)
    while True:
        try:
            release, newer = await asyncio.to_thread(newer_release, repo)
            admin = local_settings.admin_id()
            if release and newer and admin and load_state().get("notified") != release["tag"]:
                await bot.send_message(admin, message_text(release), disable_web_page_preview=True)
                save_state({"notified": release["tag"]})   # только после успешной отправки: иначе повторим в следующий раз
                log.info("Главному пользователю отправлено уведомление об обновлении %s.", release["tag"])
        except asyncio.CancelledError:
            raise
        except (urllib.error.URLError, TimeoutError, OSError, ValueError, TelegramAPIError) as error:
            log.warning("Проверка обновлений не удалась: %s", error)
        except Exception:
            log.exception("Проверка обновлений: непредвиденная ошибка")
        await asyncio.sleep(CHECK_HOURS * 3600)
