"""Обновление переписки: новый экспорт → новый индекс (бот останавливается и запускается сам)."""

from __future__ import annotations

import sys

import config
import import_export
import manage
from setup_wizard import get_export_dir


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    print("=== Обновление переписки ===\n")
    print("Сначала заново экспортируйте чат в Telegram Desktop (формат HTML), затем выберите новую папку.\n")
    try:
        if not config.CONFIG_PATH.is_file():
            print("✖ Бот ещё не установлен. Сначала запустите 1_Установить.bat")
            return
        export_dir = get_export_dir()
        was_running, _ = manage.status()
        if was_running:
            print("Останавливаю бота на время обновления...")
            manage.stop()
        extras = import_export.load_extra_sources()
        if extras:
            print(f"Подключено дополнительных папок с новыми частями: {len(extras)} (они тоже будут учтены).")
        print("Индексирую...")
        import_export.run_indexing(export_dir, config.DATABASE_PATH)
        if was_running:
            manage.start()
        print("\n✅ Готово. Бот увидит новые сообщения сразу.")
    except (KeyboardInterrupt, EOFError):
        print("\nОтменено.")
    except Exception as error:
        print(f"\n✖ Ошибка: {error}")
        if "was_running" in locals() and was_running:
            manage.start()
    input("\nНажмите Enter, чтобы закрыть окно...")


if __name__ == "__main__":
    main()
