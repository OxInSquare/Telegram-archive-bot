(() => {
  "use strict";
  const tg = window.Telegram && window.Telegram.WebApp;
  const $ = (id) => document.getElementById(id);
  const state = {
    token: "", info: null, owner: "", protect: false,
    hasBefore: false, hasAfter: false, loading: false, highlight: [],
    firstKey: null, lastKey: null, anchorUntil: 0, anchorEl: null,
    search: { offset: 0, total: 0, terms: [] },
    media: { kind: "", tabs: [], offset: 0, seq: 0 },
    cal: { month: "", months: [] },
    viewerKey: null,
  };

  // ------------------------------------------------------------ утилиты
  const esc = (s) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const reEsc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const timeOf = (iso) => iso.slice(11, 16);
  const dayLabel = (day) => new Date(day + "T12:00:00").toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" });
  const shortDay = (day) => day.slice(8, 10) + "." + day.slice(5, 7) + "." + day.slice(0, 4);
  const withToken = (url) => url + (url.includes("?") ? "&" : "?") + "t=" + encodeURIComponent(state.token);
  const mediaUrl = (id) => withToken("/media/" + id);
  const thumbUrl = (id, w) => withToken("/thumb/" + id + "?w=" + (w || 640));
  const KIND_NAME = { document: "файл", voice: "голосовое", video: "видео", photo: "фото", animation: "GIF", video_note: "кружок", sticker: "стикер" };
  const SVG_PLAY = '<svg class="p" viewBox="0 0 24 24"><path d="M7 4.5v15l13-7.5z"/></svg>';
  const SVG_PAUSE = '<svg viewBox="0 0 24 24"><path d="M6.5 4.5h4v15h-4zM13.5 4.5h4v15h-4z"/></svg>';
  const SVG_FILE = '<svg viewBox="0 0 24 24"><path d="M7 3h7l5 5v13H7zM14 3v5h5"/></svg>';
  const SVG_STICKER = '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M8.5 14c1 1.6 2.2 2.3 3.5 2.3s2.5-.7 3.5-2.3M9 9.5h.01M15 9.5h.01"/></svg>';

  const fmtSize = (n) => !n ? "" : n < 1024 ? n + " Б" : n < 1048576 ? Math.round(n / 1024) + " КБ" : (n / 1048576).toFixed(n < 10485760 ? 1 : 0) + " МБ";
  const extOf = (name) => { const i = name.lastIndexOf("."); return i > 0 ? name.slice(i + 1, i + 5).toUpperCase() : ""; };

  const SVG_PINMARK = '<svg class="pinmark" viewBox="0 0 24 24"><path d="M9 3h6l-1 6 3.5 3.5v1.5H6.5v-1.5L10 9zM12 14v7"/></svg>';

  function applyTheme() {
    if (!tg) return;
    document.documentElement.dataset.theme = tg.colorScheme === "light" ? "light" : "dark";
    const p = tg.themeParams || {}, root = document.documentElement.style;
    if (p.link_color) root.setProperty("--link", p.link_color);
  }

  function gate(text) { const g = $("gate"); g.textContent = text; g.classList.remove("hidden"); }

  // ------------------------------------------------------------ сеть
  async function authenticate() {
    const initData = tg && tg.initData;
    if (!initData) throw new Error("no-telegram");
    const r = await fetch("/api/auth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ initData }) });
    if (r.status === 403) throw new Error("denied");
    if (!r.ok) throw new Error("auth-failed");
    state.token = (await r.json()).token;
  }

  async function api(path, params, retried) {
    const qs = new URLSearchParams(params || {}).toString();
    const r = await fetch(path + (qs ? "?" + qs : ""), { headers: { Authorization: "Bearer " + state.token } });
    if (r.status === 401 && !retried) { await authenticate(); return api(path, params, true); }
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || "Ошибка " + r.status);
    return r.json();
  }

  // ------------------------------------------------------------ текст
  function renderText(text, terms) {
    const parts = [];
    let last = 0;
    for (const m of text.matchAll(/https?:\/\/[^\s<>"')]+/g)) {
      parts.push({ t: text.slice(last, m.index) });
      parts.push({ url: m[0] });
      last = m.index + m[0].length;
    }
    parts.push({ t: text.slice(last) });
    const re = terms && terms.length ? new RegExp("(" + terms.map((x) => reEsc(esc(x))).join("|") + ")", "giu") : null;
    return parts.map((p) => {
      if (p.url) return `<a href="${esc(p.url)}" data-link>${esc(p.url)}</a>`;
      const safe = esc(p.t);
      return re ? safe.replace(re, "<mark>$1</mark>") : safe;
    }).join("");
  }

  // ------------------------------------------------------------ голосовые
  let playing = null;
  const fmtTime = (s) => (isFinite(s) ? Math.floor(s / 60) + ":" + String(Math.floor(s % 60)).padStart(2, "0") : "0:00");
  const metaObserver = "IntersectionObserver" in window ? new IntersectionObserver((entries) => {
    for (const e of entries) if (e.isIntersecting) { e.target._load && e.target._load(); metaObserver.unobserve(e.target); }
  }, { rootMargin: "300px" }) : null;

  function voiceEl(a) {
    const box = document.createElement("div");
    box.className = "voice";
    const btn = document.createElement("button");
    btn.className = "vbtn"; btn.innerHTML = SVG_PLAY; btn.setAttribute("aria-label", "Воспроизвести");
    const col = document.createElement("div"); col.className = "vcol";
    const wave = document.createElement("div"); wave.className = "wave";
    const bars = [];
    let seed = (a.id * 2654435761) >>> 0;   // у каждого голосового своя, но всегда одинаковая «волна»
    for (let i = 0; i < 38; i++) {
      seed = (seed * 1664525 + 1013904223) >>> 0;
      const smooth = 0.5 + 0.5 * Math.sin(i / 3.1 + (a.id % 7));
      const h = 18 + Math.round(((seed >>> 8) % 100) * 0.55 * (0.45 + 0.55 * smooth));
      const bar = document.createElement("i"); bar.style.height = Math.min(100, h) + "%";
      bars.push(bar); wave.appendChild(bar);
    }
    const time = document.createElement("div"); time.className = "vtime"; time.textContent = "0:00";
    col.append(wave, time); box.append(btn, col);

    const audio = new Audio();
    audio.preload = "none"; audio.src = mediaUrl(a.id);
    box._load = () => { if (audio.preload === "none") { audio.preload = "metadata"; audio.load(); } };
    if (metaObserver) metaObserver.observe(box);
    const paint = () => {
      const ratio = audio.duration ? audio.currentTime / audio.duration : 0;
      const on = Math.round(ratio * bars.length);
      bars.forEach((b, i) => b.classList.toggle("on", i < on));
    };
    const showTotal = () => { time.textContent = fmtTime(audio.duration); };
    audio.addEventListener("loadedmetadata", showTotal);
    audio.addEventListener("timeupdate", () => { paint(); time.textContent = fmtTime(audio.currentTime); });
    audio.addEventListener("pause", () => { btn.innerHTML = SVG_PLAY; });
    audio.addEventListener("play", () => { btn.innerHTML = SVG_PAUSE; });
    audio.addEventListener("ended", () => { audio.currentTime = 0; paint(); showTotal(); });
    audio.addEventListener("error", () => { time.textContent = "не воспроизводится"; });
    btn.addEventListener("click", () => {
      if (audio.paused) {
        if (playing && playing !== audio) playing.pause();
        playing = audio; audio.play().catch(() => { time.textContent = "не воспроизводится"; });
      } else audio.pause();
    });
    wave.addEventListener("click", (e) => {
      if (!audio.duration) return;
      const r = wave.getBoundingClientRect();
      audio.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * audio.duration;
      paint();
    });
    return box;
  }

  // ------------------------------------------------------------ сообщения
  function attachmentEl(a) {
    const box = document.createElement("div");
    box.className = "att " + a.kind;
    const ext = (a.name.split(".").pop() || "").toLowerCase();
    if (!a.exists) {
      box.className = "att";
      box.innerHTML = `<div class="missing">${esc(KIND_NAME[a.kind] || "вложение")} «${esc(a.name)}» не сохранено в экспорте</div>`;
      return box;
    }
    if (a.kind === "photo" || (a.kind === "sticker" && ["webp", "png", "jpg"].includes(ext))) {
      const img = document.createElement("img");
      img.loading = "lazy"; img.alt = ""; img.draggable = false;
      img.src = a.kind === "photo" ? thumbUrl(a.id, 640) : mediaUrl(a.id);
      if (a.kind === "photo") img.addEventListener("click", () => openViewer(a));
      box.appendChild(img);
    } else if (a.kind === "video" || a.kind === "video_note") {
      const v = document.createElement("video");
      v.src = mediaUrl(a.id) + "#t=0.1"; v.controls = true; v.preload = "metadata"; v.playsInline = true;
      v.setAttribute("controlslist", "nodownload noplaybackrate"); v.disablePictureInPicture = true;
      box.appendChild(v);
    } else if (a.kind === "animation" || (a.kind === "sticker" && ext === "webm")) {
      if (ext === "gif") {
        const img = document.createElement("img"); img.src = mediaUrl(a.id); img.loading = "lazy"; box.appendChild(img);
      } else {
        const v = document.createElement("video");
        v.src = mediaUrl(a.id); v.autoplay = true; v.loop = true; v.muted = true; v.playsInline = true; v.preload = "metadata";
        v.addEventListener("click", () => openViewer(a));
        box.appendChild(v);
      }
    } else if (a.kind === "voice") {
      box.className = "att";
      box.appendChild(voiceEl(a));
    } else if (a.kind === "sticker") {
      box.className = "att";
      box.innerHTML = `<span class="chip">${SVG_STICKER}Анимированный стикер</span>`;
    } else {
      box.className = "att";
      const link = document.createElement("a");
      link.className = "file";
      link.href = state.protect ? "#" : mediaUrl(a.id) + "&download=1";
      link.target = "_blank";
      link.innerHTML = `<span class="ico">${SVG_FILE}</span><span class="nm">${esc(a.name)}</span>`;
      if (state.protect) link.addEventListener("click", (e) => e.preventDefault());
      box.appendChild(link);
    }
    return box;
  }

  function messageEl(m) {
    const el = document.createElement("div");
    el.className = "msg" + (m.author === state.owner ? " own" : "");
    el.dataset.key = m.sort_key; el.dataset.day = m.day; el.dataset.author = m.author; el.dataset.id = m.id;
    if (m.pinned) el.classList.add("pinned");
    let html = `<div class="who">${esc(m.author)}</div>`;
    if (m.reply) html += `<div class="reply" data-reply="${m.reply.sort_key}"><b>${esc(m.reply.author)}</b><span>${esc(m.reply.text || "вложение")}</span></div>`;
    el.innerHTML = html;
    for (const a of m.attachments) el.appendChild(attachmentEl(a));
    const time = document.createElement("span");
    time.className = "time"; time.textContent = timeOf(m.sent_at);
    if (m.pinned) time.insertAdjacentHTML("afterbegin", SVG_PINMARK);
    if (m.text) {
      const t = document.createElement("div");
      t.className = "txt"; t.innerHTML = renderText(m.text, state.highlight);
      t.appendChild(time);          // время — в правом нижнем углу последней строки, как в Telegram
      el.appendChild(t);
    } else {
      time.classList.add("solo");
      if (m.attachments.some((a) => a.kind === "voice")) el.classList.add("hasvoice");
      el.appendChild(time);
    }
    return el;
  }

  function daySep(day) {
    const d = document.createElement("div");
    d.className = "daysep"; d.dataset.sepday = day; d.textContent = dayLabel(day);
    return d;
  }

  function fragmentFor(messages, previousDay) {
    const frag = document.createDocumentFragment();
    let prev = previousDay;
    for (const m of messages) {
      if (m.day !== prev) frag.appendChild(daySep(m.day));
      frag.appendChild(messageEl(m));
      prev = m.day;
    }
    return frag;
  }

  // «хвостик» пузыря — только у последнего сообщения в серии одного автора
  function restyle() {
    let prev = null;
    for (const el of $("messages").children) {
      if (!el.classList.contains("msg")) { if (prev) prev.classList.add("tail"); prev = null; continue; }
      const same = prev && prev.dataset.author === el.dataset.author;
      el.classList.toggle("start", !same);
      if (prev) prev.classList.toggle("tail", !same);
      prev = el;
    }
    if (prev) prev.classList.add("tail");
  }

  const lastDay = () => { const l = $("messages").lastElementChild; return l ? (l.dataset.day || l.dataset.sepday) : null; };

  // ------------------------------------------------------------ лента
  function setNotes() {
    $("top-note").textContent = state.hasBefore ? "" : "Начало переписки";
    $("bottom-note").textContent = "";
    $("to-bottom").classList.toggle("hidden", !state.hasAfter);
  }

  function trackRange(res) {
    if (!res.messages.length) return;
    state.firstKey = state.firstKey === null ? res.messages[0].sort_key : Math.min(state.firstKey, res.messages[0].sort_key);
    state.lastKey = Math.max(state.lastKey === null ? -1 : state.lastKey, res.messages[res.messages.length - 1].sort_key);
  }

  async function loadLatest() {
    clearSelection();
    state.loading = true;
    try {
      const res = await api("/api/messages", { limit: 50 });
      $("messages").replaceChildren(fragmentFor(res.messages, null));
      restyle();
      state.firstKey = state.lastKey = null; trackRange(res);
      state.hasBefore = res.has_more_before; state.hasAfter = res.has_more_after;
      setNotes();
      $("chat").scrollTop = $("chat").scrollHeight;
      state.anchorEl = null; state.anchorUntil = Date.now() + 2000;
    } finally { state.loading = false; }
  }

  async function loadBefore() {
    if (state.loading || !state.hasBefore) return;
    state.loading = true;
    try {
      const chat = $("chat"), box = $("messages");
      const res = await api("/api/messages", { before: state.firstKey, limit: 40 });
      if (res.messages.length) {
        const firstSep = box.firstElementChild;
        const lastNew = res.messages[res.messages.length - 1].day;
        if (firstSep && firstSep.dataset.sepday === lastNew) firstSep.remove();   // тот же день продолжается
        const height = chat.scrollHeight, top = chat.scrollTop;
        box.prepend(fragmentFor(res.messages, null));
        restyle();
        chat.scrollTop = top + (chat.scrollHeight - height);
        trackRange(res);
      }
      state.hasBefore = res.has_more_before; setNotes();
    } finally { state.loading = false; }
  }

  async function loadAfter() {
    if (state.loading || !state.hasAfter) return;
    state.loading = true;
    try {
      const res = await api("/api/messages", { after: state.lastKey, limit: 40 });
      if (res.messages.length) { $("messages").appendChild(fragmentFor(res.messages, lastDay())); restyle(); trackRange(res); }
      state.hasAfter = res.has_more_after; setNotes();
    } finally { state.loading = false; }
  }

  async function renderAround(params, terms) {
    clearSelection();
    state.loading = true; state.highlight = terms || [];
    try {
      const res = await api("/api/messages", { ...params, limit: 60 });
      $("messages").replaceChildren(fragmentFor(res.messages, null));
      restyle();
      state.firstKey = state.lastKey = null; trackRange(res);
      state.hasBefore = res.has_more_before; state.hasAfter = res.has_more_after; setNotes();
      const target = $("messages").querySelector(`.msg[data-key="${res.anchor}"]`);
      if (target) {
        target.classList.add("flash");
        state.anchorEl = target; state.anchorUntil = Date.now() + 2500;
        target.scrollIntoView({ block: "center" });
      }
    } finally { state.loading = false; }
  }

  const jumpTo = (key, terms) => { closePanels(); return renderAround({ around: key }, terms); };
  const jumpToDay = (day) => { closePanels(); closeModal(); return renderAround({ day }, []); };

  function onScroll() {
    const chat = $("chat");
    if (chat.scrollTop < 400) loadBefore();
    if (chat.scrollHeight - chat.scrollTop - chat.clientHeight < 600) loadAfter();
  }

  // медиа догружаются и сдвигают вёрстку — удерживаем нужное место первые секунды
  $("messages").addEventListener("load", () => {
    if (Date.now() > state.anchorUntil) return;
    if (state.anchorEl) state.anchorEl.scrollIntoView({ block: "center" });
    else $("chat").scrollTop = $("chat").scrollHeight;
  }, true);

  $("messages").addEventListener("click", (e) => {
    const reply = e.target.closest("[data-reply]");
    if (reply) { renderAround({ around: reply.dataset.reply }, []); return; }
    const link = e.target.closest("a[data-link]");
    if (link && tg && tg.openLink) { e.preventDefault(); tg.openLink(link.href); }
  });

  // ------------------------------------------------------------ панели
  function closePanels() { document.querySelectorAll(".panel").forEach((p) => p.classList.add("hidden")); }
  function openPanel(id) { closePanels(); $(id).classList.remove("hidden"); }
  document.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", closePanels));

  // --- поиск
  function resultItem(r) {
    const el = document.createElement("div");
    el.className = "item";
    const kinds = r.kinds.length ? " · " + r.kinds.map((k) => KIND_NAME[k] || k).join(", ") : "";
    el.innerHTML = `<div class="meta"><b>${esc(r.author)}</b> · ${shortDay(r.day)} ${timeOf(r.sent_at)}${esc(kinds)}</div><div>${renderText(r.snippet, state.search.terms)}</div>`;
    el.addEventListener("click", () => jumpTo(r.sort_key, state.search.terms));
    return el;
  }

  async function runSearch(more) {
    const params = {
      q: $("q").value.trim(), from: $("f-from").value, to: $("f-to").value,
      author: $("f-author").value, kind: $("f-kind").value, order: $("f-order").value,
      offset: more ? state.search.offset : 0, limit: 30,
    };
    if (!params.q && !params.from && !params.to && !params.author && !params.kind) {
      $("search-summary").textContent = "Введите слово или выберите фильтр."; return;
    }
    $("search-summary").textContent = "Ищу…";
    try {
      const res = await api("/api/search", params);
      state.search.terms = res.terms; state.search.total = res.total;
      const list = $("search-results");
      if (!more) list.replaceChildren();
      res.results.forEach((r) => list.appendChild(resultItem(r)));
      state.search.offset = (more ? state.search.offset : 0) + res.results.length;
      $("search-summary").textContent = res.total ? `Найдено: ${res.total}` : "Ничего не найдено.";
      $("search-more").classList.toggle("hidden", state.search.offset >= res.total);
    } catch (e) { $("search-summary").textContent = e.message; }
  }

  $("btn-search").addEventListener("click", () => { openPanel("panel-search"); $("q").focus(); });
  $("q-go").addEventListener("click", () => runSearch(false));
  $("q").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.target.blur(); runSearch(false); } });
  ["f-from", "f-to", "f-author", "f-kind", "f-order"].forEach((id) => $(id).addEventListener("change", () => runSearch(false)));
  $("search-more").addEventListener("click", () => runSearch(true));

  // --- закрепление: нажмите на сообщение → «Закрепить»
  let selected = null;
  function clearSelection() { if (selected) selected.classList.remove("sel"); selected = null; $("msgbar").classList.add("hidden"); }
  function setPinnedEl(el, pinned) {
    el.classList.toggle("pinned", pinned);
    const time = el.querySelector(".time");
    if (!time) return;
    const mark = time.querySelector(".pinmark");
    if (pinned && !mark) time.insertAdjacentHTML("afterbegin", SVG_PINMARK);
    if (!pinned && mark) mark.remove();
  }
  async function sendPin(id, pinned, retried) {
    const r = await fetch("/api/pin", { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + state.token }, body: JSON.stringify({ id, pinned }) });
    if (r.status === 401 && !retried) { await authenticate(); return sendPin(id, pinned, true); }
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || "Ошибка " + r.status);
  }
  $("messages").addEventListener("click", (e) => {
    const msg = e.target.closest(".msg");
    if (!msg) return;
    if (e.target.closest("a, button, audio, video, img, .reply, .wave, .voice")) return;
    if (window.getSelection && String(window.getSelection())) return;   // выделяют текст — не мешаем
    if (selected === msg) { clearSelection(); return; }
    clearSelection();
    selected = msg; msg.classList.add("sel");
    $("pin-toggle").querySelector("span").textContent = msg.classList.contains("pinned") ? "Открепить" : "Закрепить";
    $("msgbar").classList.remove("hidden");
  });
  $("pin-cancel").addEventListener("click", clearSelection);
  $("pin-toggle").addEventListener("click", async () => {
    if (!selected) return;
    const el = selected, want = !el.classList.contains("pinned");
    try { await sendPin(el.dataset.id, want); setPinnedEl(el, want); }
    catch (err) { $("bottom-note").textContent = err.message; }
    clearSelection();
  });

  // --- закреплённые
  function pinItem(m, removable) {
    const el = document.createElement("div");
    el.className = "item";
    const kinds = m.attachments.map((a) => KIND_NAME[a.kind] || a.kind).join(", ");
    el.innerHTML = `<div class="meta"><b>${esc(m.author)}</b> · ${shortDay(m.day)} ${timeOf(m.sent_at)}</div><div>${esc((m.text || "").slice(0, 300)) || esc(kinds)}</div>`;
    if (removable) {
      const b = document.createElement("button");
      b.className = "unpin"; b.textContent = "Открепить";
      b.addEventListener("click", async (ev) => {
        ev.stopPropagation();
        try { await sendPin(m.id, false); el.remove(); const n = document.querySelector(`#messages .msg[data-id="${m.id}"]`); if (n) setPinnedEl(n, false); }
        catch (err) { $("pins-note").textContent = err.message; }
      });
      el.querySelector(".meta").prepend(b);
    }
    el.addEventListener("click", () => jumpTo(m.sort_key, []));
    return el;
  }
  $("btn-pins").addEventListener("click", async () => {
    openPanel("panel-pins");
    const list = $("pins-list"); list.replaceChildren();
    $("pins-note").textContent = "Загружаю…";
    try {
      const res = await api("/api/pins");
      $("pins-note").textContent = res.mine.length || res.exported.length ? "" : "Пока ничего не закреплено. Нажмите на любое сообщение в чате и выберите «Закрепить».";
      if (res.mine.length) {
        list.appendChild(Object.assign(document.createElement("div"), { className: "subhead", textContent: "Мои закрепы" }));
        res.mine.forEach((m) => list.appendChild(pinItem(m, true)));
      }
      if (res.exported.length) {
        list.appendChild(Object.assign(document.createElement("div"), { className: "subhead", textContent: "Закреплялись в Telegram" }));
        res.exported.forEach((m) => list.appendChild(pinItem(m, false)));
      }
    } catch (e) { $("pins-note").textContent = e.message; }
  });

  // --- медиа и файлы: вкладки строятся из того, что реально есть в экспорте
  const GRID_TABS = new Set(["visual", "animation", "sticker"]);

  function setupMedia(info) {
    const tabs = info.media_tabs || [];
    state.media.tabs = tabs;
    $("btn-media").classList.toggle("hidden", !tabs.length);   // нет ни одного файла — раздела нет вообще
    const box = $("media-tabs"); box.replaceChildren();
    for (const t of tabs) {
      const b = document.createElement("button");
      b.dataset.kind = t.key; b.textContent = t.label;
      b.appendChild(Object.assign(document.createElement("small"), { textContent: t.count }));
      box.appendChild(b);
    }
    // фильтр поиска по вложениям: только виды, которые есть
    const sel = $("f-kind");
    for (const k of Object.keys(info.kinds || {})) {
      sel.appendChild(Object.assign(document.createElement("option"), { value: k, textContent: KIND_NAME[k] || k }));
    }
    $("f-kind-label").classList.toggle("hidden", !sel.options.length || sel.options.length < 2);
  }

  function selectTab(key) {
    state.media.kind = key;
    document.querySelectorAll("#media-tabs button").forEach((x) => x.classList.toggle("on", x.dataset.kind === key));
  }

  async function loadMedia(reset) {
    const body = $("media-body"), kind = state.media.kind, seq = ++state.media.seq;
    if (reset) { state.media.offset = 0; body.replaceChildren(); }
    const grid = GRID_TABS.has(kind);
    let res;
    try { res = await api("/api/media", { kind, offset: state.media.offset, limit: grid ? 48 : 30 }); }
    catch (e) { body.textContent = e.message; return; }
    if (seq !== state.media.seq) return;   // пользователь уже переключил вкладку — ответ устарел
    body.querySelector(".more")?.remove();
    let container = body.querySelector(".grid, .stack");
    if (!container) {
      container = document.createElement("div");
      container.className = grid ? "grid" : "stack";
      body.appendChild(container);
    }
    if (!res.items.length && reset) body.innerHTML = '<div class="note">Здесь пока ничего нет.</div>';
    res.items.forEach((it) => container.appendChild(mediaItem(it)));
    state.media.offset += res.items.length;
    if (state.media.offset < res.total) {
      const more = document.createElement("button");
      more.className = "more"; more.textContent = "Показать ещё";
      more.addEventListener("click", () => loadMedia(false));
      body.appendChild(more);
    }
  }

  function metaLine(it) { return `${esc(it.author)} · ${shortDay(it.day)} ${timeOf(it.sent_at)}`; }

  function fileRow(it) {
    const row = document.createElement("div");
    row.className = "row filerow";
    const ext = extOf(it.name);
    const link = state.protect ? "" : ` href="${mediaUrl(it.id)}&download=1" target="_blank"`;
    row.innerHTML =
      `<div class="fbody"><a class="file"${link}><span class="ico">${ext ? `<b>${esc(ext)}</b>` : SVG_FILE}</span>` +
      `<span class="fcol"><span class="nm">${esc(it.name)}</span><span class="sub">${esc([fmtSize(it.size), ext].filter(Boolean).join(" · "))}</span></span></a>` +
      `<button class="goto">в чат</button></div><div class="top"><span>${metaLine(it)}</span></div>`;
    if (state.protect) row.querySelector("a.file").addEventListener("click", (e) => e.preventDefault());
    row.querySelector(".goto").addEventListener("click", () => jumpTo(it.sort_key, []));
    return row;
  }

  function mediaItem(it) {
    const asAttachment = { id: it.id, kind: it.kind, name: it.name, exists: it.exists, sort_key: it.sort_key };
    const tab = state.media.kind;
    if (GRID_TABS.has(tab)) {
      const cell = document.createElement("div");
      cell.className = "cell " + it.kind;
      const ext = (it.name.split(".").pop() || "").toLowerCase();
      if (it.kind === "photo") cell.innerHTML = `<img loading="lazy" src="${thumbUrl(it.id, 320)}" alt="">`;
      else if (it.kind === "sticker" && ext !== "webm") cell.innerHTML = `<img loading="lazy" src="${mediaUrl(it.id)}" alt="">`;
      else if (it.kind === "animation" && ext === "gif") cell.innerHTML = `<img loading="lazy" src="${mediaUrl(it.id)}" alt=""><span class="badge">GIF</span>`;
      else cell.innerHTML = `<video muted playsinline preload="metadata" src="${mediaUrl(it.id)}#t=0.1"></video>` + (it.kind === "sticker" ? "" : `<span class="badge">${esc(KIND_NAME[it.kind] || "")}</span>`);
      cell.addEventListener("click", () => openViewer(asAttachment));
      return cell;
    }
    if (tab === "document") return fileRow(it);
    const row = document.createElement("div");
    row.className = "row";
    row.innerHTML = `<div class="top"><span>${metaLine(it)}</span><button class="goto">в чат</button></div>`;
    row.querySelector(".goto").addEventListener("click", () => jumpTo(it.sort_key, []));
    row.appendChild(voiceEl(it));
    return row;
  }

  $("btn-media").addEventListener("click", () => {
    const tabs = state.media.tabs;
    if (!tabs.length) return;
    openPanel("panel-media");
    selectTab(tabs.some((t) => t.key === state.media.kind) ? state.media.kind : tabs[0].key);
    loadMedia(true);
  });
  $("media-tabs").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-kind]"); if (!b) return;
    selectTab(b.dataset.kind); loadMedia(true);
  });

  // --- просмотрщик
  function openViewer(a) {
    state.viewerKey = a.sort_key == null ? null : a.sort_key;
    const body = $("viewer-body"); body.replaceChildren();
    let el;
    if (a.kind === "video" || a.kind === "animation" || a.kind === "video_note" || a.name.toLowerCase().endsWith(".webm")) {
      el = document.createElement("video"); el.controls = true; el.autoplay = true; el.playsInline = true;
      el.setAttribute("controlslist", "nodownload"); el.disablePictureInPicture = true; el.src = mediaUrl(a.id);
    } else {
      el = document.createElement("img"); el.src = mediaUrl(a.id); el.draggable = false;
    }
    body.appendChild(el);
    $("viewer-goto").classList.toggle("hidden", state.viewerKey === null);
    $("viewer").classList.remove("hidden");
  }
  function closeViewer() { $("viewer").classList.add("hidden"); $("viewer-body").replaceChildren(); }
  $("viewer-close").addEventListener("click", closeViewer);
  $("viewer-goto").addEventListener("click", () => { const key = state.viewerKey; closeViewer(); jumpTo(key, []); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") { closeViewer(); closeModal(); closePanels(); } });

  // --- календарь
  const MONTHS_RU = ["январь", "февраль", "март", "апрель", "май", "июнь", "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь"];
  function closeModal() { $("calendar").classList.add("hidden"); }
  document.querySelector("[data-close-modal]").addEventListener("click", closeModal);
  $("calendar").addEventListener("click", (e) => { if (e.target === $("calendar")) closeModal(); });

  async function openCalendar() {
    if (!state.cal.months.length) state.cal.months = (await api("/api/months")).months;
    const select = $("cal-month");
    if (!select.options.length) {
      for (const m of state.cal.months) {
        const o = document.createElement("option");
        o.value = m.month; o.textContent = `${MONTHS_RU[+m.month.slice(5) - 1]} ${m.month.slice(0, 4)} (${m.count})`;
        select.appendChild(o);
      }
    }
    if (!state.cal.month) state.cal.month = state.cal.months[state.cal.months.length - 1].month;
    $("calendar").classList.remove("hidden");
    renderCalendar();
  }

  async function renderCalendar() {
    const month = state.cal.month, [y, mo] = month.split("-").map(Number);
    $("cal-month").value = month;
    const days = (await api("/api/calendar", { month })).days;
    const grid = $("cal-grid"); grid.replaceChildren();
    ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"].forEach((d) => grid.appendChild(Object.assign(document.createElement("div"), { className: "dow", textContent: d })));
    const offset = (new Date(y, mo - 1, 1).getDay() + 6) % 7, total = new Date(y, mo, 0).getDate();
    for (let i = 0; i < offset; i++) grid.appendChild(Object.assign(document.createElement("span"), { className: "empty" }));
    for (let d = 1; d <= total; d++) {
      const key = String(d).padStart(2, "0");
      if (days[key]) {
        const b = document.createElement("button");
        b.textContent = d; b.title = days[key] + " сообщ.";
        b.addEventListener("click", () => jumpToDay(`${month}-${key}`));
        grid.appendChild(b);
      } else grid.appendChild(Object.assign(document.createElement("span"), { className: "off", textContent: d }));
    }
  }

  const stepMonth = (delta) => {
    const list = state.cal.months.map((m) => m.month), i = list.indexOf(state.cal.month) + delta;
    if (i >= 0 && i < list.length) { state.cal.month = list[i]; renderCalendar(); }
  };
  $("btn-calendar").addEventListener("click", () => openCalendar().catch((e) => gate(e.message)));
  $("cal-prev").addEventListener("click", () => stepMonth(-1));
  $("cal-next").addEventListener("click", () => stepMonth(1));
  $("cal-month").addEventListener("change", (e) => { state.cal.month = e.target.value; renderCalendar(); });
  $("cal-latest").addEventListener("click", () => { closeModal(); state.highlight = []; loadLatest(); });
  $("cal-first").addEventListener("click", () => jumpToDay(state.info.first_day));
  $("to-bottom").addEventListener("click", () => { state.highlight = []; loadLatest(); });
  $("chat").addEventListener("scroll", onScroll, { passive: true });

  // ------------------------------------------------------------ запуск
  async function start() {
    if (tg) { tg.ready(); tg.expand(); applyTheme(); tg.onEvent && tg.onEvent("themeChanged", applyTheme); }
    try { await authenticate(); }
    catch (e) {
      gate(e.message === "no-telegram" ? "Откройте приложение через кнопку рядом с полем ввода в Telegram-боте — напрямую в браузере оно не работает."
        : e.message === "denied" ? "Нет доступа. Ваш аккаунт не в списке разрешённых."
        : "Не удалось войти. Проверьте, что бот запущен, и попробуйте ещё раз.");
      return;
    }
    try {
      state.info = await api("/api/info");
      state.owner = state.info.owner; state.protect = state.info.protect;
      document.body.classList.toggle("nonames", !state.info.show_names);   // в личной переписке имена не нужны (если не включено в настройках)
      if (state.protect) {
        document.body.classList.add("protect");
        document.addEventListener("contextmenu", (e) => e.preventDefault());
      }
      setupMedia(state.info);
      const sel = $("f-author");
      state.info.authors.forEach((a) => sel.appendChild(Object.assign(document.createElement("option"), { value: a, textContent: a })));
      await loadLatest();
    } catch (e) { gate(e.message); }
  }
  start();
})();
