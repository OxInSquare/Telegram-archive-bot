"""Строит локальный SQLite-индекс по HTML-экспорту Telegram Desktop."""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sqlite3
import sys
from contextlib import closing
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterable

from bs4 import BeautifulSoup, Tag

import config
from export_paths import ExportRoots

SCHEMA_VERSION = 3

SOURCES_PATH = config.DATA_DIR / "export_sources.json"   # дополнительные папки экспорта (новые части переписки)
ALIASES_PATH = config.DATA_DIR / "author_aliases.json"   # «новый ник -> прежний ник»: один человек под разными именами
MISMATCH_LIMIT = 0.02   # больше 2% «своих» сообщений с другим временем — это другой чат

SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE messages (
    id TEXT PRIMARY KEY,
    sent_at TEXT NOT NULL,
    day TEXT NOT NULL,
    author TEXT NOT NULL,
    text TEXT NOT NULL DEFAULT '',
    search_text TEXT NOT NULL DEFAULT '',
    sort_key INTEGER NOT NULL,
    reply_to TEXT
);
CREATE TABLE pins (
    message_id TEXT PRIMARY KEY,
    seq INTEGER NOT NULL
);
CREATE TABLE attachments (
    id INTEGER PRIMARY KEY,
    message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    relative_path TEXT NOT NULL,
    kind TEXT NOT NULL
);
CREATE INDEX idx_messages_day_sort ON messages(day, sort_key);
CREATE INDEX idx_messages_sort ON messages(sort_key);
CREATE INDEX idx_attachments_message ON attachments(message_id);
"""

TIMESTAMP_FORMATS = (
    "%d.%m.%Y %H:%M:%S UTC%z", "%d.%m.%Y %H:%M:%S",
    "%Y-%m-%d %H:%M:%S UTC%z", "%Y-%m-%d %H:%M:%S",
    "%d.%m.%Y %H:%M UTC%z", "%d.%m.%Y %H:%M",
)
_ODD_SPACES = re.compile(r"[\u00a0\u2007\u2009\u200e\u200f\u202f]+")


def export_pages(export_dir: Path) -> list[Path]:
    """messages.html, messages2.html … в том порядке, как их создал Telegram."""
    def number(path: Path) -> int:
        match = re.fullmatch(r"messages(\d*)\.html", path.name)
        return int(match.group(1) or 1) if match else 10**9

    return sorted((p for p in export_dir.glob("messages*.html") if number(p) < 10**9), key=number)


def parse_timestamp(value: str) -> datetime | None:
    # Telegram пишет, например: "11.09.2025 01:47:51 UTC+02:00".
    value = " ".join(_ODD_SPACES.sub(" ", value).split())   # неразрывные пробелы и невидимые метки в дате
    value = re.sub(r"\b(?:GMT|UTC)(?=[+-])", "UTC", value)    # новые версии Telegram пишут GMT+02:00 вместо UTC+02:00
    for fmt in TIMESTAMP_FORMATS:
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None


def own_strings(element: Tag | None) -> str:
    """Текст элемента без вложенных <span class="details"> (даты, «via @bot»)."""
    if element is None:
        return ""
    return "".join(element.find_all(string=True, recursive=False)).strip()


def element_text(element: Tag | None) -> str:
    """Текст сообщения: <br> становятся переводами строк, форматирование не рвёт слова."""
    if element is None:
        return ""
    for br in element.find_all("br"):
        br.replace_with("\n")
    for link in element.find_all("a", href=True):
        href = link["href"]
        shown = link.get_text("").strip()
        # Ссылка-слово: сохраняем адрес, иначе он потеряется (поиск и чтение).
        if href.startswith(("http://", "https://")) and shown and href.rstrip("/") != shown.rstrip("/"):
            link.append(f" ({href})")
    return element.get_text("").strip()


def attachment_kind(anchor: Tag, path: str) -> str:
    classes = set(anchor.get("class", []))
    suffix = Path(path).suffix.lower()
    normalized_path = path.lower()
    if normalized_path.startswith("round_video_messages/"):
        return "video_note"
    if normalized_path.startswith("voice_messages/"):
        return "voice"
    if normalized_path.startswith("stickers/") or suffix == ".tgs":
        return "sticker"
    if "sticker_wrap" in classes:
        return "sticker"
    if "animated_wrap" in classes:
        return "animation"
    if "photo_wrap" in classes or suffix in {".jpg", ".jpeg", ".png", ".webp"}:
        return "photo"
    if "video_message_wrap" in classes:
        return "video_note"
    if "media_video" in classes or suffix in {".mp4", ".mov", ".mkv"}:
        return "video"
    if "media_audio_file" in classes or "voice" in normalized_path or suffix in {".ogg", ".opus"}:
        return "voice"
    if suffix in {".gif", ".webm"}:
        return "animation"
    return "document"


def find_attachments(message: Tag) -> tuple[list[tuple[str, str]], str]:
    """Возвращает (файлы, заметка). Заметка — текст вложения без файла
    (геопозиция, опрос, контакт, «файл не включён в экспорт»)."""
    media = message.select_one(".media_wrap")
    if not media:
        return [], ""
    items: list[tuple[str, str]] = []
    seen: set[str] = set()
    for anchor in media.find_all("a", href=True):
        path = anchor["href"].replace("\\", "/")
        # Внешние ссылки и якоря — не файлы архива.
        if path.startswith(("#", "http://", "https://", "tg://")) or path in seen:
            continue
        seen.add(path)
        items.append((path, attachment_kind(anchor, path)))
    note = ""
    if not items:
        note = media.get_text(" · ", strip=True)
    return items, note


def pinned_target(service: Tag) -> str | None:
    """id закреплённого сообщения, если это служебная запись «… закрепил(а) сообщение»."""
    link = service.find("a", href=re.compile(r"^#go_to_"))
    if link is None:
        return None
    text = service.get_text(" ", strip=True).casefold()
    if "pinned" in text or "закреп" in text or "закріп" in text:
        return link["href"][len("#go_to_"):]
    return None


def message_parts(message: Tag) -> tuple[Tag, Tag | None, Tag | None]:
    """(тело, тело пересланного сообщения, элемент с автором)."""
    body = message.find("div", class_="body", recursive=False) or message
    forwarded = body.find("div", class_="forwarded", recursive=False)
    author = body.find("div", class_="from_name", recursive=False)
    return body, forwarded, author


_active_aliases: dict[str, str] = {}


def load_aliases() -> dict[str, str]:
    try:
        data = json.loads(ALIASES_PATH.read_text(encoding="utf-8-sig"))
        return {str(k): str(v) for k, v in data.get("aliases", {}).items() if k and v and k != v}
    except (OSError, ValueError, AttributeError):
        return {}


def save_aliases(aliases: dict[str, str]) -> None:
    ALIASES_PATH.parent.mkdir(parents=True, exist_ok=True)
    temporary = ALIASES_PATH.with_suffix(".tmp")
    temporary.write_text(json.dumps({"aliases": aliases}, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(ALIASES_PATH)


def canonical_author(name: str, aliases: dict[str, str] | None = None) -> str:
    aliases = _active_aliases if aliases is None else aliases
    for _ in range(10):   # цепочки вида А -> Б -> В; ограничение защищает от случайного цикла
        if name not in aliases:
            break
        name = aliases[name]
    return name


def add_alias(aliases: dict[str, str], source: str, target: str) -> dict[str, str]:
    """Ник source отныне считается ником target. Старые записи, ведущие в source, переводятся на target."""
    result = {k: (target if v == source else v) for k, v in aliases.items()}
    result[source] = target
    if result.get(target) == source:   # А->Б после Б->А: обратную запись убираем, цикл не нужен
        del result[target]
    return {k: v for k, v in result.items() if k != v}


def parse_message(message: Tag) -> dict | None:
    message_id = message.get("id")
    body, forwarded, author_element = message_parts(message)
    date_element = body.find("div", class_="date", recursive=False) or message.select_one(".date.details[title]")
    if not message_id or date_element is None or not date_element.get("title"):
        return None
    timestamp = parse_timestamp(date_element["title"])
    if timestamp is None:
        return None
    text_source = body.find("div", class_="text", recursive=False)
    forwarded_from = ""
    if forwarded is not None:
        forwarded_from = own_strings(forwarded.find("div", class_="from_name", recursive=False))
        if text_source is None:
            text_source = forwarded.find("div", class_="text", recursive=False)
    text = element_text(text_source)
    files, note = find_attachments(message)
    shown = text
    if forwarded_from:
        shown = f"↪ Переслано от {forwarded_from}" + (f"\n{text}" if text else "")
    if note:
        shown = f"{shown}\n📎 {note}".strip()
    reply_box = body.find("div", class_="reply_to", recursive=False)
    reply_link = reply_box.find("a", href=True) if reply_box is not None else None
    reply_to = reply_link["href"][len("#go_to_"):] if reply_link and reply_link["href"].startswith("#go_to_") else None
    return {
        "id": message_id,
        "reply_to": reply_to,
        "timestamp": timestamp,
        "author": canonical_author(config.clean_author(own_strings(author_element))),
        "text": shown,
        "search_text": text.casefold(),
        "files": files,
    }


def describe_failure(message: Tag) -> str:
    """Почему сообщение не разобралось (для отчёта: по этому видно, что не так с экспортом)."""
    if not message.get("id"):
        return "у сообщения нет номера (id): " + str(message)[:200]
    body, _, _ = message_parts(message)
    element = body.find("div", class_="date", recursive=False) or message.select_one(".date.details[title]")
    if element is None or not element.get("title"):
        return "не найдена дата сообщения. Начало блока: " + " ".join(str(message).split())[:250]
    return f"дата не распознана: «{element['title']}»"


# ----------------------------------------------------------------------------
# Дополнительные папки экспорта (новые части переписки)
# ----------------------------------------------------------------------------

class NotSameChat(ValueError):
    """В новой папке сообщения с теми же номерами, но другим временем: это другой чат."""


@dataclass
class MergeReport:
    folder: str = ""
    title: str = ""
    main_title: str = ""
    total: int = 0          # сообщений в новой папке
    duplicates: int = 0     # уже есть в архиве, пропущены
    added: int = 0          # новые
    mismatched: int = 0     # тот же номер, но другое время (пропущены)
    recovered: int = 0      # уже были, но без файлов; файлы нашлись в новой папке
    skipped: int = 0        # не удалось разобрать
    failure_example: str = ""   # пример причины, если не разобралось
    first_day: str = ""
    last_day: str = ""
    files_found: int = 0
    files_missing: int = 0

    @property
    def title_differs(self) -> bool:
        return bool(self.title and self.main_title and self.title.casefold() != self.main_title.casefold())


def load_extra_sources() -> list[Path]:
    try:
        data = json.loads(SOURCES_PATH.read_text(encoding="utf-8-sig"))
        return [Path(item["path"]) for item in data.get("extra", [])]
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return []


def save_extra_sources(folders: list[Path]) -> None:
    SOURCES_PATH.parent.mkdir(parents=True, exist_ok=True)
    data = {"extra": [{"path": str(folder)} for folder in folders]}
    temporary = SOURCES_PATH.with_suffix(".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(SOURCES_PATH)


def abs_ts(value) -> float:
    """Момент времени в секундах: сообщения из экспортов с разными часовыми поясами сравниваются честно."""
    if isinstance(value, str):
        value = datetime.fromisoformat(value)
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.timestamp()


def chat_title(soup: BeautifulSoup) -> str:
    element = soup.select_one(".page_header .text.bold")
    return " ".join(element.get_text(" ").split()) if element else ""


def read_title(export_dir: Path) -> str:
    pages = export_pages(export_dir)
    if not pages:
        return ""
    return chat_title(BeautifulSoup(pages[0].read_text(encoding="utf-8"), "html.parser"))


def merge_export(
    connection: sqlite3.Connection,
    folder: Path,
    number: int,
    roots: ExportRoots,
    pins: list[str],
    next_sequence: int,
    progress: Callable[[int, int], None] | None = None,
) -> tuple[MergeReport, int]:
    """Добавляет в индекс сообщения из дополнительной папки.

    Сверка идёт по номеру сообщения Telegram и по времени: то, что уже есть, пропускается;
    новое дописывается. Файлы остаются в своей папке (путь помечен «@номер/»), поэтому одинаковые
    имена файлов в разных экспортах не путаются. Ничего из уже имеющегося не удаляется, кроме одного
    случая: у старого сообщения нет файлов на диске, а в новой папке они есть — тогда берутся новые.
    """
    pages = export_pages(folder)
    if not pages:
        raise FileNotFoundError(f"В папке {folder} нет файлов messages*.html — это точно HTML-экспорт чата?")
    report = MergeReport(folder=str(folder))
    existing = {row[0]: abs_ts(row[1]) for row in connection.execute("SELECT id, sent_at FROM messages")}
    last = connection.execute("SELECT author FROM messages ORDER BY sort_key DESC LIMIT 1").fetchone()
    previous_author = last[0] if last else "Неизвестный автор"
    prefix = f"@{number}/"

    def place(mid: str, files: list[tuple[str, str]]) -> None:
        for relative_path, kind in files:
            connection.execute("INSERT INTO attachments(message_id, relative_path, kind) VALUES (?, ?, ?)", (mid, relative_path, kind))

    for page_number, page in enumerate(pages, start=1):
        soup = BeautifulSoup(page.read_text(encoding="utf-8"), "html.parser")
        if page_number == 1:
            report.title = chat_title(soup)
        for service in soup.select("div.message.service"):
            pinned_id = pinned_target(service)
            if pinned_id:
                pins.append(pinned_id)
        for message in soup.select("div.message.default"):
            parsed = parse_message(message)
            if parsed is None:
                report.skipped += 1
                report.failure_example = report.failure_example or describe_failure(message)
                continue
            report.total += 1
            if parsed["author"]:
                previous_author = parsed["author"]
            moment = abs_ts(parsed["timestamp"])
            mid = parsed["id"]
            files = [(prefix + path, kind) for path, kind in parsed["files"]]

            if mid in existing:
                if abs(existing[mid] - moment) >= 1:
                    report.mismatched += 1
                    continue
                report.duplicates += 1
                if files:   # у старой копии нет файлов на диске, а в новой папке есть — берём новые
                    old = connection.execute("SELECT relative_path FROM attachments WHERE message_id = ?", (mid,)).fetchall()
                    if not any(roots.resolve(row[0]) for row in old) and any(roots.resolve(path) for path, _ in files):
                        connection.execute("DELETE FROM attachments WHERE message_id = ?", (mid,))
                        place(mid, files)
                        report.recovered += 1
                continue

            timestamp = parsed["timestamp"]
            connection.execute(
                "INSERT INTO messages(id, sent_at, day, author, text, search_text, sort_key, reply_to) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (mid, timestamp.isoformat(), timestamp.date().isoformat(), previous_author, parsed["text"],
                 parsed["search_text"], next_sequence, parsed["reply_to"]),
            )
            place(mid, files)
            existing[mid] = moment
            next_sequence += 1
            report.added += 1
            day = timestamp.date().isoformat()
            report.first_day = min(report.first_day or day, day)
            report.last_day = max(report.last_day, day)
            for path, _ in files:
                if roots.resolve(path):
                    report.files_found += 1
                else:
                    report.files_missing += 1
        if progress:
            progress(page_number, len(pages))

    if report.total == 0 and report.skipped:
        raise ValueError(
            f"Не удалось разобрать ни одного сообщения из {report.skipped}: формат этого экспорта программа пока не понимает.\n"
            f"  Причина: {report.failure_example}"
        )
    overlap = report.duplicates + report.mismatched
    if report.mismatched and report.mismatched / overlap > MISMATCH_LIMIT:
        raise NotSameChat(
            f"Похоже, это другой чат: у {report.mismatched} из {overlap} сообщений номера совпали с архивом, а время нет."
        )
    return report, next_sequence


def resequence(connection: sqlite3.Connection, base: int) -> None:
    """Расставляет новые сообщения (sort_key >= base) по времени среди старых.
    Порядок старых сообщений не меняется; если всё новое позже старого, ничего не двигается."""
    rows = connection.execute("SELECT id, sent_at, sort_key FROM messages ORDER BY sort_key").fetchall()
    old = [row for row in rows if row[2] < base]
    new = sorted((row for row in rows if row[2] >= base), key=lambda row: (abs_ts(row[1]), row[2]))
    if not new:
        return
    old_times = [abs_ts(row[1]) for row in old]
    merged, position = [], 0
    for row in new:
        moment = abs_ts(row[1])
        while position < len(old) and old_times[position] <= moment:
            merged.append(old[position])
            position += 1
        merged.append(row)
    merged.extend(old[position:])
    if [row[0] for row in merged] == [row[0] for row in rows]:
        return
    connection.executemany("UPDATE messages SET sort_key = ? WHERE id = ?", [(number, row[0]) for number, row in enumerate(merged)])


def store_pins(connection: sqlite3.Connection, pinned: list[str], start: int = 0) -> None:
    for offset, pinned_id in enumerate(pinned):
        connection.execute(
            "INSERT OR REPLACE INTO pins(message_id, seq) SELECT id, ? FROM messages WHERE id = ?", (start + offset, pinned_id)
        )


def store_extra_meta(connection: sqlite3.Connection, folders: list[Path], title: str) -> None:
    mapping = {str(number): str(folder) for number, folder in enumerate(folders, start=1)}
    connection.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('extra_exports', ?)", (json.dumps(mapping, ensure_ascii=False),))
    if title:
        connection.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('chat_title', ?)", (title,))
    connection.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('indexed_at', ?)", (datetime.now().isoformat(timespec="seconds"),))


def merge_into_copy(database_path: Path, folder: Path, progress: Callable[[int, int], None] | None = None) -> tuple[MergeReport, Path]:
    """Пробное слияние: копия индекса + новая папка. Настоящий индекс не трогается.
    Результат можно принять (apply_merge) или выбросить (удалить файл копии)."""
    folder = folder.resolve()
    _active_aliases.clear()
    _active_aliases.update(load_aliases())
    extras = load_extra_sources()
    main_dir = stored_export_dir(database_path)
    if main_dir is None:
        raise ValueError("Сначала нужен основной индекс: выполните 2_Обновить_переписку.bat.")
    if folder == main_dir.resolve() or folder in [e.resolve() for e in extras]:
        raise ValueError("Эта папка уже подключена.")
    with closing(sqlite3.connect(database_path)) as connection:
        row = connection.execute("SELECT value FROM meta WHERE key = 'extra_exports'").fetchone()
    known = json.loads(row[0]) if row and row[0] else {}
    if len(known) != len(extras):
        raise ValueError("Индекс не совпадает со списком подключённых папок. Сначала выполните 2_Обновить_переписку.bat.")

    temporary = database_path.with_name(database_path.name + ".merge")
    temporary.unlink(missing_ok=True)
    shutil.copy2(database_path, temporary)
    connection = sqlite3.connect(temporary)
    try:
        number = len(extras) + 1
        folders = [*extras, folder]
        roots = ExportRoots(main_dir, {n: p for n, p in enumerate(folders, start=1)})
        base = (connection.execute("SELECT MAX(sort_key) FROM messages").fetchone()[0] or -1) + 1
        pins_before = (connection.execute("SELECT MAX(seq) FROM pins").fetchone()[0] or -1) + 1
        pinned: list[str] = []
        report, _ = merge_export(connection, folder, number, roots, pinned, base, progress)
        report.main_title = read_title(main_dir)
        resequence(connection, base)
        store_pins(connection, pinned, pins_before)
        store_extra_meta(connection, folders, report.main_title)
        connection.commit()
    except BaseException:
        connection.close()
        temporary.unlink(missing_ok=True)
        raise
    connection.close()
    return report, temporary


def author_counts(database_path: Path) -> list[tuple[str, int]]:
    """Кто писал и сколько сообщений, по убыванию."""
    with closing(sqlite3.connect(f"{database_path.as_uri()}?mode=ro", uri=True)) as connection:
        return [(row[0], row[1]) for row in connection.execute("SELECT author, COUNT(*) FROM messages GROUP BY author ORDER BY COUNT(*) DESC")]


def new_authors(database_path: Path, merged: Path) -> list[tuple[str, int]]:
    """Авторы, которые появились в пробном слиянии, но которых не было в архиве."""
    known = {name for name, _ in author_counts(database_path)}
    return [(name, count) for name, count in author_counts(merged) if name not in known]


def rename_author(connection: sqlite3.Connection, source: str, target: str) -> int:
    changed = connection.execute("UPDATE messages SET author = ? WHERE author = ?", (target, source)).rowcount
    connection.execute("UPDATE meta SET value = ? WHERE key = 'first_author' AND value = ?", (target, source))
    return changed


def merge_authors(database_path: Path, source: str, target: str) -> int:
    """Объединяет двух авторов в существующем архиве: source становится target.
    Пара запоминается, поэтому при любой пересборке индекса люди снова не разъедутся."""
    if source == target:
        raise ValueError("Нужно выбрать двух разных людей.")
    save_aliases(add_alias(load_aliases(), source, target))   # сначала запоминаем: даже если база не обновится, пересборка применит
    with closing(sqlite3.connect(database_path, timeout=30)) as connection:
        changed = rename_author(connection, source, target)
        connection.commit()
    return changed


def merge_authors_in_copy(merged: Path, source: str, target: str) -> None:
    with closing(sqlite3.connect(merged)) as connection:
        rename_author(connection, source, target)
        connection.commit()


def apply_merge(database_path: Path, merged: Path, folder: Path, aliases: dict[str, str] | None = None) -> None:
    """Принимает пробное слияние: список папок сохраняется, индекс подменяется."""
    folders = load_extra_sources()
    old_aliases = load_aliases()
    save_extra_sources([*folders, folder.resolve()])   # сначала список: иначе обычное обновление потеряло бы эту папку
    if aliases:
        save_aliases({**old_aliases, **aliases})
    try:
        os.replace(merged, database_path)
    except OSError as error:
        save_extra_sources(folders)
        save_aliases(old_aliases)
        merged.unlink(missing_ok=True)
        raise PermissionError("Не удалось заменить индекс: файл занят. Остановите бота и повторите.") from error


def rebuild_index(
    export_dir: Path,
    database_path: Path,
    progress: Callable[[int, int], None] | None = None,
    extras: list[Path] | None = None,
) -> tuple[int, int]:
    """Строит индекс во временном файле и подменяет старый только при успехе.
    Дополнительные папки (новые части переписки) берутся из списка и сверяются с основной."""
    pages = export_pages(export_dir)
    if not pages:
        raise FileNotFoundError("В папке нет файлов messages*.html — это точно HTML-экспорт чата?")
    extras = load_extra_sources() if extras is None else extras
    _active_aliases.clear()
    _active_aliases.update(load_aliases())
    for folder in extras:   # без папки часть переписки пропала бы молча — лучше остановиться
        if not folder.is_dir():
            raise FileNotFoundError(
                f"Подключённая папка недоступна: {folder}. Верните её на место или уберите из списка "
                "(3_Добавить_новую_часть.bat), иначе часть переписки пропадёт из индекса."
            )
    extra_pages = sum(len(export_pages(folder)) for folder in extras)
    total_pages = len(pages) + extra_pages

    database_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = database_path.with_name(database_path.name + ".new")
    temporary.unlink(missing_ok=True)
    connection = sqlite3.connect(temporary)
    try:
        connection.executescript(SCHEMA)
        message_count = attachment_count = skipped = 0
        previous_author = "Неизвестный автор"
        first_author = ""
        pins: list[str] = []
        sequence = 0

        for page_number, page in enumerate(pages, start=1):
            soup = BeautifulSoup(page.read_text(encoding="utf-8"), "html.parser")
            for service in soup.select("div.message.service"):
                pinned_id = pinned_target(service)
                if pinned_id:
                    pins.append(pinned_id)
            for message in soup.select("div.message.default"):
                parsed = parse_message(message)
                if parsed is None:
                    skipped += 1
                    continue
                if parsed["author"]:
                    previous_author = parsed["author"]
                    first_author = first_author or previous_author
                timestamp = parsed["timestamp"]
                connection.execute(
                    "INSERT OR REPLACE INTO messages(id, sent_at, day, author, text, search_text, sort_key, reply_to) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        parsed["id"], timestamp.isoformat(), timestamp.date().isoformat(),
                        previous_author, parsed["text"], parsed["search_text"], sequence, parsed["reply_to"],
                    ),
                )
                sequence += 1
                message_count += 1
                for relative_path, kind in parsed["files"]:
                    connection.execute(
                        "INSERT INTO attachments(message_id, relative_path, kind) VALUES (?, ?, ?)",
                        (parsed["id"], relative_path, kind),
                    )
                    attachment_count += 1
            if progress:
                progress(page_number, total_pages)

        if message_count == 0:
            raise ValueError("В экспорте не найдено ни одного сообщения.")
        if extras:
            roots = ExportRoots(export_dir, {n: p for n, p in enumerate(extras, start=1)})
            base = sequence
            done = len(pages)
            for number, folder in enumerate(extras, start=1):
                offset = done

                def shifted(page_done: int, _total: int, offset: int = offset) -> None:
                    if progress:
                        progress(offset + page_done, total_pages)

                report, sequence = merge_export(connection, folder, number, roots, pins, sequence, shifted)
                done += len(export_pages(folder))
            resequence(connection, base)
            message_count = connection.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
            attachment_count = connection.execute("SELECT COUNT(*) FROM attachments").fetchone()[0]
        store_pins(connection, pins)
        meta = {
            "schema_version": str(SCHEMA_VERSION),
            "export_dir": str(export_dir),
            "indexed_at": datetime.now().isoformat(timespec="seconds"),
            "first_author": first_author,
            "skipped_messages": str(skipped),
            "extra_exports": json.dumps({str(n): str(p) for n, p in enumerate(extras, start=1)}, ensure_ascii=False),
            "chat_title": read_title(export_dir),
        }
        connection.executemany("INSERT INTO meta(key, value) VALUES (?, ?)", meta.items())
        connection.commit()
        connection.execute("VACUUM")
    except BaseException:
        connection.close()
        temporary.unlink(missing_ok=True)
        raise
    connection.close()
    try:
        os.replace(temporary, database_path)
    except PermissionError as error:
        temporary.unlink(missing_ok=True)
        raise PermissionError(
            "Не удалось заменить индекс: файл занят. Остановите бота и повторите."
        ) from error
    return message_count, attachment_count


def existing_count(database_path: Path) -> int | None:
    if not database_path.is_file():
        return None
    try:
        connection = sqlite3.connect(database_path)
        try:
            return connection.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
        finally:
            connection.close()
    except sqlite3.Error:
        return None


def stored_export_dir(database_path: Path) -> Path | None:
    if not database_path.is_file():
        return None
    try:
        connection = sqlite3.connect(database_path)
        try:
            row = connection.execute("SELECT value FROM meta WHERE key = 'export_dir'").fetchone()
        finally:
            connection.close()
    except sqlite3.Error:
        return None
    return Path(row[0]) if row else None


def run_indexing(export_dir: Path, database_path: Path) -> None:
    """Индексация с понятным выводом — общая для .bat и мастера установки."""
    before = existing_count(database_path)

    def progress(done: int, total: int) -> None:
        if total > 1:
            print(f"  обработано файлов: {done} из {total}", end="\r", flush=True)

    messages, attachments = rebuild_index(export_dir, database_path, progress)
    print(" " * 50, end="\r")
    print(f"Готово: {messages} сообщений, {attachments} вложений.")
    extras = load_extra_sources()
    if extras:
        print(f"Учтено дополнительных папок с новыми частями переписки: {len(extras)}.")
    if before is not None:
        diff = messages - before
        print(f"Было {before}, стало {messages} ({'+' if diff >= 0 else ''}{diff}).")


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--export-dir", type=Path, help="папка экспорта (по умолчанию — та же, что в прошлый раз)")
    parser.add_argument("--database", type=Path, default=config.DATABASE_PATH)
    args = parser.parse_args()
    database = args.database.resolve()
    export_dir = args.export_dir or stored_export_dir(database)
    if export_dir is None:
        parser.error("Укажите --export-dir: путь к экспорту ещё не сохранён.")
    run_indexing(export_dir.resolve(), database)


if __name__ == "__main__":
    main()
