"""Где лежат файлы вложений. Одна общая логика для бота, приложения и скриншотов.

У архива есть основная папка экспорта и, возможно, дополнительные (новые части переписки,
подключённые через «3_Добавить_новую_часть.bat»). Файлы дополнительных папок никуда не копируются:
в индексе их путь помечен номером источника, например «@2/photos/photo_1.jpg». Благодаря этому
одинаковые имена в разных экспортах («doc (1).pdf») не путаются.
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
from contextlib import closing
from pathlib import Path
from urllib.parse import unquote

_PREFIX = re.compile(r"^@(\d+)/(.*)$", re.S)

_dedup_cache: dict = {"key": None, "table": {}}


def dedup_map_path() -> Path:
    import config
    return config.DATA_DIR / "dedup_map.json"


def dedup_table() -> dict[str, dict[str, str]]:
    """{папка экспорта: {удалённый файл: оставшаяся копия}}. Перечитывается, только если файл изменился."""
    path = dedup_map_path()
    try:
        stat = path.stat()
    except OSError:
        return {}
    key = (stat.st_mtime_ns, stat.st_size)
    if _dedup_cache["key"] != key:
        try:
            data = json.loads(path.read_text(encoding="utf-8-sig")).get("folders", {})
            _dedup_cache["table"] = {os.path.normcase(folder): dict(files) for folder, files in data.items()}
        except (OSError, ValueError, AttributeError, TypeError):
            return {}
        _dedup_cache["key"] = key
    return _dedup_cache["table"]


class ExportRoots:
    """Основная папка экспорта + дополнительные по номерам."""

    def __init__(self, main: Path | None, extra: dict[int, Path] | None = None) -> None:
        self.main = main.resolve() if main else None
        self.extra = {number: Path(path).resolve() for number, path in (extra or {}).items()}

    def split(self, relative_path: str) -> tuple[Path | None, str]:
        """(папка источника, путь внутри неё)."""
        match = _PREFIX.match(relative_path)
        if match:
            return self.extra.get(int(match.group(1))), match.group(2)
        return self.main, relative_path

    def resolve(self, relative_path: str) -> Path | None:
        """Существующий файл внутри папки своего источника; выйти за её пределы нельзя."""
        root, inner = self.split(relative_path)
        if root is None:
            return None
        for variant in dict.fromkeys((inner, unquote(inner))):
            candidate = (root / variant).resolve()
            try:
                candidate.relative_to(root)
            except ValueError:
                continue
            if candidate.is_file():
                return candidate
        return self._replacement(root, inner)

    @staticmethod
    def _replacement(root: Path, inner: str) -> Path | None:
        """Файл удалён очисткой повторов (dedup.py) — вместо него отдаётся оставшаяся копия."""
        table = dedup_table().get(os.path.normcase(str(root)))
        if not table:
            return None
        for variant in dict.fromkeys((inner, unquote(inner))):
            keep = table.get(variant.replace("\\", "/"))
            if keep:
                candidate = (root / keep).resolve()
                try:
                    candidate.relative_to(root)
                except ValueError:
                    continue
                if candidate.is_file():
                    return candidate
        return None

    def __str__(self) -> str:   # нужен как ключ кэша: меняются папки — пересчитываем
        return f"{self.main}|" + "|".join(f"{n}={p}" for n, p in sorted(self.extra.items()))


def extra_from_meta(value: str) -> dict[int, Path]:
    try:
        raw = json.loads(value) if value else {}
        return {int(number): Path(path) for number, path in raw.items()}
    except (ValueError, TypeError, AttributeError):
        return {}


def from_connection(connection: sqlite3.Connection, override: str = "") -> ExportRoots | None:
    def meta(key: str) -> str:
        row = connection.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
        return row[0] if row else ""

    main = override or meta("export_dir")
    if not main:
        return None
    return ExportRoots(Path(main), extra_from_meta(meta("extra_exports")))


_cache: dict = {"key": None, "roots": None}


def cached_roots(database: Path, override: str = "") -> ExportRoots | None:
    """Папки из индекса; перечитываются только когда индекс обновился."""
    try:
        stat = database.stat()
    except OSError:
        return None
    key = (stat.st_mtime_ns, stat.st_size, override)
    if _cache["key"] != key:
        try:
            with closing(sqlite3.connect(f"{database.as_uri()}?mode=ro", uri=True)) as connection:
                _cache["roots"] = from_connection(connection, override)
        except sqlite3.Error:
            return None
        _cache["key"] = key
    return _cache["roots"]
