"""Значок в трее Windows: запускает бота, следит за ним и даёт простое меню."""

from __future__ import annotations

import os
import subprocess
import sys
import threading
import time

import pystray
from PIL import Image, ImageDraw

import config

BOT_SCRIPT = config.ROOT / "bot.py"
LOG_PATH = config.BOT_LOG
MAX_LOG_BYTES = 2 * 1024 * 1024
EXIT_ALREADY_RUNNING = 0
EXIT_CONFIG_ERROR = 2

bot_process: subprocess.Popen | None = None
lock = threading.Lock()
wanted = True            # False — пользователь сам остановил бота, не перезапускать
failed = False           # True — ошибка настроек, перезапуск бессмысленен
restart_delay = 5
started_at = 0.0


def acquire_tray_mutex() -> int | None:
    """Только один значок в трее: повторный запуск молча завершается."""
    if os.name != "nt":
        return None
    import ctypes

    kernel32 = ctypes.windll.kernel32
    handle = kernel32.CreateMutexW(None, False, "Local\\PrivateArchiveBotTray")
    if handle and kernel32.GetLastError() == 183:
        kernel32.CloseHandle(handle)
        sys.exit(0)
    return handle


def create_icon(state: str) -> Image.Image:
    colors = {"running": "#35b66a", "stopped": "#8d9399", "error": "#d65a5a"}
    image = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    draw.ellipse((6, 6, 58, 58), fill=colors[state])
    draw.ellipse((22, 22, 42, 42), fill="white")
    return image


def is_running() -> bool:
    return bot_process is not None and bot_process.poll() is None


def current_state() -> str:
    if is_running():
        return "running"
    return "error" if failed else "stopped"


def rotate_log() -> None:
    config.LOG_DIR.mkdir(parents=True, exist_ok=True)
    if LOG_PATH.exists() and LOG_PATH.stat().st_size > MAX_LOG_BYTES:
        backup = LOG_PATH.with_suffix(".log.1")
        backup.unlink(missing_ok=True)
        LOG_PATH.replace(backup)


def spawn_bot() -> None:
    global bot_process, started_at
    rotate_log()
    started_at = time.monotonic()
    with LOG_PATH.open("a", encoding="utf-8") as log_file:
        bot_process = subprocess.Popen(
            [sys.executable, str(BOT_SCRIPT)],
            cwd=config.ROOT,
            stdout=subprocess.DEVNULL,
            stderr=log_file,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )


def refresh(icon: pystray.Icon) -> None:
    state = current_state()
    icon.icon = create_icon(state)
    icon.title = {
        "running": "Архив-бот: работает",
        "stopped": "Архив-бот: остановлен",
        "error": "Архив-бот: ошибка (см. журнал)",
    }[state]
    icon.update_menu()


def start_bot(icon: pystray.Icon, _item=None) -> None:
    global wanted, failed, restart_delay
    with lock:
        wanted, failed, restart_delay = True, False, 5
        if not is_running():
            spawn_bot()
    refresh(icon)


def stop_bot(icon: pystray.Icon | None = None, _item=None) -> None:
    global wanted
    with lock:
        wanted = False
        if is_running():
            bot_process.terminate()
            try:
                bot_process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                bot_process.kill()
    if icon:
        refresh(icon)


def restart_bot(icon: pystray.Icon, _item=None) -> None:
    stop_bot()
    start_bot(icon)


def open_log(_icon=None, _item=None) -> None:
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    LOG_PATH.touch(exist_ok=True)
    os.startfile(LOG_PATH)  # type: ignore[attr-defined]


def open_settings(_icon=None, _item=None) -> None:
    subprocess.Popen(["notepad.exe", str(config.CONFIG_PATH)])


def open_folder(_icon=None, _item=None) -> None:
    os.startfile(config.DATA_DIR)  # type: ignore[attr-defined]


def quit_app(icon: pystray.Icon, _item=None) -> None:
    stop_bot()
    icon.stop()


def watchdog(icon: pystray.Icon) -> None:
    """Если бот упал сам (обрыв сети, сбой) — перезапускает с нарастающей паузой."""
    global failed, restart_delay
    last_state = None
    while True:
        time.sleep(3)
        pause = None
        with lock:
            if wanted and bot_process is not None and bot_process.poll() is not None:
                code = bot_process.returncode
                if code == EXIT_CONFIG_ERROR:
                    failed = True
                elif code != EXIT_ALREADY_RUNNING:   # 0 — бот уже запущен другим способом
                    if time.monotonic() - started_at > 60:
                        restart_delay = 5            # работал долго — это не «цикл падений»
                    pause = restart_delay
                    restart_delay = min(restart_delay * 2, 60)
        if pause:
            time.sleep(pause)
            with lock:
                if wanted and not is_running():
                    spawn_bot()
        state = current_state()
        if state != last_state:
            refresh(icon)
            if state == "error":
                icon.notify("Проверьте настройки: откройте журнал из меню значка.", "Архив-бот не запустился")
            last_state = state


def main() -> None:
    mutex = acquire_tray_mutex()
    menu = pystray.Menu(
        pystray.MenuItem(lambda item: {"running": "● Работает", "stopped": "○ Остановлен", "error": "⚠ Ошибка настроек"}[current_state()], None, enabled=False),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("Перезапустить", restart_bot),
        pystray.MenuItem("Остановить", stop_bot, visible=lambda item: is_running()),
        pystray.MenuItem("Запустить", start_bot, visible=lambda item: not is_running()),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("Открыть настройки", open_settings),
        pystray.MenuItem("Показать журнал", open_log),
        pystray.MenuItem("Папка с данными", open_folder),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("Выход", quit_app),
    )
    icon = pystray.Icon("PrivateArchiveBot", create_icon("stopped"), "Архив-бот: запускается", menu=menu)

    def setup(icon: pystray.Icon) -> None:
        icon.visible = True
        start_bot(icon)
        threading.Thread(target=watchdog, args=(icon,), daemon=True).start()

    try:
        icon.run(setup)
    finally:
        stop_bot()
        if mutex:
            import ctypes
            ctypes.windll.kernel32.CloseHandle(mutex)


if __name__ == "__main__":
    main()
