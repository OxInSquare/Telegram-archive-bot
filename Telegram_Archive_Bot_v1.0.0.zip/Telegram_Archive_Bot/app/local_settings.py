"""Локальные настройки: у каждого человека свои, меняются на лету без перезапуска.

Что здесь можно настроить (для каждого Telegram ID отдельно):
  perspective  от чьего лица показывается переписка (чьи пузыри справа);
  protect      запретить пересылку и сохранение сообщений и файлов;
  page_size    сколько сообщений бот присылает за один раз при чтении;
  names        показывать ли имена авторов в приложении (авто / да / нет).

Слои значений, от слабого к сильному:  config.env  ->  «для всех» (defaults)  ->  личные (users).
Файл data/local_settings.json читается при каждом обращении (с кэшем по времени изменения),
поэтому правка из меню «Управление» или из бота действует сразу.
Токен, список разрешённых ID и адрес приложения остаются в config.env: их меняют редко и с перезапуском.
"""

from __future__ import annotations

import json
import re
import sqlite3
import threading
from collections import Counter
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path

import config

SETTINGS_PATH = config.DATA_DIR / "local_settings.json"

PARAMS = ("perspective", "protect", "page_size", "names")
TITLES = {
    "perspective": "От чьего лица показывается переписка",
    "protect": "Пересылка и сохранение сообщений",
    "page_size": "Сообщений за один раз при чтении",
    "names": "Имена авторов в приложении",
}
NAMES_MODES = ("auto", "show", "hide")
NAMES_TEXT = {"auto": "автоматически (только в беседах)", "show": "всегда показывать", "hide": "никогда не показывать"}
PAGE_SIZES = (6, 12, 20, 30)
# Эти два пункта человек может менять у себя сам; остальное (приватность, чьим лицом смотреть) — только главный пользователь.
SELF_EDITABLE = frozenset({"page_size", "names"})

_lock = threading.RLock()
_cache: dict = {"stamp": None, "data": None}


@dataclass(frozen=True)
class Effective:
    perspective: str   # пусто — «как в архиве»: автор первого сообщения (или OWNER_NAME из config.env)
    protect: bool
    page_size: int
    names: str


# ----------------------------------------------------------------------------
# Проверка значений
# ----------------------------------------------------------------------------

def clean_value(key: str, value):
    """Приводит значение к нужному виду или бросает ValueError."""
    if key == "perspective":
        text = " ".join(str(value).split())
        if len(text) > 120:
            raise ValueError("слишком длинное имя")
        return text
    if key == "protect":
        if isinstance(value, bool):
            return value
        raise ValueError("нужно да/нет")
    if key == "page_size":
        number = int(value)
        if not 1 <= number <= 30:
            raise ValueError("от 1 до 30")
        return number
    if key == "names":
        if value in NAMES_MODES:
            return value
        raise ValueError("auto, show или hide")
    raise ValueError("неизвестный параметр")


def _clean_block(raw) -> dict:
    block = {}
    if isinstance(raw, dict):
        for key in PARAMS:
            if key in raw:
                try:
                    block[key] = clean_value(key, raw[key])
                except (ValueError, TypeError):
                    continue   # испорченное значение просто игнорируем
    return block


def _normalize(raw) -> dict:
    raw = raw if isinstance(raw, dict) else {}
    users = {}
    raw_users = raw.get("users") if isinstance(raw.get("users"), dict) else {}
    for uid, block in raw_users.items():
        if re.fullmatch(r"\d+", str(uid)):
            users[str(uid)] = _clean_block(block)
    admin = raw.get("admin_id")
    return {"admin_id": admin if isinstance(admin, int) and not isinstance(admin, bool) else None,
            "defaults": _clean_block(raw.get("defaults")), "users": users}


# ----------------------------------------------------------------------------
# Чтение
# ----------------------------------------------------------------------------

def _read_file() -> dict:
    try:
        return _normalize(json.loads(SETTINGS_PATH.read_text(encoding="utf-8-sig")))
    except (OSError, ValueError):
        return _normalize({})


def load() -> dict:
    try:
        stat = SETTINGS_PATH.stat()
        stamp = (stat.st_mtime_ns, stat.st_size)
    except OSError:
        return _normalize({})
    with _lock:
        if _cache["stamp"] != stamp or _cache["data"] is None:
            _cache["stamp"], _cache["data"] = stamp, _read_file()
        return _cache["data"]


def effective(user_id: int | None) -> Effective:
    data = load()
    defaults = data["defaults"]
    personal = data["users"].get(str(user_id), {}) if user_id is not None else {}

    def pick(key: str, fallback):
        return personal.get(key, defaults.get(key, fallback))

    return Effective(
        perspective=pick("perspective", config.clean_author(config.OWNER_NAME)),
        protect=pick("protect", config.PROTECT_CONTENT),
        page_size=pick("page_size", config.PAGE_SIZE),
        names=pick("names", "auto"),
    )


def is_personal(user_id: int, key: str) -> bool:
    return key in load()["users"].get(str(user_id), {})


def admin_id() -> int | None:
    """Главный пользователь: единственный, кто меняет приватность и «лицо» других людей из бота."""
    configured = load()["admin_id"]
    if configured in config.ALLOWED_USER_IDS:
        return configured
    order = [i for i in config.ALLOWED_USER_ORDER if i in config.ALLOWED_USER_IDS]
    return order[0] if order else None


def users() -> list[int]:
    """Разрешённые ID: главный первым, дальше в порядке, как записано в config.env."""
    order = [i for i in config.ALLOWED_USER_ORDER if i in config.ALLOWED_USER_IDS]
    order += sorted(config.ALLOWED_USER_IDS - set(order))
    admin = admin_id()
    return ([admin] if admin in order else []) + [i for i in order if i != admin]


def can_edit(actor: int, target: int, key: str) -> bool:
    if key not in PARAMS:
        return False
    if actor == admin_id():
        return True
    return actor == target and key in SELF_EDITABLE


def resolve_perspective(user_id: int | None, fallback: str = "") -> str:
    """Чьи сообщения рисовать справа: личная настройка -> общая -> OWNER_NAME -> автор первого сообщения."""
    return config.clean_author(effective(user_id).perspective or fallback)


def show_names(user_id: int | None, authors_count: int) -> bool:
    mode = effective(user_id).names
    return mode == "show" or (mode == "auto" and authors_count > 2)


# ----------------------------------------------------------------------------
# Запись
# ----------------------------------------------------------------------------

def _write(data: dict) -> None:
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = SETTINGS_PATH.with_suffix(".tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(SETTINGS_PATH)
    with _lock:
        _cache["stamp"] = None


def update(target: int | None, key: str, value) -> None:
    """Меняет значение для человека (target — его ID) или «для всех» (target=None).
    value=None сбрасывает пункт: человек снова наследует общее значение."""
    if key not in PARAMS:
        raise ValueError("неизвестный параметр")
    with _lock:
        data = _read_file()
        block = data["defaults"] if target is None else data["users"].setdefault(str(target), {})
        if value is None:
            block.pop(key, None)
        else:
            block[key] = clean_value(key, value)
        if target is not None and not block:
            data["users"].pop(str(target), None)
        _write(data)


def rename_perspective(old: str, new: str) -> None:
    """Человек объединён с другим ником: настройки «чьим лицом» с прежним именем переводим на новое."""
    data = _read_file()
    for uid, block in data["users"].items():
        if block.get("perspective") == old:
            update(int(uid), "perspective", new)
    if data["defaults"].get("perspective") == old:
        update(None, "perspective", new)


def set_admin(user_id: int | None) -> None:
    with _lock:
        data = _read_file()
        data["admin_id"] = user_id
        _write(data)


# ----------------------------------------------------------------------------
# Авторы переписки
# ----------------------------------------------------------------------------

def list_authors(limit: int = 8) -> list[str]:
    """Кто писал в переписке (по убыванию числа сообщений), «via @бот» не считается отдельным автором."""
    try:
        with closing(sqlite3.connect(f"{config.DATABASE_PATH.as_uri()}?mode=ro", uri=True)) as connection:
            rows = connection.execute("SELECT author, COUNT(*) FROM messages GROUP BY author").fetchall()
    except sqlite3.Error:
        return []
    counts: Counter = Counter()
    for author, count in rows:
        counts[config.clean_author(author)] += count
    return [name for name, _ in counts.most_common(limit) if name]


def first_author() -> str:
    try:
        with closing(sqlite3.connect(f"{config.DATABASE_PATH.as_uri()}?mode=ro", uri=True)) as connection:
            row = connection.execute("SELECT value FROM meta WHERE key = 'first_author'").fetchone()
    except sqlite3.Error:
        return ""
    return config.clean_author(row[0]) if row else ""


# ----------------------------------------------------------------------------
# Подписи значений
# ----------------------------------------------------------------------------

def describe(key: str, value, default_author: str = "") -> str:
    if key == "perspective":
        return value or (f"как в архиве ({default_author})" if default_author else "как в архиве")
    if key == "protect":
        return "запрещены" if value else "разрешены"
    if key == "page_size":
        return str(value)
    return NAMES_TEXT.get(value, str(value))


def short_describe(key: str, value) -> str:
    if key == "protect":
        return "пересылка запрещена" if value else "пересылка разрешена"
    if key == "perspective":
        return f"от лица: {value or 'как в архиве'}"
    if key == "page_size":
        return f"{value} сообщ."
    return f"имена: {value}"


# ----------------------------------------------------------------------------
# Консольное меню (Управление.bat -> «Локальные настройки»)
# ----------------------------------------------------------------------------

def _ask(prompt: str) -> str:
    try:
        return input(prompt).strip()
    except EOFError:
        return ""


def _line(uid: int | None, label: str) -> str:
    here = effective(uid)
    parts = [
        f"от лица: {here.perspective or 'как в архиве'}", "пересылка " + ("запрещена" if here.protect else "разрешена"),
        f"на странице: {here.page_size}", f"имена: {here.names}",
    ]
    return f"{label} — " + "; ".join(parts)


def _print_overview() -> None:
    print("\n=== Локальные настройки ===")
    print("Действуют сразу, перезапускать бота не нужно. Люди могут менять часть из них и сами в боте (команда /settings).")
    admin = admin_id()
    authors = list_authors()
    print(f"Кто в переписке: {', '.join(authors) if authors else 'индекс ещё не создан'}")
    print(f"Главный пользователь (меняет настройки других в боте): {admin if admin else 'не задан'}")
    print("\n  0. " + _line(None, "Для всех по умолчанию"))
    for number, uid in enumerate(users(), 1):
        mark = " (главный)" if uid == admin else ""
        print(f"  {number}. " + _line(uid, f"ID {uid}{mark}"))
    print("\nВведите номер, чтобы изменить этого человека (0 — настройки для всех).")
    print("  g  — назначить главного пользователя")
    print("  Enter — назад")


def _choose_value(key: str, target: int | None) -> None:
    """Спрашивает новое значение; пустой ввод — отмена, «-» — сбросить на общее."""
    reset_hint = "  -  сбросить (брать общее значение)" if target is not None else ""
    if key == "perspective":
        authors = list_authors()
        print("\nОт чьего лица показывать переписку (эти пузыри будут справа):")
        for number, name in enumerate(authors, 1):
            print(f"  {number}. {name}")
        print("  a  как в архиве (автор первого сообщения)")
        if reset_hint:
            print(reset_hint)
        answer = _ask("Номер, имя или Enter для отмены: ")
        if not answer:
            return
        if answer == "-" and target is not None:
            update(target, key, None)
        elif answer.lower() == "a":
            update(target, key, "")
        elif answer.isdigit() and 1 <= int(answer) <= len(authors):
            update(target, key, authors[int(answer) - 1])
        elif not answer.isdigit():
            update(target, key, answer)
        else:
            print("Нет такого номера.")
            return
    elif key == "protect":
        print("\nЗапретить пересылку и сохранение сообщений и файлов?")
        print("  1. Да, запретить\n  2. Нет, разрешить")
        if reset_hint:
            print(reset_hint)
        answer = _ask("Номер или Enter для отмены: ")
        if answer in {"1", "2"}:
            update(target, key, answer == "1")
        elif answer == "-" and target is not None:
            update(target, key, None)
        else:
            return
    elif key == "page_size":
        print("\nСколько сообщений присылать за один раз при чтении (1–30).")
        if reset_hint:
            print(reset_hint)
        answer = _ask("Число или Enter для отмены: ")
        if not answer:
            return
        if answer == "-" and target is not None:
            update(target, key, None)
        else:
            try:
                update(target, key, int(answer))
            except ValueError:
                print("Нужно число от 1 до 30.")
                return
    else:
        print("\nПоказывать имена авторов в приложении?")
        for number, mode in enumerate(NAMES_MODES, 1):
            print(f"  {number}. {NAMES_TEXT[mode]}")
        if reset_hint:
            print(reset_hint)
        answer = _ask("Номер или Enter для отмены: ")
        if answer.isdigit() and 1 <= int(answer) <= len(NAMES_MODES):
            update(target, key, NAMES_MODES[int(answer) - 1])
        elif answer == "-" and target is not None:
            update(target, key, None)
        else:
            return
    print("✔ Сохранено. Бот подхватит это сразу.")


def _edit(target: int | None) -> None:
    while True:
        title = "для всех по умолчанию" if target is None else f"ID {target}"
        print(f"\n--- Настройки: {title} ---")
        here = effective(target)
        for number, key in enumerate(PARAMS, 1):
            own = "" if target is None else ("" if is_personal(target, key) else "  (общее значение)")
            print(f"  {number}. {TITLES[key]}: {describe(key, getattr(here, key), first_author())}{own}")
        answer = _ask("Номер пункта для изменения (Enter — назад): ")
        if not answer:
            return
        if answer.isdigit() and 1 <= int(answer) <= len(PARAMS):
            _choose_value(PARAMS[int(answer) - 1], target)
        else:
            print("Нет такого пункта.")


def _pick_admin() -> None:
    ids = users()
    if not ids:
        print("Список разрешённых пользователей пуст.")
        return
    print("\nКто главный пользователь?")
    for number, uid in enumerate(ids, 1):
        print(f"  {number}. {uid}" + (" (сейчас)" if uid == admin_id() else ""))
    answer = _ask("Номер или Enter для отмены: ")
    if answer.isdigit() and 1 <= int(answer) <= len(ids):
        set_admin(ids[int(answer) - 1])
        print("✔ Сохранено.")


def run_menu() -> None:
    while True:
        _print_overview()
        answer = _ask("Ваш выбор: ").lower()
        ids = users()
        if not answer:
            return
        if answer == "g":
            _pick_admin()
        elif answer == "0":
            _edit(None)
        elif answer.isdigit() and 1 <= int(answer) <= len(ids):
            _edit(ids[int(answer) - 1])
        else:
            print("Нет такого пункта.")
