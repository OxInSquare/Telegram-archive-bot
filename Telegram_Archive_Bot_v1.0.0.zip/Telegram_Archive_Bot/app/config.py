"""Общие пути и настройки. Всё личное хранится в папке data/, код — в app/."""

from __future__ import annotations

import os
import re
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent          # app/
BASE_DIR = ROOT.parent                           # корень проекта
DATA_DIR = BASE_DIR / "data"                     # личные данные: настройки, индекс, журналы, venv
VENV_DIR = DATA_DIR / "venv"
LOG_DIR = DATA_DIR / "logs"
CONFIG_PATH = DATA_DIR / "config.env"
DEFAULT_DATABASE = DATA_DIR / "archive.sqlite3"
USER_DATA_PATH = Path(os.getenv("USER_DATA_PATH") or DATA_DIR / "user_data.sqlite3")   # свои закрепы: не теряются при обновлении переписки
BOT_LOG = LOG_DIR / "bot.err.log"

TASK_NAME = "PrivateArchiveBotTray"

load_dotenv(CONFIG_PATH)

_VIA_RE = re.compile(r"\s+via\s+@\w+\s*$", re.IGNORECASE)


def clean_author(name: str) -> str:
    """«Имя via @pic» — это сообщение, отправленное через inline-бота; автор тот же."""
    return _VIA_RE.sub("", name or "").strip()


_TOKEN_RE = re.compile(r"^\d{6,}:[A-Za-z0-9_-]{20,}$")


def resolve_path(value: str) -> Path:
    """Относительные пути в настройках считаются от папки data/."""
    path = Path(value.strip().strip('"'))
    return path.resolve() if path.is_absolute() else (DATA_DIR / path).resolve()


def load_token() -> str:
    """Читает токен, не печатая его.

    Запасной вариант: если токен вставили в .env отдельной строкой без
    `BOT_TOKEN=`, он всё равно будет найден.
    """
    configured = os.getenv("BOT_TOKEN", "").strip().strip('"').strip("'")
    if configured:
        return configured
    if not CONFIG_PATH.is_file():
        return ""
    for line in CONFIG_PATH.read_text(encoding="utf-8-sig").splitlines():
        candidate = line.strip().strip('"').strip("'")
        if _TOKEN_RE.fullmatch(candidate):
            return candidate
    return ""


def parse_user_list(raw: str) -> list[int]:
    """ID можно разделять запятыми, пробелами и точками с запятой. Порядок сохраняется."""
    tokens = [token for token in re.split(r"[,;\s]+", raw.strip()) if token]
    bad = [token for token in tokens if not token.isdigit()]
    if bad:
        raise ValueError(
            f"В ALLOWED_USER_IDS нужны числовые ID (например 123456789), а не «{bad[0]}». "
            "Свой ID можно узнать у @userinfobot или командой /id у вашего бота."
        )
    return list(dict.fromkeys(int(token) for token in tokens))


def parse_user_ids(raw: str) -> set[int]:
    return set(parse_user_list(raw))


def env_flag(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None or not value.strip():
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "да", "on"}


APP_VERSION = "1.0.0"   # версия этой сборки; сравнивается с последним релизом на GitHub (updater.py)

CONFIG_ERRORS: list[str] = []   # ошибки в настройках; бот покажет их и не будет перезапускаться по кругу

TOKEN = load_token()
try:
    ALLOWED_USER_ORDER = parse_user_list(os.getenv("ALLOWED_USER_IDS", ""))   # порядок как в файле: первый — главный по умолчанию
    ALLOWED_USER_IDS = set(ALLOWED_USER_ORDER)
except ValueError as error:
    ALLOWED_USER_ORDER = []
    ALLOWED_USER_IDS = set()
    CONFIG_ERRORS.append(str(error))
DATABASE_PATH = resolve_path(os.getenv("DATABASE_PATH") or str(DEFAULT_DATABASE))
EXPORT_DIR_OVERRIDE = os.getenv("EXPORT_DIR", "").strip()   # обычно пусто: путь хранится в индексе
PROTECT_CONTENT = env_flag("PROTECT_CONTENT", False)        # запрет пересылки/сохранения в Telegram (по умолчанию выключен)
OWNER_NAME = os.getenv("OWNER_NAME", "").strip()            # чьи сообщения рисовать справа в скриншотах
WEBAPP_BUTTON_TEXT = (os.getenv("WEBAPP_BUTTON_TEXT") or "Открыть").strip()[:16]   # подпись кнопки рядом с полем ввода
WEBAPP_URL = os.getenv("WEBAPP_URL", "").strip().rstrip("/")  # публичный https-адрес Mini App (через туннель)
try:
    WEBAPP_PORT = int(os.getenv("WEBAPP_PORT") or 8765)
except ValueError:
    WEBAPP_PORT = 8765
    CONFIG_ERRORS.append("WEBAPP_PORT должен быть числом.")
if WEBAPP_URL and not WEBAPP_URL.startswith("https://"):
    CONFIG_ERRORS.append("WEBAPP_URL должен начинаться с https:// (Telegram не открывает приложения по http).")
try:
    PAGE_SIZE = max(1, min(30, int(os.getenv("PAGE_SIZE") or 12)))   # сообщений за один раз при чтении
except ValueError:
    PAGE_SIZE = 12
    CONFIG_ERRORS.append("PAGE_SIZE должен быть числом.")

CONFIG_TEMPLATE = """\
# Настройки бота. Файл личный — никому не передавайте.
# После изменений перезапустите бота (Управление -> «Перезапустить»).

# Токен от @BotFather
BOT_TOKEN={token}

# Числовые Telegram ID тех, кому разрешён доступ (через запятую)
ALLOWED_USER_IDS={ids}

# Защита контента: true — сообщения бота нельзя пересылать и сохранять,
# false (по умолчанию) — можно пересылать как обычные сообщения.
# (Это значение по умолчанию. Для каждого человека отдельно его можно менять
# в «Управление» -> «Локальные настройки» или командой /settings в боте.)
PROTECT_CONTENT={protect}

# Необязательно. Имя автора, чьи сообщения рисуются справа в скриншотах.
# Если пусто — справа будет автор самого первого сообщения в переписке.
# Тоже можно задать каждому человеку свой: «Локальные настройки» -> «От чьего лица».
OWNER_NAME={owner}

# Необязательно. Сколько сообщений показывать за один раз при чтении.
PAGE_SIZE={page_size}

# Приложение внутри Telegram (поиск, календарь, просмотр медиа как в чате).
# Вставьте сюда публичный https-адрес, который выдаёт туннель (см. README.txt, раздел «Приложение»).
# Пусто — приложение выключено, бот работает только кнопками.
WEBAPP_URL={webapp_url}
# Подпись кнопки приложения рядом с полем ввода (до 16 символов).
WEBAPP_BUTTON_TEXT={webapp_button}
# Порт внутреннего сервера приложения (на этом компьютере). Обычно менять не нужно.
WEBAPP_PORT={webapp_port}

# Необязательно. Обычно оставьте пустым: путь к экспорту запоминается при индексации.
EXPORT_DIR=
"""


def write_config(token: str, ids: set[int] | list[int], protect: bool = False, owner: str = "", page_size: int = 12, webapp_url: str = "", webapp_port: int = 8765, webapp_button: str = "Открыть") -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(
        CONFIG_TEMPLATE.format(
            token=token,
            ids=",".join(str(i) for i in sorted(ids)),
            protect="true" if protect else "false",
            owner=owner,
            page_size=page_size,
            webapp_url=webapp_url,
            webapp_port=webapp_port,
            webapp_button=webapp_button,
        ),
        encoding="utf-8",
    )
