"""Управление ботом: запуск, остановка, автозапуск, проверка. Меню и функции для мастера."""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

import config

CONTROL_SCRIPT = config.ROOT / "scripts" / "control.ps1"
EXIT_NOTHING_TO_DO = 3
EXIT_NOT_INSTALLED = 4


def run_control(action: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(CONTROL_SCRIPT), action],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )


def status() -> tuple[bool, bool]:
    """(бот запущен, автозапуск включён)"""
    result = run_control("status")
    return "running=true" in result.stdout, "autostart=true" in result.stdout


def do(action: str, ok: str, nothing: str) -> bool:
    result = run_control(action)
    if result.returncode == 0:
        print(f"✔ {ok}")
        return True
    if result.returncode == EXIT_NOTHING_TO_DO:
        print(f"• {nothing}")
        return True
    if result.returncode == EXIT_NOT_INSTALLED:
        print("✖ Сначала выполните установку (1_Установить.bat).")
        return False
    print("✖ Не получилось:", (result.stderr or result.stdout).strip() or f"код {result.returncode}")
    return False


def start() -> bool:
    return do("start", "Бот запущен (значок появится в трее у часов).", "Бот уже запущен.")


def stop() -> bool:
    return do("stop", "Бот остановлен.", "Бот и так не запущен.")


def autostart_on() -> bool:
    return do("autostart-on", "Автозапуск включён: бот будет стартовать при входе в Windows.", "")


def autostart_off() -> bool:
    return do("autostart-off", "Автозапуск выключен.", "Автозапуск и так не был включён.")


def telegram_call(token: str, method: str, params: dict | None = None, timeout: int = 15) -> dict:
    url = f"https://api.telegram.org/bot{token}/{method}"
    data = json.dumps(params or {}).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.load(response)
    except urllib.error.HTTPError as error:
        try:
            return json.load(error)
        except ValueError:
            return {"ok": False, "description": f"HTTP {error.code}"}


def check() -> None:
    """Диагностика: что работает, а что нет — простым языком."""
    print("\n--- Проверка ---")
    running, autostart = status()
    print(("✔" if running else "✖") + " Бот " + ("работает" if running else "не запущен"))
    print(("✔" if autostart else "•") + " Автозапуск " + ("включён" if autostart else "выключен"))

    if not config.CONFIG_PATH.is_file():
        print("✖ Нет файла настроек — запустите 1_Установить.bat")
        return
    for problem in config.CONFIG_ERRORS:
        print("✖", problem)
    if config.TOKEN:
        try:
            reply = telegram_call(config.TOKEN, "getMe", timeout=10)
            if reply.get("ok"):
                print(f"✔ Токен рабочий: @{reply['result']['username']}")
            else:
                print("✖ Telegram не принял токен — проверьте BOT_TOKEN (или выпустите новый в @BotFather).")
        except (urllib.error.URLError, TimeoutError, OSError):
            print("• Не удалось связаться с Telegram — проверьте интернет.")
    else:
        print("✖ BOT_TOKEN не задан.")
    print(("✔" if config.ALLOWED_USER_IDS else "✖") + f" Разрешённых пользователей: {len(config.ALLOWED_USER_IDS)}")
    if config.WEBAPP_URL:
        print(f"• Приложение включено: {config.WEBAPP_URL}  (внутренний порт {config.WEBAPP_PORT})")
        try:
            with urllib.request.urlopen(f"{config.WEBAPP_URL}/", timeout=10) as page:
                print("✔ Адрес приложения отвечает снаружи." if page.status == 200 else f"✖ Адрес отвечает кодом {page.status}.")
        except (urllib.error.URLError, TimeoutError, OSError):
            print("✖ Адрес приложения не открывается. Проверьте, что бот запущен и туннель включён (README.txt, раздел «Приложение»).")
    else:
        print("• Приложение внутри Telegram выключено (WEBAPP_URL пуст) — бот работает кнопками.")

    if config.DATABASE_PATH.is_file():
        import import_export
        count = import_export.existing_count(config.DATABASE_PATH)
        folder = Path(config.EXPORT_DIR_OVERRIDE) if config.EXPORT_DIR_OVERRIDE else import_export.stored_export_dir(config.DATABASE_PATH)
        print(f"✔ Индекс переписки: {count} сообщений")
        import_extra = import_export.load_extra_sources()
        for number, extra in enumerate(import_extra, start=1):
            print(("✔" if extra.is_dir() else "✖") + f" Дополнительная папка {number}: {extra}" + ("" if extra.is_dir() else "  ← не найдена, часть переписки не будет обновляться"))
        if folder and folder.is_dir():
            print(f"✔ Папка экспорта на месте: {folder}")
        else:
            print(f"✖ Папка экспорта не найдена ({folder}). Тексты читаются, но фото/видео/файлы отправляться не будут.")
            print("   Верните папку на место или выполните 2_Обновить_переписку.bat с новым путём.")
    else:
        print("✖ Индекса нет — выполните 2_Обновить_переписку.bat")

    if config.BOT_LOG.is_file() and config.BOT_LOG.stat().st_size:
        print(f"• Журнал ошибок: {config.BOT_LOG}")


def show_log() -> None:
    if not config.BOT_LOG.is_file() or not config.BOT_LOG.stat().st_size:
        print("Журнал пуст — ошибок не было.")
        return
    lines = config.BOT_LOG.read_text(encoding="utf-8", errors="replace").splitlines()
    print("\n".join(lines[-25:]))


def open_path(path) -> None:
    if os.name == "nt":
        os.startfile(path)  # type: ignore[attr-defined]


def add_export_menu() -> None:
    import add_export
    add_export.main()


def local_settings_menu() -> None:
    import local_settings
    local_settings.run_menu()


def dedup_menu() -> None:
    import dedup
    was_running = status()[0]
    if was_running:
        print("Бот остановлен на время очистки, потом запустится снова.")
        stop()
    try:
        dedup.run_menu()
    except (KeyboardInterrupt, EOFError):
        print("\nОтменено.")
    finally:
        if was_running:
            start()


def open_settings() -> None:
    if config.CONFIG_PATH.is_file():
        subprocess.Popen(["notepad.exe", str(config.CONFIG_PATH)])
        print("Настройки открыты в Блокноте. После правок выберите «Перезапустить».")
    else:
        print("Файла настроек ещё нет — выполните 1_Установить.bat")


MENU = """
================ Управление архив-ботом ================
  1. Запустить бота
  2. Остановить бота
  3. Перезапустить бота
  4. Включить автозапуск при входе в Windows
  5. Выключить автозапуск
  6. Проверить, всё ли в порядке
  7. Открыть настройки (токен, доступ)
  8. Показать последние ошибки
  9. Открыть папку с данными
 10. Локальные настройки (приватность, от чьего лица показывается переписка)
 11. Добавить новую часть переписки (ещё одна папка экспорта)
 12. Убрать повторяющиеся файлы (стикеры, фото, гифки) в любой папке экспорта
  0. Выход
"""


def menu() -> None:
    actions = {
        "1": start,
        "2": stop,
        "3": lambda: (stop(), start()),
        "4": autostart_on,
        "5": autostart_off,
        "6": check,
        "7": open_settings,
        "8": show_log,
        "9": lambda: open_path(config.DATA_DIR),
        "10": local_settings_menu,
        "11": add_export_menu,
        "12": dedup_menu,
    }
    while True:
        print(MENU)
        choice = input("Введите номер и нажмите Enter: ").strip()
        if choice in {"0", "", "q"}:
            return
        action = actions.get(choice)
        if action is None:
            print("Нет такого пункта.")
            continue
        print()
        action()


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if len(sys.argv) > 1 and sys.argv[1] == "check":
        check()
    else:
        menu()
