# Control script for the archive bot (start / stop / status / autostart).
# ASCII only on purpose: Windows PowerShell 5 misreads UTF-8 without BOM.
# Exit codes are interpreted by manage.py, which prints the Russian messages.
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('start', 'stop', 'status', 'autostart-on', 'autostart-off')]
    [string]$Action
)

$ErrorActionPreference = 'Stop'
$taskName   = 'PrivateArchiveBotTray'
$appDir     = Split-Path -Parent $PSScriptRoot
$baseDir    = Split-Path -Parent $appDir
$dataDir    = Join-Path $baseDir 'data'
$pythonw    = Join-Path $dataDir 'venv\Scripts\pythonw.exe'
$trayScript = Join-Path $appDir 'tray.py'
$botScript  = Join-Path $appDir 'bot.py'

function Get-BotProcesses {
    # Only processes that run THIS copy of the bot (matched by full script path).
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
        $_.CommandLine -and ($_.CommandLine.Contains($trayScript) -or $_.CommandLine.Contains($botScript))
    }
}

function Get-Task {
    Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
}

switch ($Action) {
    'status' {
        $running  = [bool](Get-BotProcesses)
        $autostart = [bool](Get-Task)
        Write-Output ("running={0} autostart={1}" -f $running.ToString().ToLower(), $autostart.ToString().ToLower())
    }
    'stop' {
        $procs = @(Get-BotProcesses)
        if ($procs.Count -eq 0) { exit 3 }   # nothing was running
        # Tray first (so it does not restart the bot), then the bot itself.
        $procs | Sort-Object { if ($_.CommandLine.Contains($trayScript)) { 0 } else { 1 } } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
        Start-Sleep -Milliseconds 700
    }
    'start' {
        if (-not (Test-Path -LiteralPath $pythonw)) { exit 4 }   # not installed
        if (@(Get-BotProcesses).Count -gt 0) { exit 3 }          # already running
        if (Get-Task) {
            Start-ScheduledTask -TaskName $taskName
        } else {
            Start-Process -FilePath $pythonw -ArgumentList ('"{0}"' -f $trayScript) -WorkingDirectory $appDir -WindowStyle Hidden
        }
    }
    'autostart-on' {
        if (-not (Test-Path -LiteralPath $pythonw)) { exit 4 }
        $taskAction   = New-ScheduledTaskAction -Execute $pythonw -Argument ('"{0}"' -f $trayScript) -WorkingDirectory $appDir
        $taskTrigger  = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
        $taskSettings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
            -ExecutionTimeLimit (New-TimeSpan -Seconds 0) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
        Register-ScheduledTask -TaskName $taskName -Action $taskAction -Trigger $taskTrigger -Settings $taskSettings `
            -Description 'Private Telegram archive bot (starts at sign-in).' -Force | Out-Null
    }
    'autostart-off' {
        if (-not (Get-Task)) { exit 3 }
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    }
}
