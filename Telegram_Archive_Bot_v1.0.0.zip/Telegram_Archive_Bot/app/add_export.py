"""Добавление новой части переписки: ещё одна папка экспорта рядом с основной.

Файлы новой папки никуда не копируются и не переименовываются. Бот сверяет сообщения по номеру
и времени: то, что уже есть, пропускает, новое дописывает в нужное место. Перед изменением показывает
отчёт и спрашивает подтверждение; если папка похожа на другой чат, остановится.
"""

from __future__ import annotations

import sys
from pathlib import Path

import config
import import_export
import local_settings
import manage
from setup_wizard import ask, find_export_candidates, yes_no


def fmt_day(day: str) -> str:
    return f"{day[8:10]}.{day[5:7]}.{day[:4]}" if day else "—"


def ask_folder(used: list[Path]) -> Path | None:
    taken = {p.resolve() for p in used}
    candidates = [p for p in find_export_candidates() if p.resolve() not in taken][:9]
    if candidates:
        print("Нашёл экспорты Telegram на этом компьютере (первый — самый свежий):")
        for number, folder in enumerate(candidates, start=1):
            print(f"  {number}. {folder}")
        print("Введите номер или вставьте путь к папке с новой частью (можно перетащить папку мышкой в окно). Enter — отмена.")
    else:
        print("Вставьте путь к папке нового экспорта (там лежит messages.html). Можно перетащить папку мышкой в окно. Enter — отмена.")
    while True:
        value = ask("Папка новой части").strip('"').strip("'")
        if not value:
            return None
        if value.isdigit() and 1 <= int(value) <= len(candidates):
            return candidates[int(value) - 1]
        folder = Path(value).expanduser()
        if folder.is_dir() and import_export.export_pages(folder):
            return folder.resolve()
        print("✖ В этой папке нет файлов messages*.html. Нужна папка, внутри которой лежит messages.html.")


def print_report(report: import_export.MergeReport) -> None:
    print("\n--- Что нашлось ---")
    print(f"Сообщений в новой папке: {report.total}")
    print(f"Уже есть в архиве (пропущу): {report.duplicates}")
    print(f"Новых: {report.added}" + (f" (с {fmt_day(report.first_day)} по {fmt_day(report.last_day)})" if report.added else ""))
    if report.added:
        print(f"Их файлов найдено: {report.files_found}" + (f", нет в экспорте: {report.files_missing}" if report.files_missing else ""))
    if report.recovered:
        print(f"Сообщений, у которых раньше не хватало файлов, а теперь они есть: {report.recovered}")
    if report.mismatched:
        print(f"Не совпало по времени с архивом (пропущу): {report.mismatched}")
    if report.skipped:
        print(f"Не удалось разобрать: {report.skipped}" + (f"\n  Пример причины: {report.failure_example}" if report.failure_example else ""))


def pick_author(title: str, authors: list[tuple[str, int]], skip: str = "") -> str | None:
    """Номера в списке не меняются, даже если один ник скрыт (skip), чтобы не путаться."""
    for number, (name, count) in enumerate(authors, start=1):
        if name != skip:
            print(f"  {number}. {name} ({count} сообщ.)")
    answer = ask(title)
    if answer.isdigit() and 1 <= int(answer) <= len(authors) and authors[int(answer) - 1][0] != skip:
        return authors[int(answer) - 1][0]
    return None


def choose_kept(first: str, second: str, first_note: str = "", second_note: str = "") -> tuple[str, str]:
    """(кого переименовать, как назвать): спрашивает, под каким ником показывать человека."""
    print(f"\nПод каким ником показывать этого человека?\n  1. «{first}»{first_note}\n  2. «{second}»{second_note}")
    keep_second = ask("Номер (Enter — 1)") == "2"
    return (first, second) if keep_second else (second, first)


def ask_author_merges(database: Path, merged: Path) -> dict[str, str]:
    """Если в новой части появился ник, которого не было в архиве, предлагает объединить его с прежним."""
    pairs: dict[str, str] = {}
    known = import_export.author_counts(database)
    for name, count in import_export.new_authors(database, merged):
        print(f"\n⚠️ В новой части появился автор «{name}» ({count} сообщ.), которого нет в архиве.")
        print("   Если человек просто сменил ник, лучше объединить: иначе бот будет считать «" + name + "» отдельным новым человеком,")
        print("   и его сообщения разойдутся с прежними (в приложении, в «чьим лицом», в скриншотах).")
        print("   Если это и правда новый человек, ничего не объединяйте.")
        print("\nКто из прежних авторов это?")
        old_name = pick_author("Номер (Enter — это новый человек, не объединять)", known)
        if old_name is None:
            continue
        source, target = choose_kept(old_name, name, " (прежний)", " (новый)")
        import_export.merge_authors_in_copy(merged, source, target)
        pairs = import_export.add_alias(pairs, source, target)
        print(f"✔ Будет объединено: «{source}» → «{target}».")
    return pairs


def merge_authors_flow() -> None:
    authors = import_export.author_counts(config.DATABASE_PATH) if config.DATABASE_PATH.is_file() else []
    if len(authors) < 2:
        print("В архиве меньше двух авторов, объединять нечего.")
        return
    print("Объединение двух ников одного человека: все сообщения будут показаны под одним именем.")
    print("\nКто из авторов первый?")
    first = pick_author("Номер (Enter — отмена)", authors)
    if first is None:
        print("Отменено.")
        return
    print("\nС кем его объединить (это тот же человек)?")
    second = pick_author("Номер (Enter — отмена)", authors, skip=first)
    if second is None:
        print("Отменено.")
        return
    source, target = choose_kept(first, second)
    print(f"\nВсе сообщения «{source}» станут сообщениями «{target}». Это запоминается: при обновлении архива люди снова не разъедутся.")
    if not yes_no("Объединить?", default=False):
        print("Отменено.")
        return
    try:
        changed = import_export.merge_authors(config.DATABASE_PATH, source, target)
    except (ValueError, OSError) as error:
        print(f"✖ {error}")
        return
    local_settings.rename_perspective(source, target)
    print(f"✅ Готово: переименовано сообщений: {changed}. Бот ничего перезапускать не нужно.")


def add_flow() -> None:
    database = config.DATABASE_PATH
    main_dir = import_export.stored_export_dir(database)
    if main_dir is None:
        print("✖ Сначала нужен основной архив: выполните 1_Установить.bat или 2_Обновить_переписку.bat.")
        return
    extras = import_export.load_extra_sources()
    folder = ask_folder([main_dir, *extras])
    if folder is None:
        print("Отменено.")
        return
    print("\nСверяю с архивом (бот при этом работает как обычно)...")

    def progress(done: int, total: int) -> None:
        if total > 1:
            print(f"  обработано файлов: {done} из {total}", end="\r", flush=True)

    try:
        report, merged = import_export.merge_into_copy(database, folder, progress)
    except import_export.NotSameChat as error:
        print(f"\n✖ {error}\n  Ничего не изменено. Проверьте, что это экспорт того же чата.")
        return
    except (ValueError, FileNotFoundError, OSError) as error:
        print(f"\n✖ {error}")
        return
    print(" " * 50, end="\r")
    print_report(report)

    if not report.added and not report.recovered:
        print("\nНичего нового не нашлось, архив остаётся как есть.")
        merged.unlink(missing_ok=True)
        return
    if report.title_differs and not report.duplicates:
        print(f"\n⚠️ Название чата другое: в архиве «{report.main_title}», в новой папке «{report.title}», а общих сообщений нет.")
        if not yes_no("Это точно та же переписка?", default=False):
            print("Отменено, ничего не изменено.")
            merged.unlink(missing_ok=True)
            return
    elif report.title_differs:
        print(f"\n• Название чата отличается («{report.title}»), но общие сообщения совпали по времени: чат тот же, просто переименован.")
    aliases = ask_author_merges(database, merged)
    if not yes_no(f"\nДобавить в архив? Бот ненадолго остановится"):
        print("Отменено, ничего не изменено.")
        merged.unlink(missing_ok=True)
        return

    was_running, _ = manage.status()
    if was_running:
        print("Останавливаю бота...")
        manage.stop()
    try:
        import_export.apply_merge(database, merged, folder, aliases)
    except (OSError, PermissionError) as error:
        print(f"\n✖ {error}")
        merged.unlink(missing_ok=True)
        if was_running:
            manage.start()
        return
    for source, target in aliases.items():
        local_settings.rename_perspective(source, target)
    if was_running:
        manage.start()
    print("\n✅ Готово. Новые сообщения уже в боте. Папку с новой частью не удаляйте и не переносите: файлы берутся оттуда.")


def remove_flow() -> None:
    extras = import_export.load_extra_sources()
    if not extras:
        print("Дополнительных папок нет.")
        return
    print("Подключённые дополнительные папки:")
    for number, folder in enumerate(extras, start=1):
        print(f"  {number}. {folder}")
    answer = ask("Какую отключить? Номер (Enter — отмена)")
    if not answer.isdigit() or not 1 <= int(answer) <= len(extras):
        print("Отменено.")
        return
    removed = extras[int(answer) - 1]
    print(f"\nСообщения, которые есть только в {removed}, пропадут из архива. Сама папка на диске не пострадает.")
    if not yes_no("Отключить?", default=False):
        print("Отменено.")
        return
    main_dir = import_export.stored_export_dir(config.DATABASE_PATH)
    if main_dir is None:
        print("✖ Нет основного индекса.")
        return
    remaining = [folder for folder in extras if folder != removed]
    was_running, _ = manage.status()
    if was_running:
        print("Останавливаю бота...")
        manage.stop()
    try:
        # индекс пересобирается без этой папки; список меняем только после успеха
        import_export.rebuild_index(main_dir, config.DATABASE_PATH, extras=remaining)
        import_export.save_extra_sources(remaining)
        print("✅ Папка отключена, индекс обновлён.")
    except Exception as error:
        print(f"✖ Не получилось: {error}\n  Ничего не изменено.")
    if was_running:
        manage.start()


def show_state() -> None:
    main_dir = import_export.stored_export_dir(config.DATABASE_PATH)
    print("\nСейчас в архиве:")
    print(f"  основная папка: {main_dir if main_dir else 'не задана'}")
    extras = import_export.load_extra_sources()
    for number, folder in enumerate(extras, start=1):
        print(f"  дополнительная {number}: {folder}" + ("" if folder.is_dir() else "   ← ПАПКА НЕ НАЙДЕНА"))
    count = import_export.existing_count(config.DATABASE_PATH)
    print(f"  сообщений: {count if count is not None else 'индекса нет'}")


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    print("=== Новая часть переписки ===")
    print("Скачайте в Telegram Desktop новый экспорт чата (формат HTML) и укажите его папку.")
    print("Ничего копировать и переименовывать не нужно: бот сам сверит сообщения и допишет только новые.\n")
    try:
        if not config.CONFIG_PATH.is_file():
            print("✖ Бот ещё не установлен. Сначала запустите 1_Установить.bat")
        else:
            while True:
                show_state()
                print("\n  1. Добавить новую часть переписки\n  2. Отключить ранее добавленную папку\n  3. Объединить двух авторов (человек сменил ник)\n  Enter — выход")
                choice = ask("Ваш выбор")
                if not choice:
                    break
                print()
                if choice == "1":
                    add_flow()
                elif choice == "2":
                    remove_flow()
                elif choice == "3":
                    merge_authors_flow()
                else:
                    print("Нет такого пункта.")
    except (KeyboardInterrupt, EOFError):
        print("\nОтменено.")
    except Exception as error:
        print(f"\n✖ Ошибка: {error}")
    try:
        input("\nНажмите Enter, чтобы закрыть окно...")
    except EOFError:
        pass


if __name__ == "__main__":
    main()
