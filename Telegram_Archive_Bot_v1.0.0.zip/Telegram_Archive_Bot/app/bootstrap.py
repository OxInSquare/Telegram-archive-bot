"""Первый шаг установки. Запускается системным Python (только стандартная библиотека):
создаёт окружение в data/venv, ставит библиотеки и передаёт управление мастеру."""

from __future__ import annotations

import re
import shutil
import subprocess
import sys
import venv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data"
VENV_DIR = DATA_DIR / "venv"
REQUIREMENTS = ROOT / "requirements.txt"
MIN_PYTHON = (3, 11)
MAX_PYTHON = (3, 14)   # для более новых версий у библиотек ещё нет готовых сборок


def venv_python() -> Path:
    return VENV_DIR / ("Scripts/python.exe" if sys.platform == "win32" else "bin/python")


def venv_version() -> tuple[int, int] | None:
    cfg = VENV_DIR / "pyvenv.cfg"
    if not cfg.is_file():
        return None
    match = re.search(r"^version\s*=\s*(\d+)\.(\d+)", cfg.read_text(encoding="utf-8", errors="replace"), re.MULTILINE)
    return (int(match.group(1)), int(match.group(2))) if match else None


CHECK_SCRIPT = r"""
import re, sys
from importlib.metadata import PackageNotFoundError, version

def parts(text):
    numbers = [int(x) for x in re.findall(r"\d+", text)[:3]]
    return tuple(numbers + [0] * (3 - len(numbers)))

for line in open(sys.argv[1], encoding="utf-8"):
    line = line.split("#")[0].strip()
    if not line:
        continue
    name = re.match(r"[A-Za-z0-9_.-]+", line).group(0)
    try:
        installed = parts(version(name))
    except PackageNotFoundError:
        sys.exit(1)
    for op, wanted in re.findall(r"(>=|<=|==|<|>)\s*([\d.]+)", line[len(name):]):
        w = parts(wanted)
        ok = {">=": installed >= w, "<=": installed <= w, "==": installed == w, "<": installed < w, ">": installed > w}[op]
        if not ok:
            sys.exit(1)
"""


def requirements_satisfied() -> bool:
    """Все ли библиотеки из requirements.txt уже есть в окружении нужных версий."""
    result = subprocess.run([str(venv_python()), "-c", CHECK_SCRIPT, str(REQUIREMENTS)], capture_output=True)
    return result.returncode == 0


def fail(message: str) -> None:
    print(f"\n✖ {message}")
    input("\nНажмите Enter, чтобы закрыть окно...")
    sys.exit(1)


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    print("=== Установка архив-бота ===\n")
    if sys.version_info < MIN_PYTHON:
        fail(
            f"Нужен Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} или новее, а найден {sys.version_info.major}.{sys.version_info.minor}.\n"
            "Скачайте свежий Python на python.org/downloads (при установке поставьте галочку «Add python.exe to PATH») и запустите установку снова."
        )

    if sys.version_info[:2] > MAX_PYTHON:
        found = f"{sys.version_info.major}.{sys.version_info.minor}"
        fail(
            f"Найден Python {found} — он слишком новый: для него ещё нет готовых сборок библиотек, и их пришлось бы собирать из исходников (нужны Visual Studio и Rust).\n"
            "Решение: установите рядом Python 3.13 с python.org/downloads (старый удалять не нужно) и запустите 1_Установить.bat снова — он сам выберет подходящую версию."
        )

    DATA_DIR.mkdir(exist_ok=True)
    old = venv_version()
    if old is not None and old != sys.version_info[:2]:
        print(f"Окружение создано другой версией Python ({old[0]}.{old[1]}) — пересоздаю...")
        shutil.rmtree(VENV_DIR, ignore_errors=True)
    if not venv_python().exists():
        print("1/2 Создаю рабочее окружение (один раз)...")
        venv.EnvBuilder(with_pip=True).create(VENV_DIR)
    if requirements_satisfied():
        print("2/2 Нужные библиотеки уже установлены — пропускаю.")
    else:
        print("2/2 Устанавливаю библиотеки (нужен интернет, 1–2 минуты)...")
        result = subprocess.run([str(venv_python()), "-m", "pip", "install", "--disable-pip-version-check", "--only-binary=:all:", "-q", "-r", str(REQUIREMENTS)])
        if result.returncode != 0:
            fail(
                "Не удалось установить библиотеки.\n"
                f"Проверьте интернет. Если интернет в порядке, возможно, Python {sys.version_info.major}.{sys.version_info.minor} не подходит: "
                "установите Python 3.13 (python.org/downloads) и запустите установку снова."
            )
    print("Готово.\n")

    wizard = subprocess.run([str(venv_python()), str(ROOT / "setup_wizard.py")])
    sys.exit(wizard.returncode)


if __name__ == "__main__":
    main()
