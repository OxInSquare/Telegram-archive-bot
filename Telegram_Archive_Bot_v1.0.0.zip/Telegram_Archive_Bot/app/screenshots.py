"""Страницы-«скриншоты» дня в стиле переписки, нарисованные из локального индекса."""

from __future__ import annotations

import sqlite3
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from urllib.parse import unquote

from PIL import Image, ImageDraw, ImageFont

from config import clean_author
from export_paths import ExportRoots

WIDTH, HEIGHT = 1080, 1920
MARGIN, HEADER_HEIGHT = 42, 112
MAX_BUBBLE_WIDTH = 760
LINE_HEIGHT = 36
BOTTOM_GAP = 24
PAGE_TOP = HEADER_HEIGHT + 28

# Несколько шрифтов на случай, если Segoe UI нет. Берётся первый найденный;
# если нет ни одного — встроенный шрифт PIL, чтобы рендер не падал.
FONT_REGULAR_CANDIDATES = (
    r"C:\Windows\Fonts\segoeui.ttf",
    r"C:\Windows\Fonts\arial.ttf",
    r"C:\Windows\Fonts\calibri.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    "/Library/Fonts/Arial.ttf",
    "/System/Library/Fonts/Supplemental/Arial.ttf",
)
FONT_BOLD_CANDIDATES = (
    r"C:\Windows\Fonts\segoeuib.ttf",
    r"C:\Windows\Fonts\arialbd.ttf",
    r"C:\Windows\Fonts\calibrib.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/Library/Fonts/Arial Bold.ttf",
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
)


def _find_font_file(candidates: tuple[str, ...]) -> str | None:
    for candidate in candidates:
        if Path(candidate).is_file():
            return candidate
    return None


@lru_cache(maxsize=None)
def font(size: int, bold: bool = False):
    path = _find_font_file(FONT_BOLD_CANDIDATES if bold else FONT_REGULAR_CANDIDATES)
    if path:
        return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def rows_for_day(database: Path, day: str) -> list[sqlite3.Row]:
    connection = sqlite3.connect(database)
    connection.row_factory = sqlite3.Row
    try:
        return connection.execute(
            """
            SELECT m.id, m.sent_at, m.author, m.text, a.relative_path, a.kind
            FROM messages m
            LEFT JOIN attachments a ON a.message_id = m.id
            WHERE m.day = ?
            ORDER BY m.sort_key, a.id
            """,
            (day,),
        ).fetchall()
    finally:
        connection.close()


def group_rows(rows: list[sqlite3.Row]) -> list[dict]:
    messages: list[dict] = []
    by_id: dict[str, dict] = {}
    for row in rows:
        if row["id"] not in by_id:
            item = {"sent_at": row["sent_at"], "author": row["author"], "text": row["text"], "attachments": []}
            by_id[row["id"]] = item
            messages.append(item)
        if row["relative_path"]:
            by_id[row["id"]]["attachments"].append((row["relative_path"], row["kind"]))
    return messages


def _break_word(draw: ImageDraw.ImageDraw, word: str, used_font, width: int) -> list[str]:
    """Режет слишком длинное слово (ссылку) по символам, чтобы оно не вылезало из пузыря."""
    pieces: list[str] = []
    current = ""
    for char in word:
        if current and draw.textlength(current + char, font=used_font) > width:
            pieces.append(current)
            current = char
        else:
            current += char
    if current:
        pieces.append(current)
    return pieces


# Эмодзи-служебные значки из индекса нечем нарисовать обычным шрифтом (получатся квадратики).
SIMPLE_REPLACEMENTS = (("📎 ", "▣ "), ("↪ ", "→ "))


def fit_text(draw: ImageDraw.ImageDraw, value: str, used_font, width: int) -> list[str]:
    if not value:
        return []
    result: list[str] = []
    for original_line in value.splitlines() or [value]:
        current = ""
        for word in original_line.split() or [""]:
            if draw.textlength(word, font=used_font) > width:
                pieces = _break_word(draw, word, used_font, width)
                if current:
                    result.append(current)
                result.extend(pieces[:-1])
                current = pieces[-1]
                continue
            candidate = f"{current} {word}".strip()
            if current and draw.textlength(candidate, font=used_font) > width:
                result.append(current)
                current = word
            else:
                current = candidate
        result.append(current)
    return result


def image_attachment(export_dir: ExportRoots | Path, attachment: tuple[str, str], max_width: int) -> Image.Image | None:
    relative_path, kind = attachment
    if kind not in {"photo", "sticker"}:
        return None
    roots = export_dir if isinstance(export_dir, ExportRoots) else ExportRoots(export_dir)
    candidate = roots.resolve(relative_path)
    if candidate is not None:
        try:
            image = Image.open(candidate).convert("RGB")
            image.thumbnail((max_width, 520))
            return image
        except (OSError, ValueError):
            return None
    return None


def media_label(attachments: list[tuple[str, str]]) -> str:
    if not attachments:
        return ""
    labels = {
        "voice": "Голосовое сообщение",
        "video_note": "◉ Видеосообщение",
        "video": "▶ Видео",
        "animation": "GIF",
        "document": "▣ Файл",
        "sticker": "Стикер",
        "photo": "Фото",
    }
    return " · ".join(labels.get(kind, "Вложение") for _, kind in attachments)


def new_page(day: str) -> tuple[Image.Image, ImageDraw.ImageDraw, int]:
    image = Image.new("RGB", (WIDTH, HEIGHT), "#e4ddd3")
    draw = ImageDraw.Draw(image)
    draw.rectangle((0, 0, WIDTH, HEADER_HEIGHT), fill="#527b8f")
    draw.text((MARGIN, 28), "Архив переписки", font=font(36, True), fill="white")
    caption = datetime.strptime(day, "%Y-%m-%d").strftime("%d.%m.%Y")
    draw.text((MARGIN, 74), caption, font=font(22), fill="#dbeaf1")
    return image, draw, PAGE_TOP


def render_day_screenshots(
    database: Path,
    export_dir: Path,
    day: str,
    output_dir: Path,
    owner: str | None = None,
) -> list[Path]:
    """Рисует все сообщения дня постранично в PNG.

    Длинное сообщение, которое не помещается на страницу, переносится на
    следующую (раньше оно обрезалось). `owner` — автор, чьи пузыри рисуются
    справа; по умолчанию автор первого сообщения дня.
    """
    messages = group_rows(rows_for_day(database, day))
    if not messages:
        return []
    output_dir.mkdir(parents=True, exist_ok=True)
    owner = clean_author(owner or messages[0]["author"])
    pages: list[Path] = []
    state = {"number": 1}
    image, draw, y = new_page(day)
    page_capacity = HEIGHT - PAGE_TOP - BOTTOM_GAP

    def save_page() -> None:
        target = output_dir / f"{day}-{state['number']:03d}.png"
        image.save(target, "PNG", optimize=True)
        pages.append(target)
        state["number"] += 1

    text_font, name_font = font(27), font(23, True)
    for message in messages:
        outgoing = clean_author(message["author"]) == owner
        color = "#d5f1c6" if outgoing else "#ffffff"
        x = WIDTH - MARGIN - MAX_BUBBLE_WIDTH if outgoing else MARGIN
        shown_text = message["text"]
        for old, new in SIMPLE_REPLACEMENTS:
            shown_text = shown_text.replace(old, new)
        lines = fit_text(draw, shown_text, text_font, MAX_BUBBLE_WIDTH - 48)
        preview = image_attachment(export_dir, message["attachments"][0], MAX_BUBBLE_WIDTH - 48) if message["attachments"] else None
        label = media_label(message["attachments"]) if preview is None else ""
        media_height = (preview.height + 16 if preview else 0) + (44 if label else 0)
        time = datetime.fromisoformat(message["sent_at"]).strftime("%H:%M")
        index, first = 0, True

        def chunk_height(count: int, with_name: bool, with_media: bool) -> int:
            return 18 + (LINE_HEIGHT if with_name else 0) + count * LINE_HEIGHT + (media_height if with_media else 0) + 40

        while True:
            remaining = len(lines) - index
            available = HEIGHT - y - BOTTOM_GAP
            whole = chunk_height(remaining, first, True)
            if whole <= available:
                count, with_media, last = remaining, True, True
            elif y > PAGE_TOP and whole <= page_capacity + 18:
                save_page()
                image, draw, y = new_page(day)
                continue
            else:
                count = (available - 18 - (LINE_HEIGHT if first else 0) - 40) // LINE_HEIGHT
                if count < 2 and y > PAGE_TOP:
                    save_page()
                    image, draw, y = new_page(day)
                    continue
                count = max(1, min(count, remaining))
                with_media, last = False, False
            height = chunk_height(count, first, with_media)
            draw.rounded_rectangle((x, y, x + MAX_BUBBLE_WIDTH, y + height), radius=22, fill=color)
            cursor = y + 18
            if first:
                draw.text((x + 22, cursor), message["author"], font=name_font, fill="#2873a0")
                cursor += LINE_HEIGHT
            for line in lines[index:index + count]:
                draw.text((x + 22, cursor), line, font=text_font, fill="#1f2933")
                cursor += LINE_HEIGHT
            if with_media and preview:
                image.paste(preview, (x + 22, cursor + 5))
                cursor += preview.height + 16
            elif with_media and label:
                draw.rounded_rectangle((x + 22, cursor + 4, x + MAX_BUBBLE_WIDTH - 22, cursor + 38), radius=10, fill="#dfe9ed")
                draw.text((x + 34, cursor + 8), label, font=font(21), fill="#37515c")
                cursor += 44
            if last:
                draw.text((x + MAX_BUBBLE_WIDTH - 82, y + height - 31), time, font=font(18), fill="#70828b")
            y += height + 18
            index += count
            first = False
            if last:
                break
            save_page()
            image, draw, y = new_page(day)
    save_page()
    return pages
