"""Веб-сервер Telegram Mini App: читает архив, пускает только разрешённых.

Как защищено:
* Страница-оболочка открыта всем, но в ней нет данных. Любой запрос за данными
  требует подписанный токен.
* Токен выдаётся только в обмен на `initData` от Telegram: подпись проверяется
  токеном бота (так делает сам Telegram), срок жизни ограничен, а ID человека
  должен быть в ALLOWED_USER_IDS.
* Файлы отдаются по номеру вложения из базы, а не по пути от клиента: выйти за
  пределы папки экспорта невозможно.
* Сервер слушает только 127.0.0.1; наружу его выводит туннель, который вы сами
  включаете (см. README.txt).
* Много неудачных попыток входа подряд с одного адреса — временная блокировка.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import mimetypes
import re
import sqlite3
import threading
import time
from collections import Counter
from contextlib import closing
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qsl, quote, unquote, urlparse

import config
import export_paths
import local_settings

log = logging.getLogger("archive-web")

STATIC_DIR = config.ROOT / "web"
THUMB_DIR = config.DATA_DIR / "cache" / "thumbs"
SESSION_TTL = 12 * 3600            # токен живёт 12 часов, потом страница сама запросит новый
INIT_DATA_MAX_AGE = 24 * 3600      # initData старше суток не принимаем
MAX_FAILURES = 15                  # неудачных входов за окно — блокировка
FAILURE_WINDOW = 600
CHUNK = 256 * 1024
FRAME_ANCESTORS = "https://web.telegram.org https://webk.telegram.org https://webz.telegram.org https://*.telegram.org"

failures: dict[str, list[float]] = {}
failures_lock = threading.Lock()


# ----------------------------------------------------------------------------
# Проверка личности
# ----------------------------------------------------------------------------

def validate_init_data(init_data: str, bot_token: str, now: float | None = None, max_age: int = INIT_DATA_MAX_AGE) -> dict | None:
    """Проверяет подпись Telegram и возвращает данные пользователя или None."""
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True, strict_parsing=True))
    except ValueError:
        return None
    received_hash = pairs.pop("hash", "")
    if not received_hash:
        return None
    check_string = "\n".join(f"{key}={pairs[key]}" for key in sorted(pairs))
    secret = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret, check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, received_hash):
        return None
    try:
        issued = int(pairs.get("auth_date", "0"))
        user = json.loads(pairs.get("user", ""))
        int(user["id"])
    except (ValueError, KeyError, TypeError):
        return None
    if (now if now is not None else time.time()) - issued > max_age:
        return None
    return user


def session_secret(bot_token: str) -> bytes:
    return hmac.new(b"archive-session", bot_token.encode(), hashlib.sha256).digest()


def make_session(user_id: int, bot_token: str, now: float | None = None) -> str:
    expires = int((now if now is not None else time.time()) + SESSION_TTL)
    payload = f"{user_id}.{expires}"
    signature = hmac.new(session_secret(bot_token), payload.encode(), hashlib.sha256).hexdigest()
    return f"{payload}.{signature}"


def verify_session(token: str, bot_token: str, allowed: set[int], now: float | None = None) -> int | None:
    match = re.fullmatch(r"(\d+)\.(\d+)\.([0-9a-f]{64})", token or "")
    if not match:
        return None
    user_id, expires, signature = int(match.group(1)), int(match.group(2)), match.group(3)
    expected = hmac.new(session_secret(bot_token), f"{user_id}.{expires}".encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature):
        return None
    if expires < (now if now is not None else time.time()):
        return None
    return user_id if user_id in allowed else None


# ----------------------------------------------------------------------------
# База данных
# ----------------------------------------------------------------------------

def connect() -> sqlite3.Connection:
    connection = sqlite3.connect(f"{config.DATABASE_PATH.as_uri()}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    return connection


def meta_value(connection: sqlite3.Connection, key: str, default: str = "") -> str:
    row = connection.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return row[0] if row else default


def export_root(connection: sqlite3.Connection) -> export_paths.ExportRoots | None:
    """Основная папка экспорта и дополнительные (новые части переписки)."""
    return export_paths.from_connection(connection, config.EXPORT_DIR_OVERRIDE)


def resolve_media(root: export_paths.ExportRoots | None, relative_path: str) -> Path | None:
    return root.resolve(relative_path) if root is not None else None


# Старые индексы относили анимированные стикеры (.tgs) к файлам — считаем их стикерами и без переиндексации.
KIND_SQL = "CASE WHEN lower(a.relative_path) LIKE '%.tgs' THEN 'sticker' ELSE a.kind END"


def effective_kind(kind: str, relative_path: str) -> str:
    return "sticker" if relative_path.lower().endswith(".tgs") else kind


# Вкладки раздела «Медиа». Ключ вкладки -> (подпись, ключи видов вложений).
# Вкладка появляется в приложении, только если в экспорте есть хотя бы один такой файл.
MEDIA_TABS = (
    ("visual", "Фото и видео", ("photo", "video", "video_note")),
    ("voice", "Голосовые", ("voice",)),
    ("animation", "GIF", ("animation",)),
    ("sticker", "Стикеры", ("sticker_view",)),   # только те, что можно показать (без анимированных .tgs)
    ("document", "Файлы", ("document",)),
)

_availability: dict = {"key": None, "data": None}
_availability_lock = threading.Lock()


def media_availability(connection: sqlite3.Connection) -> dict[str, list[int]]:
    """Какие вложения реально лежат в папке экспорта: {вид: [id по возрастанию]}.

    Вложение, на которое ссылается переписка, но которого нет на диске (Telegram не
    скачал файл или он слишком большой), в расчёт не берётся. Результат запоминается
    и пересчитывается только при смене индекса или папки экспорта.
    """
    root = export_root(connection)
    try:
        stat = config.DATABASE_PATH.stat()
        stamp = (stat.st_mtime_ns, stat.st_size)
    except OSError:
        stamp = None
    key = (stamp, str(root))
    with _availability_lock:
        if _availability["key"] == key and _availability["data"] is not None:
            return _availability["data"]
    found: dict[str, list[int]] = {}
    if root is not None:
        for row in connection.execute("SELECT id, kind, relative_path FROM attachments ORDER BY id"):
            if resolve_media(root, row["relative_path"]) is None:
                continue
            kind = effective_kind(row["kind"], row["relative_path"])
            found.setdefault(kind, []).append(row["id"])
            if kind == "sticker" and not row["relative_path"].lower().endswith(".tgs"):
                found.setdefault("sticker_view", []).append(row["id"])
    with _availability_lock:
        _availability["key"], _availability["data"] = key, found
    return found


def media_tabs(found: dict[str, list[int]]) -> list[dict]:
    tabs = []
    for key, label, kinds in MEDIA_TABS:
        count = sum(len(found.get(kind, [])) for kind in kinds)
        if count:
            tabs.append({"key": key, "label": label, "count": count})
    return tabs


def tab_ids(found: dict[str, list[int]], key: str) -> list[int]:
    """id вложений вкладки (или одного вида) по возрастанию; пустой ключ — все файлы."""
    tab = next((kinds for name, _, kinds in MEDIA_TABS if name == key), None)
    if tab is None:
        tab = (key,) if key else tuple(k for k in found if k != "sticker_view")
    return sorted(i for kind in tab for i in found.get(kind, []))


def user_db() -> sqlite3.Connection:
    """Свои закрепы живут в отдельном файле: индекс переписки при обновлении пересоздаётся."""
    config.USER_DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(config.USER_DATA_PATH)
    connection.execute(
        "CREATE TABLE IF NOT EXISTS user_pins (user_id INTEGER NOT NULL, message_id TEXT NOT NULL, pinned_at TEXT NOT NULL, PRIMARY KEY (user_id, message_id))"
    )
    return connection


def pins_dir() -> Path:
    return config.USER_DATA_PATH.parent / "pins"


def export_user_pins(uid: int, connection: sqlite3.Connection) -> None:
    """Копия закрепов человека в читаемом файле data/pins/<telegram-id>.json — чтобы можно было вернуть их после сбоя."""
    with closing(user_db()) as user:
        rows = user.execute("SELECT message_id, pinned_at FROM user_pins WHERE user_id = ? ORDER BY pinned_at, rowid", (uid,)).fetchall()
    items = []
    for message_id, pinned_at in rows:
        m = connection.execute("SELECT day, sent_at, author, text FROM messages WHERE id = ?", (message_id,)).fetchone()
        items.append({
            "message_id": message_id, "pinned_at": pinned_at,
            "message_date": m["sent_at"] if m else "", "author": config.clean_author(m["author"]) if m else "",
            "text": " ".join(m["text"].split())[:200] if m else "",
        })
    folder = pins_dir()
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f"{uid}.json"
    temp = target.with_suffix(".tmp")
    temp.write_text(json.dumps({"telegram_id": uid, "pins": items}, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(target)


def restore_user_pins() -> None:
    """При запуске добавляет закрепы из data/pins/*.json, которых нет в базе (после сбоя или переноса)."""
    folder = pins_dir()
    if not folder.is_dir():
        return
    for path in folder.glob("*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8-sig"))
            uid = int(data["telegram_id"])
            pins = [(uid, str(p["message_id"]), str(p.get("pinned_at") or "")) for p in data["pins"] if re.fullmatch(r"[\w-]{1,40}", str(p["message_id"]))]
        except (OSError, ValueError, KeyError, TypeError):
            log.warning("не удалось прочитать файл закрепов %s", path.name)
            continue
        with closing(user_db()) as user:
            user.executemany("INSERT OR IGNORE INTO user_pins (user_id, message_id, pinned_at) VALUES (?, ?, ?)", pins)
            user.commit()


def user_pinned(uid: int | None, ids: list[str]) -> set[str]:
    if uid is None or not ids:
        return set()
    marks = ",".join("?" * len(ids))
    with closing(user_db()) as connection:
        return {r[0] for r in connection.execute(f"SELECT message_id FROM user_pins WHERE user_id = ? AND message_id IN ({marks})", [uid, *ids])}


def set_user_pin(uid: int, message_id: str, pinned: bool) -> None:
    with closing(user_db()) as connection:
        if pinned:
            connection.execute("INSERT OR REPLACE INTO user_pins (user_id, message_id, pinned_at) VALUES (?, ?, ?)", (uid, message_id, datetime.now().isoformat(timespec="seconds")))
        else:
            connection.execute("DELETE FROM user_pins WHERE user_id = ? AND message_id = ?", (uid, message_id))
        connection.commit()


def escape_like(value: str) -> str:
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def like_pattern(term: str) -> str:
    escaped = term.casefold().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


def search_terms(query: str) -> list[str]:
    """Слова через пробел — все должны встретиться; "в кавычках" — точная фраза."""
    terms = [a or b for a, b in re.findall(r'"([^"]+)"|(\S+)', query)]
    return [" ".join(term.split()) for term in terms if term.strip()][:8]


def snippet(text: str, terms: list[str], limit: int = 240) -> str:
    flat = " ".join(text.split())
    positions = [flat.casefold().find(term.casefold()) for term in terms]
    positions = [p for p in positions if p >= 0]
    if not positions:
        return flat[:limit] + ("…" if len(flat) > limit else "")
    start = max(0, min(positions) - 80)
    end = min(len(flat), start + limit)
    return ("…" if start else "") + flat[start:end] + ("…" if end < len(flat) else "")


def attachments_for(connection: sqlite3.Connection, root: Path | None, message_ids: list[str]) -> dict[str, list[dict]]:
    result: dict[str, list[dict]] = {mid: [] for mid in message_ids}
    if not message_ids:
        return result
    marks = ",".join("?" * len(message_ids))
    for row in connection.execute(f"SELECT id, message_id, relative_path, kind FROM attachments WHERE message_id IN ({marks}) ORDER BY id", message_ids):
        name = Path(unquote(row["relative_path"])).name
        result[row["message_id"]].append({
            "id": row["id"], "kind": effective_kind(row["kind"], row["relative_path"]), "name": name,
            "exists": resolve_media(root, row["relative_path"]) is not None,
        })
    return result


def messages_json(connection: sqlite3.Connection, rows: list[sqlite3.Row], uid: int | None = None) -> list[dict]:
    root = export_root(connection)
    ids = [row["id"] for row in rows]
    attachments = attachments_for(connection, root, ids)
    reply_ids = sorted({row["reply_to"] for row in rows if row["reply_to"]})
    pinned = user_pinned(uid, ids)
    replies: dict[str, dict] = {}
    if reply_ids:
        marks = ",".join("?" * len(reply_ids))
        for row in connection.execute(f"SELECT id, sort_key, author, text FROM messages WHERE id IN ({marks})", reply_ids):
            replies[row["id"]] = {"sort_key": row["sort_key"], "author": config.clean_author(row["author"]), "text": " ".join(row["text"].split())[:140]}
    return [
        {
            "id": row["id"], "sort_key": row["sort_key"], "sent_at": row["sent_at"], "day": row["day"],
            "author": config.clean_author(row["author"]), "text": row["text"], "pinned": row["id"] in pinned,
            "reply": replies.get(row["reply_to"]) if row["reply_to"] else None,
            "attachments": attachments[row["id"]],
        }
        for row in rows
    ]


MESSAGE_COLUMNS = "m.id, m.sort_key, m.sent_at, m.day, m.author, m.text, m.reply_to"


def int_param(params: dict, name: str, default: int, low: int, high: int) -> int:
    try:
        return max(low, min(high, int(params.get(name, default))))
    except (TypeError, ValueError):
        return default


def day_param(params: dict, name: str) -> str | None:
    value = params.get(name, "")
    return value if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) else None


# ----------------------------------------------------------------------------
# API
# ----------------------------------------------------------------------------

def api_info(connection, params, uid=None):
    total = connection.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
    first, last = connection.execute("SELECT MIN(day), MAX(day) FROM messages").fetchone()
    counts: Counter = Counter()
    for r in connection.execute("SELECT author, COUNT(*) AS c FROM messages GROUP BY author"):
        counts[config.clean_author(r["author"])] += r["c"]
    authors = [name for name, _ in counts.most_common(20)]
    found = media_availability(connection)
    kinds = {kind: len(ids) for kind, ids in found.items() if ids and kind != "sticker_view"}   # только то, что есть на диске
    pins = connection.execute("SELECT COUNT(*) FROM pins").fetchone()[0]
    return {
        "total": total, "first_day": first, "last_day": last, "authors": authors, "kinds": kinds, "media_tabs": media_tabs(found), "pins": pins,
        # «лицо», приватность и имена — личные настройки того, кто вошёл (см. local_settings.py)
        "owner": local_settings.resolve_perspective(uid, meta_value(connection, "first_author")),
        "protect": local_settings.effective(uid).protect,
        "show_names": local_settings.show_names(uid, len(counts)),
        "last_sort_key": connection.execute("SELECT MAX(sort_key) FROM messages").fetchone()[0],
    }


def api_months(connection, params, uid=None):
    return {"months": [{"month": r["month"], "count": r["c"]} for r in connection.execute(
        "SELECT substr(day, 1, 7) AS month, COUNT(*) AS c FROM messages GROUP BY month ORDER BY month")]}


def api_calendar(connection, params, uid=None):
    month = params.get("month", "")
    if not re.fullmatch(r"\d{4}-\d{2}", month):
        raise ValueError("month")
    return {"days": {r["day"][8:]: r["c"] for r in connection.execute(
        "SELECT day, COUNT(*) AS c FROM messages WHERE substr(day, 1, 7) = ? GROUP BY day", (month,))}}


def api_messages(connection, params, uid=None):
    limit = int_param(params, "limit", 40, 1, 100)
    if "day" in params:
        day = day_param(params, "day")
        if not day:
            raise ValueError("day")
        row = connection.execute("SELECT MIN(sort_key) FROM messages WHERE day = ?", (day,)).fetchone()
        if row[0] is None:   # такого дня нет — ближайший следующий, иначе последний
            row = connection.execute("SELECT MIN(sort_key) FROM messages WHERE day > ?", (day,)).fetchone()
        if row[0] is None:
            row = connection.execute("SELECT MAX(sort_key) FROM messages").fetchone()
        return api_messages(connection, {"around": str(row[0]), "limit": str(limit), "anchor_first": "1"}, uid)
    if "around" in params:
        center = int_param(params, "around", 0, 0, 10**9)
        before = 2 if params.get("anchor_first") else limit // 2
        rows = connection.execute(
            f"SELECT {MESSAGE_COLUMNS} FROM messages m WHERE sort_key BETWEEN ? AND ? ORDER BY sort_key",
            (center - before, center + limit - before),
        ).fetchall()
        anchor = center
    elif "before" in params:
        key = int_param(params, "before", 0, 0, 10**9)
        rows = connection.execute(
            f"SELECT {MESSAGE_COLUMNS} FROM messages m WHERE sort_key < ? ORDER BY sort_key DESC LIMIT ?", (key, limit)
        ).fetchall()[::-1]
        anchor = None
    elif "after" in params:
        key = int_param(params, "after", -1, -1, 10**9)
        rows = connection.execute(
            f"SELECT {MESSAGE_COLUMNS} FROM messages m WHERE sort_key > ? ORDER BY sort_key LIMIT ?", (key, limit)
        ).fetchall()
        anchor = None
    else:   # по умолчанию — самые свежие
        rows = connection.execute(
            f"SELECT {MESSAGE_COLUMNS} FROM messages m ORDER BY sort_key DESC LIMIT ?", (limit,)
        ).fetchall()[::-1]
        anchor = None
    return {
        "messages": messages_json(connection, rows, uid), "anchor": anchor,
        "has_more_before": bool(rows) and connection.execute("SELECT 1 FROM messages WHERE sort_key < ? LIMIT 1", (rows[0]["sort_key"],)).fetchone() is not None,
        "has_more_after": bool(rows) and connection.execute("SELECT 1 FROM messages WHERE sort_key > ? LIMIT 1", (rows[-1]["sort_key"],)).fetchone() is not None,
    }


def api_search(connection, params, uid=None):
    terms = search_terms(params.get("q", ""))
    where, args = [], []
    for term in terms:
        where.append("m.search_text LIKE ? ESCAPE '\\'")
        args.append(like_pattern(term))
    date_from, date_to = day_param(params, "from"), day_param(params, "to")
    if date_from:
        where.append("m.day >= ?"); args.append(date_from)
    if date_to:
        where.append("m.day <= ?"); args.append(date_to)
    author = params.get("author", "")
    if author:
        where.append("(m.author = ? OR m.author LIKE ? ESCAPE '\\')"); args.extend([author, escape_like(author) + " via @%"])
    kind = params.get("kind", "")
    if kind:
        where.append(f"EXISTS (SELECT 1 FROM attachments a WHERE a.message_id = m.id AND {KIND_SQL} = ?)"); args.append(kind)
    if not where:
        return {"total": 0, "results": [], "terms": []}
    clause = " AND ".join(where)
    order = "ASC" if params.get("order") == "asc" else "DESC"
    offset, limit = int_param(params, "offset", 0, 0, 10**7), int_param(params, "limit", 30, 1, 60)
    total = connection.execute(f"SELECT COUNT(*) FROM messages m WHERE {clause}", args).fetchone()[0]
    rows = connection.execute(
        f"SELECT {MESSAGE_COLUMNS} FROM messages m WHERE {clause} ORDER BY m.sort_key {order} LIMIT ? OFFSET ?",
        [*args, limit, offset],
    ).fetchall()
    attachments = attachments_for(connection, None, [r["id"] for r in rows])
    return {
        "total": total, "terms": terms,
        "results": [
            {"sort_key": r["sort_key"], "day": r["day"], "sent_at": r["sent_at"], "author": config.clean_author(r["author"]),
             "snippet": snippet(r["text"], terms), "kinds": [a["kind"] for a in attachments[r["id"]]]}
            for r in rows
        ],
    }


def api_media(connection, params, uid=None):
    """Страница вложений одной вкладки. Отдаёт только файлы, которые есть в экспорте."""
    ids = tab_ids(media_availability(connection), params.get("kind", ""))
    total = len(ids)
    offset, limit = int_param(params, "offset", 0, 0, 10**7), int_param(params, "limit", 48, 1, 100)
    if params.get("order") != "asc":
        ids = ids[::-1]
    page = ids[offset:offset + limit]
    if not page:
        return {"total": total, "items": []}
    marks = ",".join("?" * len(page))
    rows = {r["id"]: r for r in connection.execute(
        f"""SELECT a.id, a.kind, a.relative_path, m.sort_key, m.day, m.author, m.sent_at
            FROM attachments a JOIN messages m ON m.id = a.message_id WHERE a.id IN ({marks})""", page)}
    root = export_root(connection)
    items = []
    for attachment_id in page:
        r = rows.get(attachment_id)
        path = resolve_media(root, r["relative_path"]) if r else None
        if r is None or path is None:
            continue
        try:
            size = path.stat().st_size
        except OSError:
            size = 0
        items.append({
            "id": r["id"], "kind": effective_kind(r["kind"], r["relative_path"]), "name": Path(unquote(r["relative_path"])).name,
            "size": size, "sort_key": r["sort_key"], "day": r["day"], "author": config.clean_author(r["author"]),
            "sent_at": r["sent_at"], "exists": True,
        })
    return {"total": total, "items": items}


def api_pins(connection, params, uid=None):
    """mine — свои закрепы (новые сверху); exported — что закреплялось в самом Telegram."""
    mine: list[dict] = []
    if uid is not None:
        with closing(user_db()) as user:
            order = [r[0] for r in user.execute("SELECT message_id FROM user_pins WHERE user_id = ? ORDER BY pinned_at DESC, rowid DESC", (uid,))]
        if order:
            marks = ",".join("?" * len(order))
            found = {r["id"]: r for r in connection.execute(f"SELECT {MESSAGE_COLUMNS} FROM messages m WHERE m.id IN ({marks})", order)}
            mine = messages_json(connection, [found[i] for i in order if i in found], uid)
    rows = connection.execute(f"SELECT {MESSAGE_COLUMNS} FROM pins p JOIN messages m ON m.id = p.message_id ORDER BY p.seq DESC").fetchall()
    return {"mine": mine, "exported": messages_json(connection, rows, uid)}


API = {
    "/api/info": api_info, "/api/months": api_months, "/api/calendar": api_calendar,
    "/api/messages": api_messages, "/api/search": api_search, "/api/media": api_media, "/api/pins": api_pins,
}

STATIC_TYPES = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml"}


# ----------------------------------------------------------------------------
# HTTP
# ----------------------------------------------------------------------------

def client_ip(handler: BaseHTTPRequestHandler) -> str:
    peer = handler.client_address[0]
    if peer in ("127.0.0.1", "::1"):   # за туннелем настоящий адрес лежит в заголовках
        forwarded = handler.headers.get("CF-Connecting-IP") or (handler.headers.get("X-Forwarded-For") or "").split(",")[0].strip()
        return forwarded or peer
    return peer


def is_blocked(ip: str) -> bool:
    now = time.time()
    with failures_lock:
        recent = [t for t in failures.get(ip, []) if now - t < FAILURE_WINDOW]
        failures[ip] = recent
        return len(recent) >= MAX_FAILURES


def record_failure(ip: str) -> None:
    with failures_lock:
        failures.setdefault(ip, []).append(time.time())


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "ArchiveWeb"
    sys_version = ""

    def log_message(self, format, *args):  # noqa: A002 - не засоряем консоль
        log.debug("%s %s", self.address_string(), format % args)

    # --- общие помощники ---
    def security_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "private, no-store")
        self.send_header(
            "Content-Security-Policy",
            f"default-src 'self'; script-src 'self' https://telegram.org; style-src 'self' 'unsafe-inline'; "
            f"img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'; object-src 'none'; "
            f"base-uri 'none'; frame-ancestors {FRAME_ANCESTORS}",
        )

    def send_bytes(self, status: int, body: bytes, content_type: str, extra: dict | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.security_headers()
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def send_json(self, status: int, payload: dict) -> None:
        self.send_bytes(status, json.dumps(payload, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def error(self, status: int, message: str) -> None:
        self.send_json(status, {"error": message})

    def authenticate(self, query: dict) -> int | None:
        header = self.headers.get("Authorization", "")
        token = header[7:] if header.startswith("Bearer ") else query.get("t", "")
        return verify_session(token, config.TOKEN, config.ALLOWED_USER_IDS)

    # --- маршруты ---
    def do_HEAD(self) -> None:
        self.do_GET()

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        query = dict(parse_qsl(parsed.query))
        path = parsed.path
        try:
            if path in ("/", "/index.html"):
                return self.serve_static("index.html")
            if path.startswith("/static/"):
                return self.serve_static(path[len("/static/"):])
            uid = self.authenticate(query)
            if uid is None:
                ip = client_ip(self)   # блокировка касается только тех, у кого нет действующего токена
                if is_blocked(ip):
                    return self.error(429, "Слишком много попыток. Подождите несколько минут.")
                record_failure(ip)
                return self.error(401, "Нужна авторизация через Telegram.")
            if path in API:
                with closing(connect()) as connection:
                    return self.send_json(200, API[path](connection, query, uid))
            match = re.fullmatch(r"/(media|thumb)/(\d+)", path)
            if match:
                return self.serve_attachment(match.group(1), int(match.group(2)), query, uid)
            self.error(404, "Не найдено.")
        except ValueError:
            self.error(400, "Неверные параметры.")
        except sqlite3.Error as error:
            log.warning("database error: %s", error)
            self.error(500, "Не удалось прочитать архив.")
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/pin":
            return self.post_pin()
        if path != "/api/auth":
            return self.error(404, "Не найдено.")
        ip = client_ip(self)
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 8192:
                raise ValueError
            init_data = json.loads(self.rfile.read(length))["initData"]
        except (ValueError, KeyError, TypeError):
            record_failure(ip)
            return self.error(400, "Неверный запрос.")
        user = validate_init_data(init_data, config.TOKEN)
        if user is None or int(user["id"]) not in config.ALLOWED_USER_IDS:
            if is_blocked(ip):
                return self.error(429, "Слишком много попыток. Подождите несколько минут.")
            record_failure(ip)
            log.warning("web login refused from %s (user %s)", ip, user.get("id") if user else "?")
            return self.error(403, "Нет доступа к этому архиву.")
        self.send_json(200, {"token": make_session(int(user["id"]), config.TOKEN), "name": user.get("first_name", "")})

    def post_pin(self) -> None:
        uid = self.authenticate({})
        if uid is None:
            return self.error(401, "Нужна авторизация через Telegram.")
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 1024:
                raise ValueError
            body = json.loads(self.rfile.read(length))
            message_id, pinned = str(body["id"]), bool(body["pinned"])
            if not re.fullmatch(r"[\w-]{1,40}", message_id):
                raise ValueError
        except (ValueError, KeyError, TypeError):
            return self.error(400, "Неверный запрос.")
        with closing(connect()) as connection:
            if connection.execute("SELECT 1 FROM messages WHERE id = ?", (message_id,)).fetchone() is None:
                return self.error(404, "Сообщение не найдено.")
        set_user_pin(uid, message_id, pinned)
        try:
            with closing(connect()) as connection:
                export_user_pins(uid, connection)
        except (OSError, sqlite3.Error) as error:
            log.warning("не удалось записать копию закрепов: %s", error)
        self.send_json(200, {"pinned": pinned})

    def serve_static(self, name: str) -> None:
        if not re.fullmatch(r"[\w.-]+", name) or name.startswith("."):
            return self.error(404, "Не найдено.")
        path = STATIC_DIR / name
        content_type = STATIC_TYPES.get(path.suffix)
        if content_type is None or not path.is_file():
            return self.error(404, "Не найдено.")
        self.send_bytes(200, path.read_bytes(), content_type)

    def serve_attachment(self, mode: str, attachment_id: int, query: dict, uid: int | None = None) -> None:
        with closing(connect()) as connection:
            row = connection.execute("SELECT relative_path, kind FROM attachments WHERE id = ?", (attachment_id,)).fetchone()
            root = export_root(connection)
        if row is None:
            return self.error(404, "Не найдено.")
        path = resolve_media(root, row["relative_path"])
        if path is None:
            return self.error(404, "Файла нет в экспорте.")
        if mode == "thumb":
            thumb = make_thumbnail(attachment_id, path, int_param(query, "w", 320, 100, 800))
            if thumb is not None:
                return self.serve_file(thumb, "image/jpeg")
            return self.serve_file(path, guess_type(path))
        download = path.name if query.get("download") == "1" and not local_settings.effective(uid).protect else None
        self.serve_file(path, guess_type(path), download)

    def serve_file(self, path: Path, content_type: str, download_name: str | None = None) -> None:
        size = path.stat().st_size
        start, end, status = 0, size - 1, 200
        range_header = self.headers.get("Range")
        if range_header:
            match = re.fullmatch(r"bytes=(\d*)-(\d*)", range_header.strip())
            if not match or (not match.group(1) and not match.group(2)):
                return self.send_bytes(416, b"", "text/plain", {"Content-Range": f"bytes */{size}"})
            if match.group(1):
                start = int(match.group(1))
                end = int(match.group(2)) if match.group(2) else size - 1
            else:   # bytes=-N — последние N байт
                start = max(0, size - int(match.group(2)))
            end = min(end, size - 1)
            if start > end or start >= size:
                return self.send_bytes(416, b"", "text/plain", {"Content-Range": f"bytes */{size}"})
            status = 206
        length = end - start + 1
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(length))
        self.send_header("Accept-Ranges", "bytes")
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        disposition = "attachment" if download_name else "inline"
        if download_name:
            self.send_header("Content-Disposition", f"{disposition}; filename*=UTF-8''{quote_filename(download_name)}")
        self.security_headers()
        self.send_header("Cache-Control", "private, max-age=3600")
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            with path.open("rb") as handle:
                handle.seek(start)
                remaining = length
                while remaining > 0:
                    chunk = handle.read(min(CHUNK, remaining))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass   # человек перемотал видео или закрыл окно


def quote_filename(name: str) -> str:
    return quote(name, safe="")


def guess_type(path: Path) -> str:
    kind = mimetypes.guess_type(path.name)[0]
    if path.suffix.lower() in {".ogg", ".opus", ".oga"}:
        return "audio/ogg"
    return kind or "application/octet-stream"


def make_thumbnail(attachment_id: int, source: Path, width: int) -> Path | None:
    if source.suffix.lower() not in {".jpg", ".jpeg", ".png", ".webp", ".gif"}:
        return None
    target = THUMB_DIR / f"{attachment_id}_{width}.jpg"
    if target.is_file():
        return target
    try:
        from PIL import Image
        THUMB_DIR.mkdir(parents=True, exist_ok=True)
        with Image.open(source) as image:
            image.thumbnail((width, width * 2))
            image.convert("RGB").save(target, "JPEG", quality=82)
        return target
    except (OSError, ValueError):
        return None


class ArchiveServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def start_server(port: int) -> ArchiveServer:
    """Запускает сервер в фоновом потоке и возвращает его (для остановки)."""
    restore_user_pins()
    server = ArchiveServer(("127.0.0.1", port), Handler)
    threading.Thread(target=server.serve_forever, name="archive-web", daemon=True).start()
    log.info("Mini App слушает http://127.0.0.1:%d", port)
    return server
