"""Очистка повторяющихся файлов (стикеры, фото, гифки, видео) в папке экспорта.

Если один и тот же файл лежит в экспорте сто раз, остаётся одна копия, остальные удаляются.
Какой файл чем заменён, записывается в data/dedup_map.json; export_paths.ExportRoots.resolve()
подставляет оставшуюся копию сам. Поэтому чат выглядит как раньше, а пересборка индекса и
подключение папки позже ничего не ломают. Работает с любой папкой экспорта по пути,
не только с основной.
"""

from __future__ import annotations

import filecmp
import hashlib
import json
import os
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

import config
import export_paths

SKIP_DIRS = {"css", "js", "images"}   # служебные папки самого экспорта (оформление), не вложения
CONFIRM_WORD = "УДАЛИТЬ"

WARNING = f"""
⚠  ВНИМАНИЕ. Это действие НЕОБРАТИМО.
   • Лишние копии будут удалены с диска. Вернуть их можно только из резервной копии
     или новым экспортом из Telegram.
   • В самом чате ничего не пропадёт: бот запомнит, какой файл заменил удалённые,
     и будет показывать оставшуюся копию. Файл {config.DATA_DIR.name}\\dedup_map.json удалять нельзя:
     без него бот перестанет находить удалённые копии.
   • После очистки не переименовывайте и не переносите эту папку экспорта: замены привязаны к её пути.
   • Если открыть messages.html из этой папки прямо в браузере, на месте удалённых копий будут пустые места.
   • Есть риск, что при сбое (выключили свет, закрыли окно, диск занят) часть файлов
     окажется удалена, а чат будет показывать недостающие медиа.
   Перед очисткой настоятельно рекомендуется скопировать папку экспорта в надёжное место.
"""


@dataclass
class Group:
    keep: str                                   # какой файл остаётся (путь внутри папки, через /)
    dupes: list[str] = field(default_factory=list)
    size: int = 0


@dataclass
class ScanResult:
    folder: Path
    files: int = 0
    groups: list[Group] = field(default_factory=list)

    @property
    def dupe_count(self) -> int:
        return sum(len(g.dupes) for g in self.groups)

    @property
    def bytes_freed(self) -> int:
        return sum(len(g.dupes) * g.size for g in self.groups)


def human_size(value: float) -> str:
    for unit in ("Б", "КБ", "МБ", "ГБ"):
        if value < 1024 or unit == "ГБ":
            return f"{value:.0f} {unit}" if unit == "Б" else f"{value:.1f} {unit}"
        value /= 1024
    return ""


def media_files(folder: Path) -> list[tuple[str, int]]:
    """(путь внутри папки через /, размер) всех файлов вложений. Страницы чата и оформление пропускаются."""
    found: list[tuple[str, int]] = []
    for current, dirs, names in os.walk(folder):
        here = Path(current)
        if here == folder:
            dirs[:] = [d for d in dirs if d.lower() not in SKIP_DIRS]
        for name in names:
            if here == folder and name.lower().startswith("messages") and name.lower().endswith(".html"):
                continue
            path = here / name
            try:
                size = path.stat().st_size
            except OSError:
                continue
            if size > 0:
                found.append((path.relative_to(folder).as_posix(), size))
    return found


def file_hash(path: Path) -> str:
    digest = hashlib.sha1()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def scan(folder: Path, progress=None) -> ScanResult:
    """Ищет побайтово одинаковые файлы. Ничего не меняет."""
    folder = folder.resolve()
    files = media_files(folder)
    result = ScanResult(folder=folder, files=len(files))
    by_size: dict[int, list[str]] = defaultdict(list)
    for relative, size in files:
        by_size[size].append(relative)
    candidates = [(size, names) for size, names in by_size.items() if len(names) > 1]
    total = sum(len(names) for _, names in candidates)
    done = 0
    for size, names in candidates:
        by_hash: dict[str, list[str]] = defaultdict(list)
        for relative in names:
            try:
                by_hash[file_hash(folder / relative)].append(relative)
            except OSError:
                pass
            done += 1
            if progress and (done % 25 == 0 or done == total):
                progress(done, total)
        for same in by_hash.values():
            if len(same) > 1:
                same.sort(key=lambda r: (len(r), r))   # «sticker.webp» раньше «sticker (1).webp»
                result.groups.append(Group(keep=same[0], dupes=same[1:], size=size))
    result.groups.sort(key=lambda g: g.size * len(g.dupes), reverse=True)
    return result


# ----------------------------------------------------------------------------
# Таблица замен
# ----------------------------------------------------------------------------

def load_map() -> dict[str, dict[str, str]]:
    try:
        data = json.loads(export_paths.dedup_map_path().read_text(encoding="utf-8-sig"))
        return {str(k): dict(v) for k, v in data.get("folders", {}).items()}
    except (OSError, ValueError, AttributeError, TypeError):
        return {}


def save_map(table: dict[str, dict[str, str]]) -> None:
    path = export_paths.dedup_map_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps({"folders": table}, ensure_ascii=False, indent=1), encoding="utf-8")
    temporary.replace(path)


def apply(result: ScanResult, progress=None) -> tuple[int, int, int]:
    """Удаляет повторы. Возвращает (удалено, освобождено байт, не удалось).
    Сначала замены записываются в таблицу, потом файлы удаляются: при сбое посередине всё останется рабочим."""
    folder = result.folder
    table = load_map()
    key = next((k for k in table if os.path.normcase(k) == os.path.normcase(str(folder))), str(folder))
    entries = table.setdefault(key, {})
    planned = {dupe: group.keep for group in result.groups for dupe in group.dupes}
    entries.update(planned)
    save_map(table)

    deleted = failed = freed = 0
    total = len(planned)
    for group in result.groups:
        keep = folder / group.keep
        for dupe in group.dupes:
            target = folder / dupe
            try:
                if not keep.is_file() or not filecmp.cmp(keep, target, shallow=False):   # последняя проверка перед удалением
                    raise OSError("файлы различаются или оставляемая копия пропала")
                target.unlink()
                deleted += 1
                freed += group.size
            except OSError:
                failed += 1
                if target.is_file():          # файл на месте — замена не нужна
                    entries.pop(dupe, None)
            if progress and ((deleted + failed) % 25 == 0 or deleted + failed == total):
                progress(deleted + failed, total)
    if not entries:
        table.pop(key, None)
    save_map(table)
    return deleted, freed, failed


# ----------------------------------------------------------------------------
# Диалог
# ----------------------------------------------------------------------------

def _ask(prompt: str) -> str:
    return input(f"{prompt}: ").strip()


def _progress(label: str):
    def show(done: int, total: int) -> None:
        print(f"  {label}: {done} из {total}", end="\r", flush=True)
    return show


def clean_folder(folder: Path) -> int:
    """Полный сценарий для одной папки: поиск → отчёт → предупреждение → подтверждение → удаление.
    Возвращает число удалённых файлов."""
    print(f"\nПапка: {folder}")
    print("Ищу повторяющиеся файлы (ничего не удаляется)...")
    result = scan(folder, _progress("проверено"))
    print(" " * 60, end="\r")
    if not result.groups:
        print(f"✔ Повторов нет (проверено файлов: {result.files}). Чистить нечего.")
        return 0
    print(f"Файлов всего: {result.files}. Повторяющихся копий: {result.dupe_count} "
          f"(в {len(result.groups)} группах). Освободится: {human_size(result.bytes_freed)}.")
    print("Чаще всего повторяются:")
    for group in result.groups[:5]:
        print(f"  • {group.keep}  — ещё {len(group.dupes)} копий по {human_size(group.size)}")

    print(WARNING)
    if _ask("Продолжить? (д/Н)").lower() not in {"д", "да", "y", "yes"}:
        print("Отменено, ничего не удалено.")
        return 0
    if _ask(f"Для подтверждения введите слово {CONFIRM_WORD}").casefold() != CONFIRM_WORD.casefold():
        print("Слово не совпало. Отменено, ничего не удалено.")
        return 0

    print("Удаляю повторы...")
    deleted, freed, failed = apply(result, _progress("обработано"))
    print(" " * 60, end="\r")
    print(f"✔ Удалено копий: {deleted}. Освобождено: {human_size(freed)}.")
    if failed:
        print(f"• Не удалось удалить файлов: {failed} (заняты или изменились) — они остались как были.")
    return deleted


def known_folders() -> list[tuple[str, Path]]:
    import import_export
    found: list[tuple[str, Path]] = []
    main = import_export.stored_export_dir(config.DATABASE_PATH)
    if main and main.is_dir():
        found.append(("основная переписка", main))
    for number, extra in enumerate(import_export.load_extra_sources(), start=1):
        if extra.is_dir():
            found.append((f"дополнительная папка {number}", extra))
    return found


def run_menu() -> int:
    """Выбор папки (подключённой к архиву или любой другой по пути) и очистка. Возвращает число удалённых файлов."""
    import import_export
    print("=== Убрать повторяющиеся файлы ===")
    print("Если один стикер/фото/гифка/видео сохранён в экспорте много раз, останется одна копия.")
    folders = known_folders()
    for number, (label, path) in enumerate(folders, start=1):
        print(f"  {number}. {label}: {path}")
    print("Введите номер или вставьте путь к ЛЮБОЙ другой папке экспорта (где лежит messages.html). Enter — выход.")
    while True:
        value = _ask("Папка").strip('"').strip("'")
        if not value:
            return 0
        if value.isdigit() and 1 <= int(value) <= len(folders):
            folder = folders[int(value) - 1][1]
        else:
            folder = Path(value).expanduser()
            if not folder.is_dir() or not import_export.export_pages(folder):
                print("✖ Это не папка экспорта: внутри должен лежать messages.html.")
                continue
        deleted = clean_folder(folder.resolve())
        if deleted and not any(folder.resolve() == path.resolve() for _, path in folders):
            print("• Эта папка не подключена к архиву. Когда подключите её («3_Добавить_новую_часть.bat»), "
                  "бот учтёт очистку. Файл dedup_map.json при этом должен остаться на месте.")
        return deleted


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    try:
        run_menu()
    except (KeyboardInterrupt, EOFError):
        print("\nОтменено.")
    try:
        input("\nНажмите Enter, чтобы закрыть окно...")
    except EOFError:
        pass
