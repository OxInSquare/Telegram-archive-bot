"""Мастер установки: токен → ваш ID → папка экспорта → индексация → автозапуск."""

from __future__ import annotations

import re
import sys
import time
import urllib.error
from pathlib import Path

import config
import import_export
import manage

TOKEN_RE = re.compile(r"^\d{6,}:[A-Za-z0-9_-]{20,}$")
ID_WAIT_SECONDS = 120


def ask(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"{prompt}{suffix}: ").strip()
    return value or default


def yes_no(prompt: str, default: bool = True) -> bool:
    hint = "Д/н" if default else "д/Н"
    answer = input(f"{prompt} ({hint}): ").strip().lower()
    if not answer:
        return default
    return answer in {"д", "да", "y", "yes", "1"}


def step(number: int, title: str) -> None:
    print(f"\n--- Шаг {number} из 5. {title} ---")


# --- 1. Токен ---------------------------------------------------------------

def get_token() -> tuple[str, str]:
    """Возвращает (токен, @username бота)."""
    if config.TOKEN and TOKEN_RE.fullmatch(config.TOKEN):
        username = _bot_username(config.TOKEN)
        if username and yes_no(f"Уже подключён бот @{username}. Оставить его?"):
            return config.TOKEN, username
    print(
        "Откройте в Telegram @BotFather → отправьте /newbot → придумайте имя и username →\n"
        "скопируйте длинный токен и вставьте сюда (правой кнопкой мыши в окне)."
    )
    while True:
        token = ask("Токен").strip('"').strip("'")
        if not TOKEN_RE.fullmatch(token):
            print("Это не похоже на токен. Он выглядит так: 123456789:AAE...длинный набор символов.")
            continue
        try:
            reply = manage.telegram_call(token, "getMe")
        except (urllib.error.URLError, TimeoutError, OSError):
            if yes_no("Не удалось связаться с Telegram (нет интернета?). Всё равно использовать этот токен?", False):
                return token, ""
            continue
        if reply.get("ok"):
            username = reply["result"]["username"]
            print(f"✔ Бот найден: @{username}")
            return token, username
        print("✖ Telegram не принял этот токен. Проверьте, что скопировали его целиком.")


def _bot_username(token: str) -> str:
    try:
        reply = manage.telegram_call(token, "getMe", timeout=10)
        return reply["result"]["username"] if reply.get("ok") else ""
    except (urllib.error.URLError, TimeoutError, OSError, KeyError):
        return ""


# --- 2. Telegram ID ---------------------------------------------------------

def detect_user_id(token: str, username: str) -> tuple[int, str] | None:
    """Ждёт, пока человек напишет боту, и берёт ID из первого сообщения."""
    try:
        latest = manage.telegram_call(token, "getUpdates", {"offset": -1, "timeout": 0})
        if not latest.get("ok"):
            return None
        offset = (latest["result"][-1]["update_id"] + 1) if latest["result"] else 0
        deadline = time.monotonic() + ID_WAIT_SECONDS
        while time.monotonic() < deadline:
            reply = manage.telegram_call(token, "getUpdates", {"offset": offset, "timeout": 8, "allowed_updates": ["message"]}, timeout=20)
            if not reply.get("ok"):
                return None
            for update in reply["result"]:
                offset = update["update_id"] + 1
                sender = update.get("message", {}).get("from")
                if sender and not sender.get("is_bot"):
                    name = sender.get("first_name") or sender.get("username") or ""
                    manage.telegram_call(token, "getUpdates", {"offset": offset, "timeout": 0})  # отметить прочитанным
                    return int(sender["id"]), name
    except (urllib.error.URLError, TimeoutError, OSError, KeyError, ValueError):
        return None
    return None


def get_user_ids(token: str, username: str, existing: set[int]) -> set[int]:
    ids: set[int] = set()
    if existing and yes_no(f"Уже разрешён доступ для ID: {', '.join(map(str, sorted(existing)))}. Оставить?"):
        ids |= existing
    if not ids:
        link = f"https://t.me/{username}" if username else "вашему боту"
        print(f"Теперь откройте {link} и отправьте ему любое сообщение (например «привет»).")
        print(f"Я жду до {ID_WAIT_SECONDS // 60} минут и сам определю ваш Telegram ID...")
        found = detect_user_id(token, username)
        if found:
            print(f"✔ Определён ваш ID: {found[0]} ({found[1]})")
            ids.add(found[0])
        else:
            print("Не удалось определить автоматически. ID можно узнать у бота @userinfobot.")
            while not ids:
                ids = _manual_ids(ask("Введите ваш числовой Telegram ID"))
    while yes_no("Дать доступ ещё кому-нибудь (например, второму человеку из переписки)?", False):
        print("Попросите этого человека написать любое сообщение вашему боту, а затем команду /id — бот ответит его числом.")
        more = _manual_ids(ask("Введите его числовой ID"))
        if more:
            ids |= more
    return ids


def _manual_ids(raw: str) -> set[int]:
    try:
        return config.parse_user_ids(raw)
    except ValueError as error:
        print("✖", error)
        return set()


# --- 3. Папка экспорта ------------------------------------------------------

def find_export_candidates() -> list[Path]:
    roots = [Path.home() / "Downloads" / "Telegram Desktop", Path.home() / "Documents" / "Telegram Desktop", Path.home() / "Desktop"]
    found: list[Path] = []
    for root in roots:
        if root.is_dir():
            found.extend(sorted(p.parent for p in root.glob("ChatExport_*/messages.html")))
    return sorted(set(found), key=lambda p: p.stat().st_mtime, reverse=True)


def get_export_dir() -> Path:
    previous = import_export.stored_export_dir(config.DATABASE_PATH)
    candidates = find_export_candidates()          # самые свежие — первыми
    if previous and previous.is_dir() and previous not in candidates:
        candidates.append(previous)
    candidates = candidates[:9]
    if candidates:
        print("Нашёл экспорты Telegram на этом компьютере (первый — самый свежий):")
        for number, folder in enumerate(candidates, start=1):
            note = "  ← использовался раньше" if folder == previous else ""
            print(f"  {number}. {folder}{note}")
        print("Нажмите Enter, чтобы взять номер 1, введите другой номер или вставьте путь к другой папке.")
    else:
        print(
            "Экспорт делается в Telegram Desktop: откройте чат → ⋮ → «Экспорт истории чата» →\n"
            "формат «HTML», отметьте нужные медиа → «Экспортировать». Затем вставьте сюда путь к папке экспорта\n"
            "(папка, где лежит messages.html). Можно перетащить папку мышкой в это окно."
        )
    while True:
        value = ask("Папка экспорта").strip('"').strip("'")
        if not value and candidates:
            return candidates[0]
        if value.isdigit() and 1 <= int(value) <= len(candidates):
            return candidates[int(value) - 1]
        folder = Path(value).expanduser()
        if (folder / "messages.html").is_file():
            return folder.resolve()
        print("✖ В этой папке нет messages.html. Нужна папка, внутри которой лежат messages.html и папки photos, video_files...")


def offer_dedup(export_dir: Path) -> None:
    """Необязательно: убрать повторяющиеся стикеры/фото. По умолчанию — нет, с отдельным предупреждением."""
    print(
        "\nНеобязательно: если в чате много одинаковых стикеров, фото или гифок, можно оставить по одной копии\n"
        "и сэкономить место. Это удаляет файлы из папки экспорта БЕЗ возможности вернуть. "
        "Позже это можно сделать в «Управление» → пункт 12."
    )
    if not yes_no("Проверить папку на повторы сейчас?", False):
        return
    import dedup
    dedup.clean_folder(export_dir)


# --- 4. Приложение внутри Telegram --------------------------------------------

def get_webapp_url() -> str:
    current = config.WEBAPP_URL
    print(
        "Приложение — это лента как в обычном чате, внутри Telegram (поиск по словам и датам, календарь, фото, видео, голосовые).\n"
        "Ему нужен публичный https-адрес вашего компьютера; как его получить за 5 минут бесплатно (Tailscale Funnel) — в README.txt, раздел «Приложение».\n"
        "Можно пропустить сейчас и добавить позже: «Управление» → пункт 7 → строка WEBAPP_URL."
    )
    if current:
        print(f"Сейчас указан адрес: {current}")
    while True:
        value = ask("Адрес https://... (Enter — " + ("оставить как есть" if current else "пропустить") + ")").strip().rstrip("/")
        if not value:
            return current
        if value.startswith("https://") and "." in value:
            return value
        print("✖ Адрес должен начинаться с https:// (например https://мой-компьютер.tailXXXX.ts.net).")


# --- 5. Индексация и запуск -------------------------------------------------

def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    print("=== Настройка архив-бота ===")
    try:
        step(1, "Бот из Telegram")
        token, username = get_token()

        step(2, "Кому разрешён доступ")
        ids = get_user_ids(token, username, set(config.ALLOWED_USER_IDS))

        def save(webapp_url: str) -> None:
            config.write_config(token, ids, protect=config.PROTECT_CONTENT, owner=config.OWNER_NAME,
                                page_size=config.PAGE_SIZE, webapp_url=webapp_url, webapp_port=config.WEBAPP_PORT, webapp_button=config.WEBAPP_BUTTON_TEXT)

        save(config.WEBAPP_URL)
        print("✔ Настройки сохранены.")

        step(3, "Экспорт переписки")
        export_dir = get_export_dir()
        print("Индексирую переписку (для больших чатов — до пары минут)...")
        import_export.run_indexing(export_dir, config.DATABASE_PATH)
        offer_dedup(export_dir)

        step(4, "Приложение внутри Telegram (по желанию)")
        save(get_webapp_url())

        step(5, "Запуск")
        manage.stop()   # на случай переустановки: освободить старый процесс и файлы
        if yes_no("Запускать бота автоматически при входе в Windows?", True):
            manage.autostart_on()
        manage.start()
    except (KeyboardInterrupt, EOFError):
        print("\nУстановка прервана. Запустите 1_Установить.bat ещё раз — введённое сохранится.")
        sys.exit(1)
    except Exception as error:   # понятное сообщение вместо длинной трассировки
        print(f"\n✖ Ошибка: {error}")
        input("\nНажмите Enter, чтобы закрыть окно...")
        sys.exit(1)

    link = f"t.me/{username}" if username else "своего бота"
    print(f"\n✅ Готово! Откройте {link} в Telegram и нажмите /start.")
    print("Дальше всё делается из «Управление.bat» (запуск, остановка, проверка) и «2_Обновить_переписку.bat».")
    input("\nНажмите Enter, чтобы закрыть окно...")


if __name__ == "__main__":
    main()
