@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "data\venv\Scripts\python.exe" (
  echo Сначала запустите 1_Установить.bat
  pause
  exit /b 1
)
"data\venv\Scripts\python.exe" app\add_export.py
