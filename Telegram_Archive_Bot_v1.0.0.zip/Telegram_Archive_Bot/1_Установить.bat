@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Берём версию Python, для которой есть готовые библиотеки (самые новые версии часто ещё не поддерживаются).
py -3.13 --version >nul 2>nul
if not errorlevel 1 (
  py -3.13 app\bootstrap.py
  exit /b
)
py -3.12 --version >nul 2>nul
if not errorlevel 1 (
  py -3.12 app\bootstrap.py
  exit /b
)
py -3.14 --version >nul 2>nul
if not errorlevel 1 (
  py -3.14 app\bootstrap.py
  exit /b
)
py -3.11 --version >nul 2>nul
if not errorlevel 1 (
  py -3.11 app\bootstrap.py
  exit /b
)
where python >nul 2>nul
if not errorlevel 1 (
  python app\bootstrap.py
  exit /b
)
echo.
echo Подходящий Python не найден.
echo Скачайте Python 3.13 на https://www.python.org/downloads/ и при установке поставьте галочку "Add python.exe to PATH".
echo Потом запустите этот файл снова.
pause
